﻿namespace _2nd_Exercise
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lbl_uc = new System.Windows.Forms.Label();
            this.lbl_username = new System.Windows.Forms.Label();
            this.lbl_pass = new System.Windows.Forms.Label();
            this.btn_login = new System.Windows.Forms.Button();
            this.btn_regis = new System.Windows.Forms.Button();
            this.tb_username = new System.Windows.Forms.TextBox();
            this.tb_pass = new System.Windows.Forms.TextBox();
            this.panel_main = new System.Windows.Forms.Panel();
            this.panel_regis = new System.Windows.Forms.Panel();
            this.lbl_ucR = new System.Windows.Forms.Label();
            this.tb_passR = new System.Windows.Forms.TextBox();
            this.tb_usernameR = new System.Windows.Forms.TextBox();
            this.btn_regisR = new System.Windows.Forms.Button();
            this.lbl_passR = new System.Windows.Forms.Label();
            this.lbl_usernameR = new System.Windows.Forms.Label();
            this.panel_balance = new System.Windows.Forms.Panel();
            this.btn_logout = new System.Windows.Forms.Button();
            this.btn_withdraw = new System.Windows.Forms.Button();
            this.btn_depo = new System.Windows.Forms.Button();
            this.lbl_duid = new System.Windows.Forms.Label();
            this.lbl_balance = new System.Windows.Forms.Label();
            this.lbl_ucB = new System.Windows.Forms.Label();
            this.panel_depo = new System.Windows.Forms.Panel();
            this.tb_depo = new System.Windows.Forms.TextBox();
            this.lbl_inputDepo = new System.Windows.Forms.Label();
            this.btn_logoutD = new System.Windows.Forms.Button();
            this.btn_depoD = new System.Windows.Forms.Button();
            this.lbl_duidD = new System.Windows.Forms.Label();
            this.lbl_balanceD = new System.Windows.Forms.Label();
            this.lbl_ucD = new System.Windows.Forms.Label();
            this.panel_withdraw = new System.Windows.Forms.Panel();
            this.tb_withdraw = new System.Windows.Forms.TextBox();
            this.label_inputWithdraw = new System.Windows.Forms.Label();
            this.btn_logoutW = new System.Windows.Forms.Button();
            this.btn_withdrawW = new System.Windows.Forms.Button();
            this.lbl_duidW = new System.Windows.Forms.Label();
            this.lbl_balanceW = new System.Windows.Forms.Label();
            this.lbl_ucW = new System.Windows.Forms.Label();
            this.panel_main.SuspendLayout();
            this.panel_regis.SuspendLayout();
            this.panel_balance.SuspendLayout();
            this.panel_depo.SuspendLayout();
            this.panel_withdraw.SuspendLayout();
            this.SuspendLayout();
            // 
            // lbl_uc
            // 
            this.lbl_uc.AutoSize = true;
            this.lbl_uc.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_uc.Location = new System.Drawing.Point(16, 25);
            this.lbl_uc.Name = "lbl_uc";
            this.lbl_uc.Size = new System.Drawing.Size(133, 32);
            this.lbl_uc.TabIndex = 0;
            this.lbl_uc.Text = "UC Bank";
            // 
            // lbl_username
            // 
            this.lbl_username.AutoSize = true;
            this.lbl_username.Location = new System.Drawing.Point(18, 87);
            this.lbl_username.Name = "lbl_username";
            this.lbl_username.Size = new System.Drawing.Size(91, 20);
            this.lbl_username.TabIndex = 1;
            this.lbl_username.Text = "Username :";
            // 
            // lbl_pass
            // 
            this.lbl_pass.AutoSize = true;
            this.lbl_pass.Location = new System.Drawing.Point(18, 116);
            this.lbl_pass.Name = "lbl_pass";
            this.lbl_pass.Size = new System.Drawing.Size(86, 20);
            this.lbl_pass.TabIndex = 2;
            this.lbl_pass.Text = "Password :";
            // 
            // btn_login
            // 
            this.btn_login.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_login.Location = new System.Drawing.Point(103, 159);
            this.btn_login.Name = "btn_login";
            this.btn_login.Size = new System.Drawing.Size(126, 33);
            this.btn_login.TabIndex = 3;
            this.btn_login.Text = "LOGIN";
            this.btn_login.UseVisualStyleBackColor = true;
            this.btn_login.Click += new System.EventHandler(this.btn_login_Click);
            // 
            // btn_regis
            // 
            this.btn_regis.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_regis.Location = new System.Drawing.Point(103, 198);
            this.btn_regis.Name = "btn_regis";
            this.btn_regis.Size = new System.Drawing.Size(126, 33);
            this.btn_regis.TabIndex = 4;
            this.btn_regis.Text = "REGISTER";
            this.btn_regis.UseVisualStyleBackColor = true;
            this.btn_regis.Click += new System.EventHandler(this.btn_regis_Click);
            // 
            // tb_username
            // 
            this.tb_username.Location = new System.Drawing.Point(115, 81);
            this.tb_username.Name = "tb_username";
            this.tb_username.Size = new System.Drawing.Size(100, 26);
            this.tb_username.TabIndex = 5;
            // 
            // tb_pass
            // 
            this.tb_pass.Location = new System.Drawing.Point(115, 116);
            this.tb_pass.Name = "tb_pass";
            this.tb_pass.Size = new System.Drawing.Size(100, 26);
            this.tb_pass.TabIndex = 6;
            // 
            // panel_main
            // 
            this.panel_main.Controls.Add(this.tb_pass);
            this.panel_main.Controls.Add(this.tb_username);
            this.panel_main.Controls.Add(this.btn_regis);
            this.panel_main.Controls.Add(this.btn_login);
            this.panel_main.Controls.Add(this.lbl_pass);
            this.panel_main.Controls.Add(this.lbl_username);
            this.panel_main.Controls.Add(this.lbl_uc);
            this.panel_main.Location = new System.Drawing.Point(60, 52);
            this.panel_main.Name = "panel_main";
            this.panel_main.Size = new System.Drawing.Size(264, 240);
            this.panel_main.TabIndex = 7;
            // 
            // panel_regis
            // 
            this.panel_regis.Controls.Add(this.lbl_ucR);
            this.panel_regis.Controls.Add(this.tb_passR);
            this.panel_regis.Controls.Add(this.tb_usernameR);
            this.panel_regis.Controls.Add(this.btn_regisR);
            this.panel_regis.Controls.Add(this.lbl_passR);
            this.panel_regis.Controls.Add(this.lbl_usernameR);
            this.panel_regis.Location = new System.Drawing.Point(60, 55);
            this.panel_regis.Name = "panel_regis";
            this.panel_regis.Size = new System.Drawing.Size(235, 293);
            this.panel_regis.TabIndex = 8;
            this.panel_regis.Visible = false;
            // 
            // lbl_ucR
            // 
            this.lbl_ucR.AutoSize = true;
            this.lbl_ucR.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_ucR.Location = new System.Drawing.Point(16, 25);
            this.lbl_ucR.Name = "lbl_ucR";
            this.lbl_ucR.Size = new System.Drawing.Size(133, 32);
            this.lbl_ucR.TabIndex = 7;
            this.lbl_ucR.Text = "UC Bank";
            // 
            // tb_passR
            // 
            this.tb_passR.Location = new System.Drawing.Point(115, 116);
            this.tb_passR.Name = "tb_passR";
            this.tb_passR.Size = new System.Drawing.Size(100, 26);
            this.tb_passR.TabIndex = 6;
            // 
            // tb_usernameR
            // 
            this.tb_usernameR.Location = new System.Drawing.Point(115, 81);
            this.tb_usernameR.Name = "tb_usernameR";
            this.tb_usernameR.Size = new System.Drawing.Size(100, 26);
            this.tb_usernameR.TabIndex = 5;
            // 
            // btn_regisR
            // 
            this.btn_regisR.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_regisR.Location = new System.Drawing.Point(105, 159);
            this.btn_regisR.Name = "btn_regisR";
            this.btn_regisR.Size = new System.Drawing.Size(126, 33);
            this.btn_regisR.TabIndex = 4;
            this.btn_regisR.Text = "REGISTER";
            this.btn_regisR.UseVisualStyleBackColor = true;
            this.btn_regisR.Click += new System.EventHandler(this.btn_regisR_Click);
            // 
            // lbl_passR
            // 
            this.lbl_passR.AutoSize = true;
            this.lbl_passR.Location = new System.Drawing.Point(18, 116);
            this.lbl_passR.Name = "lbl_passR";
            this.lbl_passR.Size = new System.Drawing.Size(86, 20);
            this.lbl_passR.TabIndex = 2;
            this.lbl_passR.Text = "Password :";
            // 
            // lbl_usernameR
            // 
            this.lbl_usernameR.AutoSize = true;
            this.lbl_usernameR.Location = new System.Drawing.Point(18, 87);
            this.lbl_usernameR.Name = "lbl_usernameR";
            this.lbl_usernameR.Size = new System.Drawing.Size(91, 20);
            this.lbl_usernameR.TabIndex = 1;
            this.lbl_usernameR.Text = "Username :";
            // 
            // panel_balance
            // 
            this.panel_balance.Controls.Add(this.btn_logout);
            this.panel_balance.Controls.Add(this.btn_withdraw);
            this.panel_balance.Controls.Add(this.btn_depo);
            this.panel_balance.Controls.Add(this.lbl_duid);
            this.panel_balance.Controls.Add(this.lbl_balance);
            this.panel_balance.Controls.Add(this.lbl_ucB);
            this.panel_balance.Location = new System.Drawing.Point(56, 52);
            this.panel_balance.Name = "panel_balance";
            this.panel_balance.Size = new System.Drawing.Size(440, 221);
            this.panel_balance.TabIndex = 8;
            this.panel_balance.Visible = false;
            this.panel_balance.Paint += new System.Windows.Forms.PaintEventHandler(this.panel_balance_Paint);
            // 
            // btn_logout
            // 
            this.btn_logout.Location = new System.Drawing.Point(179, 28);
            this.btn_logout.Name = "btn_logout";
            this.btn_logout.Size = new System.Drawing.Size(66, 34);
            this.btn_logout.TabIndex = 5;
            this.btn_logout.Text = "logout";
            this.btn_logout.UseVisualStyleBackColor = true;
            this.btn_logout.Click += new System.EventHandler(this.btn_logout_Click);
            // 
            // btn_withdraw
            // 
            this.btn_withdraw.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_withdraw.Location = new System.Drawing.Point(90, 173);
            this.btn_withdraw.Name = "btn_withdraw";
            this.btn_withdraw.Size = new System.Drawing.Size(96, 33);
            this.btn_withdraw.TabIndex = 4;
            this.btn_withdraw.Text = "withdraw";
            this.btn_withdraw.UseVisualStyleBackColor = true;
            this.btn_withdraw.Click += new System.EventHandler(this.btn_withdraw_Click);
            // 
            // btn_depo
            // 
            this.btn_depo.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_depo.Location = new System.Drawing.Point(90, 134);
            this.btn_depo.Name = "btn_depo";
            this.btn_depo.Size = new System.Drawing.Size(96, 33);
            this.btn_depo.TabIndex = 3;
            this.btn_depo.Text = "deposit";
            this.btn_depo.UseVisualStyleBackColor = true;
            this.btn_depo.Click += new System.EventHandler(this.btn_depo_Click);
            // 
            // lbl_duid
            // 
            this.lbl_duid.AutoSize = true;
            this.lbl_duid.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_duid.Location = new System.Drawing.Point(100, 87);
            this.lbl_duid.Name = "lbl_duid";
            this.lbl_duid.Size = new System.Drawing.Size(86, 25);
            this.lbl_duid.TabIndex = 2;
            this.lbl_duid.Text = "Rp 0,00";
            // 
            // lbl_balance
            // 
            this.lbl_balance.AutoSize = true;
            this.lbl_balance.Location = new System.Drawing.Point(18, 87);
            this.lbl_balance.Name = "lbl_balance";
            this.lbl_balance.Size = new System.Drawing.Size(75, 20);
            this.lbl_balance.TabIndex = 1;
            this.lbl_balance.Text = "Balance :";
            // 
            // lbl_ucB
            // 
            this.lbl_ucB.AutoSize = true;
            this.lbl_ucB.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_ucB.Location = new System.Drawing.Point(16, 25);
            this.lbl_ucB.Name = "lbl_ucB";
            this.lbl_ucB.Size = new System.Drawing.Size(133, 32);
            this.lbl_ucB.TabIndex = 0;
            this.lbl_ucB.Text = "UC Bank";
            // 
            // panel_depo
            // 
            this.panel_depo.Controls.Add(this.tb_depo);
            this.panel_depo.Controls.Add(this.lbl_inputDepo);
            this.panel_depo.Controls.Add(this.btn_logoutD);
            this.panel_depo.Controls.Add(this.btn_depoD);
            this.panel_depo.Controls.Add(this.lbl_duidD);
            this.panel_depo.Controls.Add(this.lbl_balanceD);
            this.panel_depo.Controls.Add(this.lbl_ucD);
            this.panel_depo.Location = new System.Drawing.Point(56, 51);
            this.panel_depo.Name = "panel_depo";
            this.panel_depo.Size = new System.Drawing.Size(278, 354);
            this.panel_depo.TabIndex = 9;
            this.panel_depo.Visible = false;
            // 
            // tb_depo
            // 
            this.tb_depo.Location = new System.Drawing.Point(86, 146);
            this.tb_depo.Name = "tb_depo";
            this.tb_depo.Size = new System.Drawing.Size(100, 26);
            this.tb_depo.TabIndex = 7;
            // 
            // lbl_inputDepo
            // 
            this.lbl_inputDepo.AutoSize = true;
            this.lbl_inputDepo.Location = new System.Drawing.Point(65, 123);
            this.lbl_inputDepo.Name = "lbl_inputDepo";
            this.lbl_inputDepo.Size = new System.Drawing.Size(166, 20);
            this.lbl_inputDepo.TabIndex = 6;
            this.lbl_inputDepo.Text = "input deposit amount :";
            // 
            // btn_logoutD
            // 
            this.btn_logoutD.Location = new System.Drawing.Point(179, 28);
            this.btn_logoutD.Name = "btn_logoutD";
            this.btn_logoutD.Size = new System.Drawing.Size(66, 34);
            this.btn_logoutD.TabIndex = 5;
            this.btn_logoutD.Text = "logout";
            this.btn_logoutD.UseVisualStyleBackColor = true;
            this.btn_logoutD.Click += new System.EventHandler(this.btn_logoutD_Click);
            // 
            // btn_depoD
            // 
            this.btn_depoD.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_depoD.Location = new System.Drawing.Point(92, 178);
            this.btn_depoD.Name = "btn_depoD";
            this.btn_depoD.Size = new System.Drawing.Size(84, 33);
            this.btn_depoD.TabIndex = 3;
            this.btn_depoD.Text = "deposit";
            this.btn_depoD.UseVisualStyleBackColor = true;
            this.btn_depoD.Click += new System.EventHandler(this.btn_depoD_Click);
            // 
            // lbl_duidD
            // 
            this.lbl_duidD.AutoSize = true;
            this.lbl_duidD.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_duidD.Location = new System.Drawing.Point(100, 87);
            this.lbl_duidD.Name = "lbl_duidD";
            this.lbl_duidD.Size = new System.Drawing.Size(86, 25);
            this.lbl_duidD.TabIndex = 2;
            this.lbl_duidD.Text = "Rp 0,00";
            // 
            // lbl_balanceD
            // 
            this.lbl_balanceD.AutoSize = true;
            this.lbl_balanceD.Location = new System.Drawing.Point(18, 87);
            this.lbl_balanceD.Name = "lbl_balanceD";
            this.lbl_balanceD.Size = new System.Drawing.Size(75, 20);
            this.lbl_balanceD.TabIndex = 1;
            this.lbl_balanceD.Text = "Balance :";
            // 
            // lbl_ucD
            // 
            this.lbl_ucD.AutoSize = true;
            this.lbl_ucD.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_ucD.Location = new System.Drawing.Point(16, 25);
            this.lbl_ucD.Name = "lbl_ucD";
            this.lbl_ucD.Size = new System.Drawing.Size(133, 32);
            this.lbl_ucD.TabIndex = 0;
            this.lbl_ucD.Text = "UC Bank";
            // 
            // panel_withdraw
            // 
            this.panel_withdraw.Controls.Add(this.tb_withdraw);
            this.panel_withdraw.Controls.Add(this.label_inputWithdraw);
            this.panel_withdraw.Controls.Add(this.btn_logoutW);
            this.panel_withdraw.Controls.Add(this.btn_withdrawW);
            this.panel_withdraw.Controls.Add(this.lbl_duidW);
            this.panel_withdraw.Controls.Add(this.lbl_balanceW);
            this.panel_withdraw.Controls.Add(this.lbl_ucW);
            this.panel_withdraw.Location = new System.Drawing.Point(56, 51);
            this.panel_withdraw.Name = "panel_withdraw";
            this.panel_withdraw.Size = new System.Drawing.Size(336, 315);
            this.panel_withdraw.TabIndex = 10;
            this.panel_withdraw.Visible = false;
            // 
            // tb_withdraw
            // 
            this.tb_withdraw.Location = new System.Drawing.Point(86, 146);
            this.tb_withdraw.Name = "tb_withdraw";
            this.tb_withdraw.Size = new System.Drawing.Size(100, 26);
            this.tb_withdraw.TabIndex = 7;
            // 
            // label_inputWithdraw
            // 
            this.label_inputWithdraw.AutoSize = true;
            this.label_inputWithdraw.Location = new System.Drawing.Point(65, 123);
            this.label_inputWithdraw.Name = "label_inputWithdraw";
            this.label_inputWithdraw.Size = new System.Drawing.Size(188, 20);
            this.label_inputWithdraw.TabIndex = 6;
            this.label_inputWithdraw.Text = "input withdrawal amount :";
            // 
            // btn_logoutW
            // 
            this.btn_logoutW.Location = new System.Drawing.Point(179, 28);
            this.btn_logoutW.Name = "btn_logoutW";
            this.btn_logoutW.Size = new System.Drawing.Size(66, 34);
            this.btn_logoutW.TabIndex = 5;
            this.btn_logoutW.Text = "logout";
            this.btn_logoutW.UseVisualStyleBackColor = true;
            this.btn_logoutW.Click += new System.EventHandler(this.btn_logoutW_Click);
            // 
            // btn_withdrawW
            // 
            this.btn_withdrawW.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_withdrawW.Location = new System.Drawing.Point(86, 178);
            this.btn_withdrawW.Name = "btn_withdrawW";
            this.btn_withdrawW.Size = new System.Drawing.Size(100, 33);
            this.btn_withdrawW.TabIndex = 3;
            this.btn_withdrawW.Text = "withdrawal";
            this.btn_withdrawW.UseVisualStyleBackColor = true;
            this.btn_withdrawW.Click += new System.EventHandler(this.btn_withdrawW_Click);
            // 
            // lbl_duidW
            // 
            this.lbl_duidW.AutoSize = true;
            this.lbl_duidW.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_duidW.Location = new System.Drawing.Point(100, 87);
            this.lbl_duidW.Name = "lbl_duidW";
            this.lbl_duidW.Size = new System.Drawing.Size(86, 25);
            this.lbl_duidW.TabIndex = 2;
            this.lbl_duidW.Text = "Rp 0,00";
            // 
            // lbl_balanceW
            // 
            this.lbl_balanceW.AutoSize = true;
            this.lbl_balanceW.Location = new System.Drawing.Point(18, 87);
            this.lbl_balanceW.Name = "lbl_balanceW";
            this.lbl_balanceW.Size = new System.Drawing.Size(75, 20);
            this.lbl_balanceW.TabIndex = 1;
            this.lbl_balanceW.Text = "Balance :";
            // 
            // lbl_ucW
            // 
            this.lbl_ucW.AutoSize = true;
            this.lbl_ucW.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_ucW.Location = new System.Drawing.Point(16, 25);
            this.lbl_ucW.Name = "lbl_ucW";
            this.lbl_ucW.Size = new System.Drawing.Size(133, 32);
            this.lbl_ucW.TabIndex = 0;
            this.lbl_ucW.Text = "UC Bank";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1256, 649);
            this.Controls.Add(this.panel_withdraw);
            this.Controls.Add(this.panel_depo);
            this.Controls.Add(this.panel_balance);
            this.Controls.Add(this.panel_regis);
            this.Controls.Add(this.panel_main);
            this.Name = "Form1";
            this.Text = "Form1";
            this.panel_main.ResumeLayout(false);
            this.panel_main.PerformLayout();
            this.panel_regis.ResumeLayout(false);
            this.panel_regis.PerformLayout();
            this.panel_balance.ResumeLayout(false);
            this.panel_balance.PerformLayout();
            this.panel_depo.ResumeLayout(false);
            this.panel_depo.PerformLayout();
            this.panel_withdraw.ResumeLayout(false);
            this.panel_withdraw.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Label lbl_uc;
        private System.Windows.Forms.Label lbl_username;
        private System.Windows.Forms.Label lbl_pass;
        private System.Windows.Forms.Button btn_login;
        private System.Windows.Forms.Button btn_regis;
        private System.Windows.Forms.TextBox tb_username;
        private System.Windows.Forms.TextBox tb_pass;
        private System.Windows.Forms.Panel panel_main;
        private System.Windows.Forms.Button btn_regisR;
        private System.Windows.Forms.Label lbl_usernameR;
        private System.Windows.Forms.Panel panel_regis;
        private System.Windows.Forms.TextBox tb_passR;
        private System.Windows.Forms.TextBox tb_usernameR;
        private System.Windows.Forms.Label lbl_passR;
        private System.Windows.Forms.Label lbl_ucR;
        private System.Windows.Forms.Panel panel_balance;
        private System.Windows.Forms.Button btn_withdraw;
        private System.Windows.Forms.Button btn_depo;
        private System.Windows.Forms.Label lbl_duid;
        private System.Windows.Forms.Label lbl_balance;
        private System.Windows.Forms.Label lbl_ucB;
        private System.Windows.Forms.Button btn_logout;
        private System.Windows.Forms.Panel panel_depo;
        private System.Windows.Forms.Button btn_logoutD;
        private System.Windows.Forms.Button btn_depoD;
        private System.Windows.Forms.Label lbl_duidD;
        private System.Windows.Forms.Label lbl_balanceD;
        private System.Windows.Forms.Label lbl_ucD;
        private System.Windows.Forms.Label lbl_inputDepo;
        private System.Windows.Forms.TextBox tb_depo;
        private System.Windows.Forms.Panel panel_withdraw;
        private System.Windows.Forms.TextBox tb_withdraw;
        private System.Windows.Forms.Label label_inputWithdraw;
        private System.Windows.Forms.Button btn_logoutW;
        private System.Windows.Forms.Button btn_withdrawW;
        private System.Windows.Forms.Label lbl_duidW;
        private System.Windows.Forms.Label lbl_balanceW;
        private System.Windows.Forms.Label lbl_ucW;
    }
}

