﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.StartPanel;

namespace _2nd_Exercise
{
    public partial class Form1 : Form
    {
        DataTable daftarUN = new DataTable();
        CultureInfo culture = new CultureInfo("id-ID");
        string ingatOrang = string.Empty;
        public Form1()
        {
            InitializeComponent();
            daftarUN.Columns.Add("Username", typeof(string));
            daftarUN.Columns.Add("Password", typeof(string));
            daftarUN.Columns.Add("Balance", typeof(int));
        }

        private void backtomain (object sender, EventArgs e)
        {
            panel_main.Visible = true;
            panel_withdraw.Visible = false;
            panel_balance.Visible = false;
            panel_depo.Visible = false;
            panel_regis.Visible = false;
        }

        private void btn_regis_Click(object sender, EventArgs e)
        {
            panel_regis.Visible = true;
            panel_main.Visible = false;
            panel_withdraw.Visible = false;
            panel_balance.Visible = false;
            panel_depo.Visible = false;
            
        }

        private void btn_login_Click(object sender, EventArgs e)
        {
            int cekLogin = 0;
            
            foreach (DataRow seorang in daftarUN.Rows)
            {
                if(seorang["Username"].ToString() == tb_username.Text && seorang["Password"].ToString() == tb_pass.Text)
                {
                    cekLogin = 1;
                    ingatOrang = seorang["Username"].ToString();
                    lbl_duid.Text = seorang["Balance"].ToString();
                    MessageBox.Show("Login Succesful");
                    panel_balance.Visible = true;
                    panel_regis.Visible = false;
                    panel_depo.Visible = false;
                    panel_main.Visible = false;
                    panel_withdraw.Visible = false;
                    tb_username.Clear();
                    tb_pass.Clear();
                }
                if (seorang["Username"].ToString() == tb_username.Text && seorang["Password"].ToString() != tb_pass.Text)
                {
                    cekLogin = 2;
                    MessageBox.Show("Incorrect Password", "Login Information", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    tb_username.Clear();
                    tb_pass.Clear();
                }
            }
            if (cekLogin == 0)
            {
                  MessageBox.Show("Username or Password not found", "Login Information", MessageBoxButtons.OK, MessageBoxIcon.Error);
                  tb_username.Clear();
                  tb_pass.Clear();
            }
            
        }

        private void btn_depo_Click(object sender, EventArgs e)
        {
            panel_depo.Visible = true;
            panel_main.Visible = false;
            panel_regis.Visible = false;
            panel_balance.Visible = false;
            panel_withdraw.Visible = false;
            foreach (DataRow seorang in daftarUN.Rows)
            {
                if (seorang["Username"].ToString() == ingatOrang)
                {
                    string rupiah = Convert.ToInt32(seorang["Balance"]).ToString("C", culture);
                    lbl_duidD.Text = rupiah;
                }
            }
        }

        private void btn_withdraw_Click(object sender, EventArgs e)
        {
            panel_withdraw.Visible = true;
            panel_balance.Visible = false;
            panel_depo.Visible = false;
            panel_main.Visible = false;
            panel_regis.Visible = false;
            foreach (DataRow seorang in daftarUN.Rows)
            {
                if (seorang["Username"].ToString() == ingatOrang)
                {
                    string rupiah = Convert.ToInt32(seorang["Balance"]).ToString("C", culture);
                    lbl_duidW.Text = rupiah;
                }
            }
        }

        private void btn_regisR_Click(object sender, EventArgs e)
        {
            bool sama = false;
            foreach (DataRow seorang in daftarUN.Rows)
            {
                if ( seorang["Username"].ToString() == tb_usernameR.Text)
                {
                    MessageBox.Show("Username or Password already used", "Registration", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    sama = true;
                    return;
                }
            }
            if (sama == false)
            {
                daftarUN.Rows.Add(tb_usernameR.Text, tb_passR.Text, 0);
                MessageBox.Show("Register Succesful");
            }
            backtomain(sender, e);
            tb_passR.Clear();
            tb_usernameR.Clear();
        }

        private void btn_logout_Click(object sender, EventArgs e)
        {
            backtomain(sender, e);

        }

        private void btn_logoutD_Click(object sender, EventArgs e)
        {
            backtomain(sender, e);

        }

        private void btn_logoutW_Click(object sender, EventArgs e)
        {
            backtomain(sender, e);

        }

        private void btn_withdrawW_Click(object sender, EventArgs e)
        {
            int jumlahtarik = Convert.ToInt32(tb_withdraw.Text);
            
                foreach (DataRow seorang in daftarUN.Rows)
                {
                    if (seorang["Username"].ToString() == ingatOrang)
                    {
                        if (jumlahtarik <= 0 || jumlahtarik > Convert.ToInt32(seorang["Balance"]))
                        {
                            MessageBox.Show("invalid withdraw amount");
                            tb_withdraw.Clear();
                            return;
                        }
                        seorang["Balance"] = Convert.ToInt32(seorang["Balance"]) - jumlahtarik;
                        MessageBox.Show("Successfully withdraw");
                        string rupiah = Convert.ToInt32(seorang["Balance"]).ToString("C", culture);
                        lbl_duidW.Text = rupiah;
                    }
                }
            tb_withdraw.Clear();
            panel_balance.Visible = true;
            panel_withdraw.Visible = false;
        }

        private void btn_depoD_Click(object sender, EventArgs e)
        {
            int jumlahdepo = Convert.ToInt32(tb_depo.Text);
            if (jumlahdepo <= 0)
            {
                MessageBox.Show("Deposit amount can't be less than 1");
                tb_depo.Clear();
            }
            else
            {
                foreach (DataRow seorang in daftarUN.Rows)
                {
                    if (seorang["Username"].ToString() == ingatOrang)
                    {
                        seorang["Balance"] = Convert.ToInt32(seorang["Balance"]) + jumlahdepo;
                        MessageBox.Show("Successfully Add Deposit");
                        string rupiah = Convert.ToInt32(seorang["Balance"]).ToString("C", culture);
                        lbl_duidD.Text = rupiah;
                    }
                }
                tb_depo.Clear();
                panel_balance.Visible = true;
                panel_depo.Visible = false;
                
            }
        }

        private void panel_balance_Paint(object sender, PaintEventArgs e)
        {
            foreach (DataRow seorang in daftarUN.Rows)
            {
                if (seorang["Username"].ToString() == ingatOrang)
                {
                    string rupiah = Convert.ToInt32(seorang["Balance"]).ToString("C", culture);
                    lbl_duid.Text = rupiah;
                }
            }
        }

    }
}
