﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace UniqME
{
    public partial class Form1 : Form
    {
        DataTable keranjang = new DataTable();
        string hapus = "";
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            dgv_keranjang.DataSource = keranjang;
            keranjang.Columns.Add("Item");
            keranjang.Columns.Add("Qty");
            keranjang.Columns.Add("Price");
            keranjang.Columns.Add("Total");
        }

        private void nambah(string itemName, int harga)
        {
            bool cek = false;
            int jumlah = 1;

            foreach (DataRow dr in keranjang.Rows)
            {
                if (dr["Item"].ToString() == itemName)
                {
                    cek = true;
                    break;
                }
                else
                {
                    cek = false;
                }
            }
            if (cek == false)
            {
                keranjang.Rows.Add(itemName, jumlah, harga, jumlah * harga);
            }
            else if (cek == true)
            {
                foreach (DataRow dr in keranjang.Rows)
                {
                    if (dr["Item"].ToString() == itemName)
                    {
                        int currentQty = Convert.ToInt32(dr["Qty"]); 
                        int newQty = currentQty + 1; 
                        dr["Qty"] = newQty; 
                        dr["Total"] = newQty * harga; 
                        break;
                    }
                }
            }
            nentuinHarga();
        }

        private void btn_kaosHitam_Click(object sender, EventArgs e)
        {
            int harga = 200000;
            string namaItem = "T-Shirt Hitam";
            nambah(namaItem, harga);
        }

        private void btn_kaosPutih_Click(object sender, EventArgs e)
        {
            int harga = 200000;
            string namaItem = "T-Shirt Putih";
            nambah(namaItem, harga);
        }

        private void btn_kaosBiru_Click(object sender, EventArgs e)
        {
            int harga = 200000;
            string namaItem = "T-Shirt Biru";
            nambah(namaItem, harga);
        }
        private void btn_kemejaHitam_Click(object sender, EventArgs e)
        {
            int harga = 500000;
            string namaItem = "Shirt Hitam";
            nambah(namaItem, harga);
        }

        private void btn_kemejaPutih_Click(object sender, EventArgs e)
        {
            int harga = 500000;
            string namaItem = "Shirt Putih";
            nambah(namaItem, harga);
        }

        private void btn_kemejaBiru_Click(object sender, EventArgs e)
        {
            int harga = 500000;
            string namaItem = "Shirt Biru";
            nambah(namaItem, harga);
        }

        private void btn_celpenKhaki_Click(object sender, EventArgs e)
        {
            int harga = 350000;
            string namaItem = "Khaki Shorts";
            nambah(namaItem, harga);
        }

        private void btn_celpenHijau_Click(object sender, EventArgs e)
        {
            int harga = 350000;
            string namaItem = "Green Shorts";
            nambah(namaItem, harga);
        }

        private void btn_celpenJeans_Click(object sender, EventArgs e)
        {
            int harga = 500000;
            string namaItem = "Jeans Shorts";
            nambah(namaItem, harga);
        }

        private void btn_celpanHitam_Click(object sender, EventArgs e)
        {
            int harga = 400000;
            string namaItem = "Black Pants";
            nambah(namaItem, harga);
        }

        private void btn_celpanHijau_Click(object sender, EventArgs e)
        {
            int harga = 400000;
            string namaItem = "Green Pants";
            nambah(namaItem, harga);
        }
        private void btn_celpanKhaki_Click(object sender, EventArgs e)
        {
            int harga = 400000;
            string namaItem = "Khaki Pants";
            nambah(namaItem, harga);
        }
        private void btn_cap_Click(object sender, EventArgs e)
        {
            int harga = 200000;
            string namaItem = "Baseball Cap";
            nambah(namaItem, harga);
        }

        private void btn_belt_Click(object sender, EventArgs e)
        {
            int harga = 400000;
            string namaItem = "Leather Belt";
            nambah(namaItem, harga);
        }

        private void btn_bag_Click(object sender, EventArgs e)
        {
            int harga = 200000;
            string namaItem = "Dumpling Bag";
            nambah(namaItem, harga);
        }

        private void btn_slipOn_Click(object sender, EventArgs e)
        {
            int harga = 800000;
            string namaItem = "Slip On Shoes";
            nambah(namaItem, harga);
        }

        private void btn_platform_Click(object sender, EventArgs e)
        {
            int harga = 600000;
            string namaItem = "Platform Sandal";
            nambah(namaItem, harga);
        }

        private void btn_loafers_Click(object sender, EventArgs e)
        {
            int harga = 1000000;
            string namaItem = "Loafers";
            nambah(namaItem, harga);
        }

        private void nentuinHarga()
        {
            int total = 0;
            int subtotal = 0;
            foreach (DataRow dr in keranjang.Rows)
            {
                subtotal = subtotal + Convert.ToInt32(dr["Total"]);
                total = subtotal + (subtotal / 10);
                tb_subTotal.Text = subtotal.ToString();
                tb_total.Text = total.ToString();
            }
        }
        private void btn_delete_Click(object sender, EventArgs e)
        {
            if (dgv_keranjang.SelectedCells.Count > 0)
            {
                DataRow hapus2 = null;
                foreach (DataRow dr in keranjang.Rows)
                {
                    if (dr["Item"].ToString() == hapus)
                    {
                        hapus2 = dr;
                        break;
                    }
                }
                if (hapus2 != null)
                {
                    keranjang.Rows.Remove(hapus2);
                }
                dgv_keranjang.Refresh();
            }
            else
            {
                MessageBox.Show("Please select an item", "Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
            nentuinHarga();
        }

        private void dgv_keranjang_CellMouseClick(object sender, DataGridViewCellMouseEventArgs e)
        {
            hapus = dgv_keranjang.CurrentRow.Cells[0].Value.ToString();
        }

        private void tShirtToolStripMenuItem_Click(object sender, EventArgs e)
        {
            panel_tshirt.Visible = true;
            panel_shirt.Visible = false;
            panel_pants.Visible = false;
            panel_long.Visible = false;
            panel_jewelleries.Visible = false;
            panel_shoes.Visible = false;
            panel_others.Visible = false;
        }

        private void shirtToolStripMenuItem_Click(object sender, EventArgs e)
        {
            panel_shirt.Visible = true;
            panel_tshirt.Visible = false;
            panel_pants.Visible = false;
            panel_long.Visible = false;
            panel_jewelleries.Visible = false;
            panel_shoes.Visible = false;
            panel_others.Visible = false;
        }

        private void pantsToolStripMenuItem_Click(object sender, EventArgs e)
        {
            panel_pants.Visible = true;
            panel_shirt.Visible = false;
            panel_tshirt.Visible = false;
            panel_long.Visible = false;
            panel_jewelleries.Visible = false;
            panel_shoes.Visible = false;
            panel_others.Visible = false;
        }

        private void longPantsToolStripMenuItem_Click(object sender, EventArgs e)
        {
            panel_long.Visible = true;
            panel_pants.Visible = false;
            panel_shirt.Visible = false;
            panel_tshirt.Visible = false;
            panel_jewelleries.Visible = false;
            panel_shoes.Visible = false;
            panel_others.Visible = false;
        }

        private void shoesToolStripMenuItem_Click(object sender, EventArgs e)
        {
            panel_shoes.Visible = true;
            panel_jewelleries.Visible = false;
            panel_long.Visible = false;
            panel_pants.Visible = false;
            panel_shirt.Visible = false;
            panel_tshirt.Visible = false;
            panel_others.Visible = false;
        }

        private void jewelleriesToolStripMenuItem_Click(object sender, EventArgs e)
        {
            panel_jewelleries.Visible = true;
            panel_long.Visible = false;
            panel_pants.Visible = false;
            panel_shirt.Visible = false;
            panel_tshirt.Visible = false;
            panel_shoes.Visible = false;
            panel_others.Visible = false;
        }

        private void tb_hargaUpload_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar) && (e.KeyChar != '.'))
            {
                e.Handled = true;
            }

            if ((e.KeyChar == '.') && ((sender as TextBox).Text.IndexOf('.') > -1))
            {
                e.Handled = true;
            }
        }

        private void btn_uploadImage_Click(object sender, EventArgs e)
        {
            OpenFileDialog openFileDialog = new OpenFileDialog();
            openFileDialog.Filter = "Image Files (*.jpg, *.jpeg, *.png, *.bmp)|*.jpg;*.jpeg;*.png;*.bmp";

            if (openFileDialog.ShowDialog() == DialogResult.OK)
            {
                pb_others.Image = Image.FromFile(openFileDialog.FileName);
                pb_others.SizeMode = PictureBoxSizeMode.Zoom;
                tb_itemUpload.Enabled = true;
                tb_hargaUpload.Enabled = true;
            }
        }

        private void tsm_others_Click(object sender, EventArgs e)
        {
            panel_others.Visible = true;
            panel_shoes.Visible = false;
            panel_jewelleries.Visible = false;
            panel_long.Visible = false;
            panel_pants.Visible = false;
            panel_shirt.Visible = false;
            panel_tshirt.Visible = false;
        }

        private void btn_upload_Click(object sender, EventArgs e)
        {
            string item = tb_itemUpload.Text;
            int harga = Convert.ToInt32(tb_hargaUpload.Text);
            nambah(item, harga);
        }

        private void tb_itemUpload_TextChanged(object sender, EventArgs e)
        {
            if (tb_itemUpload.Text.Length > 0 && tb_hargaUpload.Text.Length > 0)
            {
                btn_upload.Enabled = true;
            }
            else
            {
                btn_upload.Enabled = false;
            }
        }

        private void tb_hargaUpload_TextChanged(object sender, EventArgs e)
        {
            if (tb_itemUpload.Text.Length > 0 && tb_hargaUpload.Text.Length > 0)
            {
                btn_upload.Enabled = true;
            }
            else
            {
                btn_upload.Enabled = false;
            }
        }
    }
}
