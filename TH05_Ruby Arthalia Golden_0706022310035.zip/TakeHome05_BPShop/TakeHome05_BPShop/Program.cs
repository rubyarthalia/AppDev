﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace TakeHome05_BPShop
{
    internal static class Program
    {
        [STAThread]
        static void Main()//the first method to be executed when the program is started
        {
            Application.Run(new Welcome());
        }
    }
}
