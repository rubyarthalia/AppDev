﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Runtime.ConstrainedExecution;
using System.Text;
using System.Threading.Tasks;
using System.Web;
using System.Windows.Forms;
using TakeHome05_BPShop;

namespace TakeHome05_BPShop
{
    public partial class shop : Form
    {
        public shop()
        {
            InitializeComponent();
            listCategory.Columns.Add("ID Category", typeof(string));
            listCategory.Columns.Add("Nama Category", typeof(string));
            listProduct.Columns.Add("ID Product");
            listProduct.Columns.Add("Nama Product");
            listProduct.Columns.Add("Harga");
            listProduct.Columns.Add("Stock");
            listProduct.Columns.Add("ID Category");
            listProduct.Rows.Add("J001", "Jas Hitam", "100000", "10", "C1");
            listProduct.Rows.Add("T001", "T-Shirt Black Pink", "70000", "20", "C2");
            listProduct.Rows.Add("T002", "T-Shirt Obsessive", "75000", "16", "C2");
            listProduct.Rows.Add("R001", "Rok Mini", "82000", "26", "C3");
            listProduct.Rows.Add("J002", "Jeans Biru", "90000", "5", "C4");
            listProduct.Rows.Add("C001", "Celana Pendek Coklat", "60000", "11", "C4");
            listProduct.Rows.Add("C002", "Cawat Blink-Blink", "1000000", "1", "C5");
            listProduct.Rows.Add("R002", "Rocca Shirt", "50000", "8", "C2");
            listCategory.Rows.Add("C1", "Jas");
            listCategory.Rows.Add("C2", "T-Shirt");
            listCategory.Rows.Add("C3", "Rok");
            listCategory.Rows.Add("C4", "Jeans");
            listCategory.Rows.Add("C5", "Cawat");

            dg_category.DataSource = listCategory;
            dg_product.DataSource = listProduct;
        }

        DataTable listCategory = new DataTable();
        DataTable listProduct = new DataTable();
        DataTable filter = new DataTable();

        private void Form1_Load(object sender, EventArgs e)
        {
            
            foreach (DataRow dr in listCategory.Rows)
            {
                cb_categoryDetails.Items.Add(dr[0]);
            }
        }

        private void btn_addCategory_Click(object sender, EventArgs e)
        {
            if (tb_addCategory.Text != "")
            {
                foreach(DataRow cekKembar in listCategory.Rows)
                {
                    if (cekKembar[1].ToString() == tb_addCategory.Text.ToString())
                    {
                        MessageBox.Show("category sudah ada", "ERROR", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        return;
                    }
                }
                string cekHitung = listCategory.Rows[listCategory.Rows.Count - 1][0].ToString();
                int nilai = cekHitung[1] + 1 - '0';
                listCategory.Rows.Add($"C{nilai}", tb_addCategory.Text.ToString());
                cb_categoryDetails.Items.Add($"C{nilai}");
                dg_category.Refresh();
                tb_addCategory.Clear();
            }
            else
            {
                MessageBox.Show("Ngetik dulu bang", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error );
            }
        }

        private void btn_removeCategory_Click(object sender, EventArgs e)
        {
            bool hapus = false;
            string remove = "";
            foreach(DataRow dr in listCategory.Rows)
            {
                if (dr[1].ToString() == tb_addCategory.Text.ToString())
                {
                    hapus = true;
                    remove = dr[0].ToString();
                    listCategory.Rows.Remove(dr);
                    MessageBox.Show("category has succeesfully removed", "success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    dg_category.Refresh();
                    break;
                }
            }
            if (hapus)
            {
                cb_categoryDetails.Items.Remove(remove);
                filter = listProduct.Clone();
                foreach (DataRow row in listProduct.Rows)
                {
                    if (row[4].ToString() != remove)
                    {
                        filter.ImportRow(row);
                    }
                }
                listProduct = filter;
                dg_product.DataSource = filter;
            }
            Refresh();
        }

        private void btn_addProduct_Click(object sender, EventArgs e)
        {
            
            if (tb_namaDetails.Text != "" && tb_hargaDetails.Text != "" && tb_stockDetails.Text != "" && cb_categoryDetails.SelectedItem != null)
            {
                foreach (DataRow cekKembar in listProduct.Rows)
                {
                    if (cekKembar[1].ToString() == tb_namaDetails.Text.ToString())
                    {
                        MessageBox.Show("product sudah ada", "ERROR", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        return;
                    }
                }
                int ceksama = 1;
                string add = tb_namaDetails.Text[0].ToString().ToUpper();
                for (int i = 0;i < listProduct.Rows.Count; i++)
                {
                    if (listProduct.Rows[i][1].ToString() == tb_namaDetails.Text.ToString())
                    {
                        ceksama++;
                    }
                }
                listProduct.Rows.Add(add + "00" + ceksama, tb_namaDetails.Text.ToString(), tb_hargaDetails.Text.ToString(), 
                    tb_stockDetails.Text.ToString(), cb_categoryDetails.SelectedItem.ToString());
                dg_product.Refresh();
                tb_namaDetails.Clear();
                tb_hargaDetails.Clear();
                tb_stockDetails.Clear();
                cb_categoryDetails.SelectedIndex = -1;

            }
            else
            {
                MessageBox.Show("Ngetik dulu bang", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btn_editProduct_Click(object sender, EventArgs e)
        {
            if (tb_namaDetails.Text != "" && tb_hargaDetails.Text != "" && tb_stockDetails.Text != "" && cb_categoryDetails.SelectedItem != null)
            {
                int pilihan = dg_product.CurrentCell.RowIndex;
                string idProduct = listProduct.Rows[pilihan][0].ToString();
                string namaProduct = tb_namaDetails.Text.ToString();
                string harga = tb_hargaDetails.Text.ToString();
                string stock = tb_stockDetails.Text.ToString();
                string category = cb_categoryDetails.SelectedItem.ToString();
                foreach(DataRow dr in listCategory.Rows)
                {
                    if (dr[1].ToString() == category)
                    {
                        category = dr[0].ToString();
                    }
                }

                for(int i = 0; i < listProduct.Rows.Count; i++)
                {
                    if (listProduct.Rows[i][0].ToString() == idProduct)
                    {
                        listProduct.Rows[i][1] = namaProduct;
                        listProduct.Rows[i][2] = harga;
                        listProduct.Rows[i][3] = stock;
                        listProduct.Rows[i][4] = category;
                    }
                }
            }
            else
            {
                MessageBox.Show("Pilih dulu", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            Refresh();
            tb_namaDetails.Clear();
            tb_hargaDetails.Clear();
            tb_stockDetails.Clear();
            cb_categoryDetails.SelectedIndex = -1;
            dg_product.ClearSelection();

        }

        private void btn_removeProduct_Click(object sender, EventArgs e)
        {
            foreach (DataRow dr in listProduct.Rows)
            {
                if (dr[1].ToString() == tb_namaDetails.Text.ToString())
                {
                    listProduct.Rows.Remove(dr);
                    MessageBox.Show("product has succeesfully removed", "success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    dg_product.Refresh();
                    break;
                }
            }
            dg_product.Refresh();
            tb_namaDetails.Clear();
            tb_hargaDetails.Clear();
            tb_stockDetails.Clear();
            cb_categoryDetails.SelectedIndex = -1;
            Refresh();
        }

        private void btn_filter_Click(object sender, EventArgs e)
        {
            foreach (DataRow dr in listCategory.Rows)
            {
                cb_filter.Items.Add(dr[1]);
            }
            cb_filter.Enabled = true;
        }

        private void cb_filter_SelectedIndexChanged(object sender, EventArgs e)
        {
            string cek = "";
            string filtered = cb_filter.SelectedItem.ToString();
            foreach (DataRow dr in listCategory.Rows)
            {
                if (dr[1] == filtered)
                {
                    cek = dr[0].ToString();
                }
            }
            filter = listProduct.Clone();
            foreach (DataRow row in listProduct.Rows)
            {
                if (row[4].ToString() == cek)
                {
                    filter.ImportRow(row);
                }
            }
            dg_product.DataSource = filter;
        }

        private void btn_all_Click(object sender, EventArgs e)
        {
            cb_filter.Enabled = false;
            cb_filter.Items.Clear();
            dg_product.DataSource = listProduct;
        }

        private void tb_hargaDetails_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar) && (e.KeyChar != '.'))
            {
                e.Handled = true;
            }
            if ((e.KeyChar == '.') && ((sender as TextBox).Text.IndexOf('.') > -1))
            {
                e.Handled = true;
            }
        }

        private void tb_stockDetails_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar) && (e.KeyChar != '.'))
            {
                e.Handled = true;
            }

            if ((e.KeyChar == '.') && ((sender as TextBox).Text.IndexOf('.') > -1))
            {
                e.Handled = true;
            }
        }

        private void dg_category_CellMouseClick(object sender, DataGridViewCellMouseEventArgs e)
        {
            DataGridViewRow dgvr = dg_category.CurrentRow;
            if (e.RowIndex < dg_category.Rows.Count && e.RowIndex >= 0)
            {
                tb_addCategory.Text = dgvr.Cells[1].Value.ToString();
                Refresh();
            }
        }

        private void dg_product_CellMouseClick(object sender, DataGridViewCellMouseEventArgs e)
        {
            DataGridViewRow dgvr = dg_product.CurrentRow;
            if (e.RowIndex < dg_product.Rows.Count && e.RowIndex >= 0)
            {
                tb_namaDetails.Text = dgvr.Cells[1].Value.ToString();
                tb_hargaDetails.Text = dgvr.Cells[2].Value.ToString();
                tb_stockDetails.Text = dgvr.Cells[3].Value.ToString();
                cb_categoryDetails.Text = dgvr.Cells[4].Value.ToString();
                Refresh();
            }
        }
    }
}
