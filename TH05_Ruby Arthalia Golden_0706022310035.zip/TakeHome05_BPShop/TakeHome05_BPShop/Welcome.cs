﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace TakeHome05_BPShop
{
    public partial class Welcome : Form
    {
        public Welcome()
        {
            InitializeComponent();
        }

        private void tb_name_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                panel_awal.Visible = false;
                panel_next.Visible = true;
                if (tb_name.Text != "")
                {
                    lbl_name.Text = tb_name.Text;
                }
            }
        }
        private void ShowForm2()
        {
            shop frm = new shop();
            frm.Show();
            this.Hide();
        }

        private void btn_shop_Click(object sender, EventArgs e)
        {
            var frm = new shop();
            frm.Show();
            this.Hide();
        }

        private void btn_skip_Click(object sender, EventArgs e)
        {
            var frm = new shop();
            frm.Show();
            this.Hide();
        }
    }
}
