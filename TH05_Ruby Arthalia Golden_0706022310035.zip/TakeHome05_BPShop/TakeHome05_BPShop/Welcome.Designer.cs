﻿namespace TakeHome05_BPShop
{
    partial class Welcome
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lbl_welcome = new System.Windows.Forms.Label();
            this.lbl_entername = new System.Windows.Forms.Label();
            this.tb_name = new System.Windows.Forms.TextBox();
            this.lbl_enter = new System.Windows.Forms.Label();
            this.btn_skip = new System.Windows.Forms.Button();
            this.panel_awal = new System.Windows.Forms.Panel();
            this.lbl_name = new System.Windows.Forms.Label();
            this.btn_shop = new System.Windows.Forms.Button();
            this.panel_next = new System.Windows.Forms.Panel();
            this.panel_awal.SuspendLayout();
            this.panel_next.SuspendLayout();
            this.SuspendLayout();
            // 
            // lbl_welcome
            // 
            this.lbl_welcome.AutoSize = true;
            this.lbl_welcome.Font = new System.Drawing.Font("Palatino Linotype", 16F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_welcome.Location = new System.Drawing.Point(147, 88);
            this.lbl_welcome.Name = "lbl_welcome";
            this.lbl_welcome.Size = new System.Drawing.Size(291, 43);
            this.lbl_welcome.TabIndex = 0;
            this.lbl_welcome.Text = "Welcome to Ryuu\'s";
            // 
            // lbl_entername
            // 
            this.lbl_entername.AutoSize = true;
            this.lbl_entername.Location = new System.Drawing.Point(15, 2);
            this.lbl_entername.Name = "lbl_entername";
            this.lbl_entername.Size = new System.Drawing.Size(175, 20);
            this.lbl_entername.TabIndex = 1;
            this.lbl_entername.Text = "please enter your name";
            // 
            // tb_name
            // 
            this.tb_name.Location = new System.Drawing.Point(47, 25);
            this.tb_name.Name = "tb_name";
            this.tb_name.Size = new System.Drawing.Size(100, 26);
            this.tb_name.TabIndex = 2;
            this.tb_name.KeyDown += new System.Windows.Forms.KeyEventHandler(this.tb_name_KeyDown);
            // 
            // lbl_enter
            // 
            this.lbl_enter.AutoSize = true;
            this.lbl_enter.Location = new System.Drawing.Point(52, 54);
            this.lbl_enter.Name = "lbl_enter";
            this.lbl_enter.Size = new System.Drawing.Size(89, 20);
            this.lbl_enter.TabIndex = 3;
            this.lbl_enter.Text = "press enter";
            // 
            // btn_skip
            // 
            this.btn_skip.Location = new System.Drawing.Point(512, 12);
            this.btn_skip.Name = "btn_skip";
            this.btn_skip.Size = new System.Drawing.Size(76, 36);
            this.btn_skip.TabIndex = 4;
            this.btn_skip.Text = "skip";
            this.btn_skip.UseVisualStyleBackColor = true;
            this.btn_skip.Click += new System.EventHandler(this.btn_skip_Click);
            // 
            // panel_awal
            // 
            this.panel_awal.Controls.Add(this.lbl_enter);
            this.panel_awal.Controls.Add(this.tb_name);
            this.panel_awal.Controls.Add(this.lbl_entername);
            this.panel_awal.Location = new System.Drawing.Point(187, 145);
            this.panel_awal.Name = "panel_awal";
            this.panel_awal.Size = new System.Drawing.Size(207, 88);
            this.panel_awal.TabIndex = 5;
            // 
            // lbl_name
            // 
            this.lbl_name.AutoSize = true;
            this.lbl_name.Font = new System.Drawing.Font("Modern No. 20", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_name.Location = new System.Drawing.Point(45, 6);
            this.lbl_name.Name = "lbl_name";
            this.lbl_name.Size = new System.Drawing.Size(64, 37);
            this.lbl_name.TabIndex = 6;
            this.lbl_name.Text = ". . .";
            // 
            // btn_shop
            // 
            this.btn_shop.Location = new System.Drawing.Point(19, 46);
            this.btn_shop.Name = "btn_shop";
            this.btn_shop.Size = new System.Drawing.Size(103, 34);
            this.btn_shop.TabIndex = 7;
            this.btn_shop.Text = "shop now !!";
            this.btn_shop.UseVisualStyleBackColor = true;
            this.btn_shop.Click += new System.EventHandler(this.btn_shop_Click);
            // 
            // panel_next
            // 
            this.panel_next.Controls.Add(this.btn_shop);
            this.panel_next.Controls.Add(this.lbl_name);
            this.panel_next.Location = new System.Drawing.Point(206, 145);
            this.panel_next.Name = "panel_next";
            this.panel_next.Size = new System.Drawing.Size(171, 136);
            this.panel_next.TabIndex = 8;
            this.panel_next.Visible = false;
            // 
            // Welcome
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.ClientSize = new System.Drawing.Size(600, 317);
            this.Controls.Add(this.panel_next);
            this.Controls.Add(this.panel_awal);
            this.Controls.Add(this.btn_skip);
            this.Controls.Add(this.lbl_welcome);
            this.Name = "Welcome";
            this.Text = "Welcome";
            this.panel_awal.ResumeLayout(false);
            this.panel_awal.PerformLayout();
            this.panel_next.ResumeLayout(false);
            this.panel_next.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lbl_welcome;
        private System.Windows.Forms.Label lbl_entername;
        private System.Windows.Forms.TextBox tb_name;
        private System.Windows.Forms.Label lbl_enter;
        private System.Windows.Forms.Button btn_skip;
        private System.Windows.Forms.Panel panel_awal;
        private System.Windows.Forms.Label lbl_name;
        private System.Windows.Forms.Button btn_shop;
        private System.Windows.Forms.Panel panel_next;
    }
}