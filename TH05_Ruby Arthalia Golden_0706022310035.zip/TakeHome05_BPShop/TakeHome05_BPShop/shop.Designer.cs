﻿namespace TakeHome05_BPShop
{
    partial class shop
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(shop));
            this.dg_product = new System.Windows.Forms.DataGridView();
            this.dg_category = new System.Windows.Forms.DataGridView();
            this.cb_filter = new System.Windows.Forms.ComboBox();
            this.lbl_category = new System.Windows.Forms.Label();
            this.lbl_details = new System.Windows.Forms.Label();
            this.lbl_product = new System.Windows.Forms.Label();
            this.lbl_namaC = new System.Windows.Forms.Label();
            this.lbl_namaD = new System.Windows.Forms.Label();
            this.lbl_cat = new System.Windows.Forms.Label();
            this.lbl_harga = new System.Windows.Forms.Label();
            this.lbl_stock = new System.Windows.Forms.Label();
            this.cb_categoryDetails = new System.Windows.Forms.ComboBox();
            this.tb_hargaDetails = new System.Windows.Forms.TextBox();
            this.tb_stockDetails = new System.Windows.Forms.TextBox();
            this.tb_namaDetails = new System.Windows.Forms.TextBox();
            this.btn_addProduct = new System.Windows.Forms.Button();
            this.btn_editProduct = new System.Windows.Forms.Button();
            this.btn_removeProduct = new System.Windows.Forms.Button();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.dateTimePicker1 = new System.Windows.Forms.DateTimePicker();
            this.btn_removeCategory = new System.Windows.Forms.Button();
            this.btn_addCategory = new System.Windows.Forms.Button();
            this.btn_all = new System.Windows.Forms.Button();
            this.btn_filter = new System.Windows.Forms.Button();
            this.tb_addCategory = new System.Windows.Forms.TextBox();
            ((System.ComponentModel.ISupportInitialize)(this.dg_product)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dg_category)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // dg_product
            // 
            this.dg_product.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dg_product.Location = new System.Drawing.Point(32, 69);
            this.dg_product.Name = "dg_product";
            this.dg_product.RowHeadersWidth = 62;
            this.dg_product.RowTemplate.Height = 28;
            this.dg_product.Size = new System.Drawing.Size(635, 411);
            this.dg_product.TabIndex = 0;
            this.dg_product.CellMouseClick += new System.Windows.Forms.DataGridViewCellMouseEventHandler(this.dg_product_CellMouseClick);
            // 
            // dg_category
            // 
            this.dg_category.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dg_category.Location = new System.Drawing.Point(704, 69);
            this.dg_category.Name = "dg_category";
            this.dg_category.RowHeadersWidth = 62;
            this.dg_category.RowTemplate.Height = 28;
            this.dg_category.Size = new System.Drawing.Size(402, 341);
            this.dg_category.TabIndex = 1;
            this.dg_category.CellMouseClick += new System.Windows.Forms.DataGridViewCellMouseEventHandler(this.dg_category_CellMouseClick);
            // 
            // cb_filter
            // 
            this.cb_filter.Enabled = false;
            this.cb_filter.FormattingEnabled = true;
            this.cb_filter.Location = new System.Drawing.Point(529, 31);
            this.cb_filter.Name = "cb_filter";
            this.cb_filter.Size = new System.Drawing.Size(137, 28);
            this.cb_filter.TabIndex = 2;
            this.cb_filter.SelectedIndexChanged += new System.EventHandler(this.cb_filter_SelectedIndexChanged);
            // 
            // lbl_category
            // 
            this.lbl_category.AutoSize = true;
            this.lbl_category.Font = new System.Drawing.Font("Times New Roman", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_category.Location = new System.Drawing.Point(698, 24);
            this.lbl_category.Name = "lbl_category";
            this.lbl_category.Size = new System.Drawing.Size(123, 32);
            this.lbl_category.TabIndex = 4;
            this.lbl_category.Text = "Category";
            // 
            // lbl_details
            // 
            this.lbl_details.AutoSize = true;
            this.lbl_details.Font = new System.Drawing.Font("Times New Roman", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_details.Location = new System.Drawing.Point(38, 504);
            this.lbl_details.Name = "lbl_details";
            this.lbl_details.Size = new System.Drawing.Size(96, 32);
            this.lbl_details.TabIndex = 5;
            this.lbl_details.Text = "Details";
            // 
            // lbl_product
            // 
            this.lbl_product.AutoSize = true;
            this.lbl_product.Font = new System.Drawing.Font("Times New Roman", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_product.Location = new System.Drawing.Point(26, 24);
            this.lbl_product.Name = "lbl_product";
            this.lbl_product.Size = new System.Drawing.Size(110, 32);
            this.lbl_product.TabIndex = 6;
            this.lbl_product.Text = "Product";
            // 
            // lbl_namaC
            // 
            this.lbl_namaC.AutoSize = true;
            this.lbl_namaC.Location = new System.Drawing.Point(738, 428);
            this.lbl_namaC.Name = "lbl_namaC";
            this.lbl_namaC.Size = new System.Drawing.Size(59, 20);
            this.lbl_namaC.TabIndex = 7;
            this.lbl_namaC.Text = "Nama :";
            // 
            // lbl_namaD
            // 
            this.lbl_namaD.AutoSize = true;
            this.lbl_namaD.Location = new System.Drawing.Point(62, 548);
            this.lbl_namaD.Name = "lbl_namaD";
            this.lbl_namaD.Size = new System.Drawing.Size(59, 20);
            this.lbl_namaD.TabIndex = 8;
            this.lbl_namaD.Text = "Nama :";
            // 
            // lbl_cat
            // 
            this.lbl_cat.AutoSize = true;
            this.lbl_cat.Location = new System.Drawing.Point(40, 577);
            this.lbl_cat.Name = "lbl_cat";
            this.lbl_cat.Size = new System.Drawing.Size(81, 20);
            this.lbl_cat.TabIndex = 9;
            this.lbl_cat.Text = "Category :";
            // 
            // lbl_harga
            // 
            this.lbl_harga.AutoSize = true;
            this.lbl_harga.Location = new System.Drawing.Point(60, 614);
            this.lbl_harga.Name = "lbl_harga";
            this.lbl_harga.Size = new System.Drawing.Size(61, 20);
            this.lbl_harga.TabIndex = 10;
            this.lbl_harga.Text = "Harga :";
            // 
            // lbl_stock
            // 
            this.lbl_stock.AutoSize = true;
            this.lbl_stock.Location = new System.Drawing.Point(63, 646);
            this.lbl_stock.Name = "lbl_stock";
            this.lbl_stock.Size = new System.Drawing.Size(58, 20);
            this.lbl_stock.TabIndex = 11;
            this.lbl_stock.Text = "Stock :";
            // 
            // cb_categoryDetails
            // 
            this.cb_categoryDetails.FormattingEnabled = true;
            this.cb_categoryDetails.Location = new System.Drawing.Point(127, 574);
            this.cb_categoryDetails.Name = "cb_categoryDetails";
            this.cb_categoryDetails.Size = new System.Drawing.Size(137, 28);
            this.cb_categoryDetails.TabIndex = 12;
            // 
            // tb_hargaDetails
            // 
            this.tb_hargaDetails.Location = new System.Drawing.Point(127, 608);
            this.tb_hargaDetails.Name = "tb_hargaDetails";
            this.tb_hargaDetails.Size = new System.Drawing.Size(137, 26);
            this.tb_hargaDetails.TabIndex = 13;
            this.tb_hargaDetails.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.tb_hargaDetails_KeyPress);
            // 
            // tb_stockDetails
            // 
            this.tb_stockDetails.Location = new System.Drawing.Point(127, 640);
            this.tb_stockDetails.Name = "tb_stockDetails";
            this.tb_stockDetails.Size = new System.Drawing.Size(137, 26);
            this.tb_stockDetails.TabIndex = 14;
            this.tb_stockDetails.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.tb_stockDetails_KeyPress);
            // 
            // tb_namaDetails
            // 
            this.tb_namaDetails.Location = new System.Drawing.Point(127, 542);
            this.tb_namaDetails.Name = "tb_namaDetails";
            this.tb_namaDetails.Size = new System.Drawing.Size(384, 26);
            this.tb_namaDetails.TabIndex = 15;
            // 
            // btn_addProduct
            // 
            this.btn_addProduct.BackColor = System.Drawing.Color.Lime;
            this.btn_addProduct.ForeColor = System.Drawing.Color.Black;
            this.btn_addProduct.Location = new System.Drawing.Point(270, 591);
            this.btn_addProduct.Name = "btn_addProduct";
            this.btn_addProduct.Size = new System.Drawing.Size(82, 61);
            this.btn_addProduct.TabIndex = 16;
            this.btn_addProduct.Text = "Add Product";
            this.btn_addProduct.UseVisualStyleBackColor = false;
            this.btn_addProduct.Click += new System.EventHandler(this.btn_addProduct_Click);
            // 
            // btn_editProduct
            // 
            this.btn_editProduct.BackColor = System.Drawing.Color.Yellow;
            this.btn_editProduct.Location = new System.Drawing.Point(358, 591);
            this.btn_editProduct.Name = "btn_editProduct";
            this.btn_editProduct.Size = new System.Drawing.Size(82, 61);
            this.btn_editProduct.TabIndex = 17;
            this.btn_editProduct.Text = "Edit Product";
            this.btn_editProduct.UseVisualStyleBackColor = false;
            this.btn_editProduct.Click += new System.EventHandler(this.btn_editProduct_Click);
            // 
            // btn_removeProduct
            // 
            this.btn_removeProduct.BackColor = System.Drawing.Color.Red;
            this.btn_removeProduct.Location = new System.Drawing.Point(446, 591);
            this.btn_removeProduct.Name = "btn_removeProduct";
            this.btn_removeProduct.Size = new System.Drawing.Size(82, 61);
            this.btn_removeProduct.TabIndex = 18;
            this.btn_removeProduct.Text = "Remove Product";
            this.btn_removeProduct.UseVisualStyleBackColor = false;
            this.btn_removeProduct.Click += new System.EventHandler(this.btn_removeProduct_Click);
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(753, 548);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(298, 207);
            this.pictureBox1.TabIndex = 19;
            this.pictureBox1.TabStop = false;
            // 
            // dateTimePicker1
            // 
            this.dateTimePicker1.Location = new System.Drawing.Point(1041, 711);
            this.dateTimePicker1.Name = "dateTimePicker1";
            this.dateTimePicker1.Size = new System.Drawing.Size(10, 26);
            this.dateTimePicker1.TabIndex = 20;
            this.dateTimePicker1.Value = new System.DateTime(2024, 3, 25, 15, 57, 40, 0);
            // 
            // btn_removeCategory
            // 
            this.btn_removeCategory.BackColor = System.Drawing.Color.Red;
            this.btn_removeCategory.Location = new System.Drawing.Point(915, 459);
            this.btn_removeCategory.Name = "btn_removeCategory";
            this.btn_removeCategory.Size = new System.Drawing.Size(99, 61);
            this.btn_removeCategory.TabIndex = 22;
            this.btn_removeCategory.Text = "Remove Category";
            this.btn_removeCategory.UseVisualStyleBackColor = false;
            this.btn_removeCategory.Click += new System.EventHandler(this.btn_removeCategory_Click);
            // 
            // btn_addCategory
            // 
            this.btn_addCategory.BackColor = System.Drawing.Color.Lime;
            this.btn_addCategory.ForeColor = System.Drawing.Color.Black;
            this.btn_addCategory.Location = new System.Drawing.Point(814, 459);
            this.btn_addCategory.Name = "btn_addCategory";
            this.btn_addCategory.Size = new System.Drawing.Size(95, 61);
            this.btn_addCategory.TabIndex = 21;
            this.btn_addCategory.Text = "Add Category";
            this.btn_addCategory.UseVisualStyleBackColor = false;
            this.btn_addCategory.Click += new System.EventHandler(this.btn_addCategory_Click);
            // 
            // btn_all
            // 
            this.btn_all.Font = new System.Drawing.Font("Microsoft Tai Le", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_all.Location = new System.Drawing.Point(397, 24);
            this.btn_all.Name = "btn_all";
            this.btn_all.Size = new System.Drawing.Size(54, 35);
            this.btn_all.TabIndex = 23;
            this.btn_all.Text = "ALL";
            this.btn_all.UseVisualStyleBackColor = true;
            this.btn_all.Click += new System.EventHandler(this.btn_all_Click);
            // 
            // btn_filter
            // 
            this.btn_filter.Font = new System.Drawing.Font("Microsoft Tai Le", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_filter.Location = new System.Drawing.Point(453, 24);
            this.btn_filter.Name = "btn_filter";
            this.btn_filter.Size = new System.Drawing.Size(70, 35);
            this.btn_filter.TabIndex = 24;
            this.btn_filter.Text = "FILTER";
            this.btn_filter.UseVisualStyleBackColor = true;
            this.btn_filter.Click += new System.EventHandler(this.btn_filter_Click);
            // 
            // tb_addCategory
            // 
            this.tb_addCategory.Location = new System.Drawing.Point(814, 422);
            this.tb_addCategory.Name = "tb_addCategory";
            this.tb_addCategory.Size = new System.Drawing.Size(200, 26);
            this.tb_addCategory.TabIndex = 25;
            // 
            // shop
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.ClientSize = new System.Drawing.Size(1145, 840);
            this.Controls.Add(this.tb_addCategory);
            this.Controls.Add(this.btn_filter);
            this.Controls.Add(this.btn_all);
            this.Controls.Add(this.btn_removeCategory);
            this.Controls.Add(this.btn_addCategory);
            this.Controls.Add(this.dateTimePicker1);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.btn_removeProduct);
            this.Controls.Add(this.btn_editProduct);
            this.Controls.Add(this.btn_addProduct);
            this.Controls.Add(this.tb_namaDetails);
            this.Controls.Add(this.tb_stockDetails);
            this.Controls.Add(this.tb_hargaDetails);
            this.Controls.Add(this.cb_categoryDetails);
            this.Controls.Add(this.lbl_stock);
            this.Controls.Add(this.lbl_harga);
            this.Controls.Add(this.lbl_cat);
            this.Controls.Add(this.lbl_namaD);
            this.Controls.Add(this.lbl_namaC);
            this.Controls.Add(this.lbl_product);
            this.Controls.Add(this.lbl_details);
            this.Controls.Add(this.lbl_category);
            this.Controls.Add(this.cb_filter);
            this.Controls.Add(this.dg_category);
            this.Controls.Add(this.dg_product);
            this.Name = "shop";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dg_product)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dg_category)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.DataGridView dg_product;
        private System.Windows.Forms.DataGridView dg_category;
        private System.Windows.Forms.ComboBox cb_filter;
        private System.Windows.Forms.Label lbl_category;
        private System.Windows.Forms.Label lbl_details;
        private System.Windows.Forms.Label lbl_product;
        private System.Windows.Forms.Label lbl_namaC;
        private System.Windows.Forms.Label lbl_namaD;
        private System.Windows.Forms.Label lbl_cat;
        private System.Windows.Forms.Label lbl_harga;
        private System.Windows.Forms.Label lbl_stock;
        private System.Windows.Forms.ComboBox cb_categoryDetails;
        private System.Windows.Forms.TextBox tb_hargaDetails;
        private System.Windows.Forms.TextBox tb_stockDetails;
        private System.Windows.Forms.TextBox tb_namaDetails;
        private System.Windows.Forms.Button btn_addProduct;
        private System.Windows.Forms.Button btn_editProduct;
        private System.Windows.Forms.Button btn_removeProduct;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.DateTimePicker dateTimePicker1;
        private System.Windows.Forms.Button btn_removeCategory;
        private System.Windows.Forms.Button btn_addCategory;
        private System.Windows.Forms.Button btn_all;
        private System.Windows.Forms.Button btn_filter;
        private System.Windows.Forms.TextBox tb_addCategory;
    }
}

