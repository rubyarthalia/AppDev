﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Security.Policy;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace ruby_punya_th04
{
    public partial class Form1 : Form
    {
        DataTable listTeam = new DataTable();
        public DataRow [] listpemain;
        public Form1()
        {
            InitializeComponent();
        }

        private void btn_Remove_Click(object sender, EventArgs e)
        {
            if (lBox_ListTeam.Items.Count < 12 && lBox_ListTeam.SelectedItem == null)
            {
                MessageBox.Show("Total player cannot be less than 11", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }

            else if (lBox_ListTeam.SelectedItem != null && lBox_ListTeam.Items.Count > 11)
            {
                DataRow[] playerToRemove = listTeam.Select($"[Player Number] = '{listTeam.Rows[3]}'");
                if (playerToRemove.Length > 0)
                {
                    listTeam.Rows.Remove(playerToRemove[0]);
                }
                lBox_ListTeam.Items.Remove(lBox_ListTeam.SelectedItem);
                return;
            }
            if (lBox_ListTeam.SelectedItem  == null)
            {
                MessageBox.Show("Please select a player to remove", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            lBox_ListTeam.SelectedItems.Clear();
        }

        private void btn_addTeam_Click(object sender, EventArgs e)
        {
            if (tb_TName.Text != "" || tb_TCountry.Text != "" || tb_TCity.Text != "")
            {
                foreach (DataRow twin in listTeam.Rows)
                {
                    if (tb_TName.Text == twin["Team Name"] && tb_TCountry.Text == twin["Team Country"])
                    {
                        MessageBox.Show("Team already existed","Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        break;
                    }
                }
                listTeam.Rows.Add(tb_TName.Text, tb_TCountry.Text, tb_TCity.Text, "", "00", "");
                combo_team.Items.Add(tb_TName.Text);
                if (!combo_country.Items.Contains(tb_TCountry.Text))
                {
                    combo_country.Items.Add(tb_TCountry.Text);
                }

                tb_TCity.Clear();
                tb_TCountry.Clear();
                tb_TName.Clear();
            }
            else 
            {
                MessageBox.Show("All fields need to be field", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }
            combo_team.Items.Clear();
        }

        private void btn_addPlayer_Click(object sender, EventArgs e)
        {
            if (combo_country.SelectedItem == null || combo_team.SelectedItem == null)
            {
                MessageBox.Show("Please choose where the player from first", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            else if (tb_PName.Text != "" || tb_PNumber.Text != "" || cb_PPosition.SelectedItem.ToString() != "")
            {
                DataRow[] pilihan = listTeam.Select($"[Team name] = '{combo_team.SelectedItem.ToString()}' AND [Team Country] = '{combo_country.SelectedItem.ToString()}'");
                foreach (DataRow twin in listTeam.Rows)
                {
                    if (tb_PName.Text == twin["Player Name"])
                    {
                        if (tb_PNumber.Text == twin["Player Number"])
                        {
                            MessageBox.Show("Player already existed", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        }
                    }
                }
                DataRow playerBaru = listTeam.NewRow();
                playerBaru["Team Name"] = pilihan[0]["Team Name"];
                playerBaru["Team Country"] = pilihan[0]["Team Country"];
                playerBaru["Team City"] =pilihan[0]["Team City"];
                playerBaru["Player Name"] = tb_PName.Text;
                playerBaru["Player Number"] = tb_PNumber.Text;
                playerBaru["Player Position"] = cb_PPosition.SelectedItem.ToString();
                listTeam.Rows.Add(playerBaru);
                lBox_ListTeam.Items.Add($"({tb_PNumber.Text}) {tb_PName.Text}, {cb_PPosition.SelectedItem.ToString()}");
            }
            else
            {
                MessageBox.Show("All fields need to be field", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }
            cb_PPosition.SelectedItem = null;
            tb_PName.Clear();
            tb_PNumber.Clear();
        }

        private void combo_country_SelectedIndexChanged(object sender, EventArgs e)
        {
            combo_team.Items.Clear();
            foreach (DataRow cek in listTeam.Rows)
            {
                if (cek["Team Country"].ToString() == combo_country.SelectedItem.ToString())
                {
                    string team = cek["Team Name"].ToString();
                    if (!combo_team.Items.Contains(team))
                    {
                        combo_team.Items.Add(team);
                    }
                }
            }

        }

        private void combo_team_SelectedIndexChanged(object sender, EventArgs e)
        {
            lBox_ListTeam.Items.Clear();
            listpemain = listTeam.Select($"[Team Name] = '{combo_team.SelectedItem.ToString()}'");
            foreach (DataRow isi in listpemain)
            {
                lBox_ListTeam.Items.Add($"({isi["Player Number"]}) {isi["Player Name"]}, {isi["Player Position"]}");
            }
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            listTeam.Columns.Add("Team Name", typeof(string));
            listTeam.Columns.Add("Team Country", typeof(string));
            listTeam.Columns.Add("Team City", typeof(string));
            listTeam.Columns.Add("Player Name", typeof(string));
            listTeam.Columns.Add("Player Number", typeof(string));
            listTeam.Columns.Add("Player Position", typeof(string));

            listTeam.Rows.Add("Manchester United", "England", "Manchester", "David De Gea", "01", "GK");
            listTeam.Rows.Add("Manchester United", "England", "Manchester", "Victor Lindelof", "02", "DF");
            listTeam.Rows.Add("Manchester United", "England", "Manchester", "Phil Jones", "04", "DF");
            listTeam.Rows.Add("Manchester United", "England", "Manchester", "Harry Maguire", "05", "DF");
            listTeam.Rows.Add("Manchester United", "England", "Manchester", "Lisandro Martinez", "06", "DF");
            listTeam.Rows.Add("Manchester United", "England", "Manchester", "Bruno Fernandez", "08", "MF");
            listTeam.Rows.Add("Manchester United", "England", "Manchester", "Anthony Martial", "09", "FW");
            listTeam.Rows.Add("Manchester United", "England", "Manchester", "Marcus Rashford", "10", "FW");
            listTeam.Rows.Add("Manchester United", "England", "Manchester", "Tyrell Malacia", "12", "DF");
            listTeam.Rows.Add("Manchester United", "England", "Manchester", "Christian Eriksen", "14", "MF");
            listTeam.Rows.Add("Manchester United", "England", "Manchester", "Casemiro", "18", "MF");

            listTeam.Rows.Add("Chelsea", "England", "Fulham", "Kepa Arrizabalaga", "01", "GK");
            listTeam.Rows.Add("Chelsea", "England", "Fulham", "Benoit Badaiashile", "04", "DF");
            listTeam.Rows.Add("Chelsea", "England", "Fulham", "Enzo Fernandez", "05", "MF");
            listTeam.Rows.Add("Chelsea", "England", "Fulham", "Thiago Silva", "61", "DF");
            listTeam.Rows.Add("Chelsea", "England", "Fulham", "N'Golo Kante", "07", "MF");
            listTeam.Rows.Add("Chelsea", "England", "Fulham", "Pierre-Emerick Aubameyang", "09", "FW");
            listTeam.Rows.Add("Chelsea", "England", "Fulham", "Christian Pulisic", "10", "MF");
            listTeam.Rows.Add("Chelsea", "England", "Fulham", "Joao Felix", "11", "FW");
            listTeam.Rows.Add("Chelsea", "England", "Fulham", "Ruben Loftus-Cheek", "12", "MF");
            listTeam.Rows.Add("Chelsea", "England", "Fulham", "Raheem Sterling", "17", "MF");

            listTeam.Rows.Add("Bayern Munich", "Germany", "Munich", "Manuel Neuer", "01", "GK");
            listTeam.Rows.Add("Bayern Munich", "Germany", "Munich", "Dayot Upamecano", "02", "DF");
            listTeam.Rows.Add("Bayern Munich", "Germany", "Munich", "Matthijis de Ligt", "04", "DF");
            listTeam.Rows.Add("Bayern Munich", "Germany", "Munich", "Benjamin Pavard", "05", "DF");
            listTeam.Rows.Add("Bayern Munich", "Germany", "Munich", "Joshua Kimmich", "06", "MF");
            listTeam.Rows.Add("Bayern Munich", "Germany", "Munich", "Serge Gnabry", "07", "FW");
            listTeam.Rows.Add("Bayern Munich", "Germany", "Munich", "Leon Goretzka", "08", "MF");
            listTeam.Rows.Add("Bayern Munich", "Germany", "Munich", "Leroy Sane", "10", "FW");
            listTeam.Rows.Add("Bayern Munich", "Germany", "Munich", "Paul Wanner", "14", "MF");
            listTeam.Rows.Add("Bayern Munich", "Germany", "Munich", "Lucas Hernandez", "21", "DF");
            listTeam.Rows.Add("Bayern Munich", "Germany", "Munich", "Thomas Muller", "25", "FW");
        }
    }
}
