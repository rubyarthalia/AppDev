﻿namespace ruby_punya_th04
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btn_Remove = new System.Windows.Forms.Button();
            this.btn_addTeam = new System.Windows.Forms.Button();
            this.btn_addPlayer = new System.Windows.Forms.Button();
            this.lBox_ListTeam = new System.Windows.Forms.ListBox();
            this.lbl_TName = new System.Windows.Forms.Label();
            this.tb_TName = new System.Windows.Forms.TextBox();
            this.tb_TCountry = new System.Windows.Forms.TextBox();
            this.lbl_TCountry = new System.Windows.Forms.Label();
            this.tb_TCity = new System.Windows.Forms.TextBox();
            this.lbl_TCity = new System.Windows.Forms.Label();
            this.lbl_PPosition = new System.Windows.Forms.Label();
            this.tb_PNumber = new System.Windows.Forms.TextBox();
            this.lbl_PNumber = new System.Windows.Forms.Label();
            this.tb_PName = new System.Windows.Forms.TextBox();
            this.lbl_PName = new System.Windows.Forms.Label();
            this.lbl_addTeam = new System.Windows.Forms.Label();
            this.lbl_addPlayer = new System.Windows.Forms.Label();
            this.lbl_List = new System.Windows.Forms.Label();
            this.lbl_ChooseCountry = new System.Windows.Forms.Label();
            this.combo_country = new System.Windows.Forms.ComboBox();
            this.combo_team = new System.Windows.Forms.ComboBox();
            this.lbl_ChooseTeam = new System.Windows.Forms.Label();
            this.cb_PPosition = new System.Windows.Forms.ComboBox();
            this.SuspendLayout();
            // 
            // btn_Remove
            // 
            this.btn_Remove.Location = new System.Drawing.Point(56, 334);
            this.btn_Remove.Name = "btn_Remove";
            this.btn_Remove.Size = new System.Drawing.Size(92, 38);
            this.btn_Remove.TabIndex = 0;
            this.btn_Remove.Text = "REMOVE";
            this.btn_Remove.UseVisualStyleBackColor = true;
            this.btn_Remove.Click += new System.EventHandler(this.btn_Remove_Click);
            // 
            // btn_addTeam
            // 
            this.btn_addTeam.Location = new System.Drawing.Point(587, 259);
            this.btn_addTeam.Name = "btn_addTeam";
            this.btn_addTeam.Size = new System.Drawing.Size(87, 38);
            this.btn_addTeam.TabIndex = 1;
            this.btn_addTeam.Text = "ADD";
            this.btn_addTeam.UseVisualStyleBackColor = true;
            this.btn_addTeam.Click += new System.EventHandler(this.btn_addTeam_Click);
            // 
            // btn_addPlayer
            // 
            this.btn_addPlayer.Location = new System.Drawing.Point(947, 259);
            this.btn_addPlayer.Name = "btn_addPlayer";
            this.btn_addPlayer.Size = new System.Drawing.Size(87, 38);
            this.btn_addPlayer.TabIndex = 2;
            this.btn_addPlayer.Text = "ADD";
            this.btn_addPlayer.UseVisualStyleBackColor = true;
            this.btn_addPlayer.Click += new System.EventHandler(this.btn_addPlayer_Click);
            // 
            // lBox_ListTeam
            // 
            this.lBox_ListTeam.FormattingEnabled = true;
            this.lBox_ListTeam.ItemHeight = 20;
            this.lBox_ListTeam.Location = new System.Drawing.Point(56, 204);
            this.lBox_ListTeam.Name = "lBox_ListTeam";
            this.lBox_ListTeam.Size = new System.Drawing.Size(291, 124);
            this.lBox_ListTeam.TabIndex = 3;
            // 
            // lbl_TName
            // 
            this.lbl_TName.AutoSize = true;
            this.lbl_TName.Location = new System.Drawing.Point(423, 122);
            this.lbl_TName.Name = "lbl_TName";
            this.lbl_TName.Size = new System.Drawing.Size(103, 20);
            this.lbl_TName.TabIndex = 4;
            this.lbl_TName.Text = "Team Name :";
            // 
            // tb_TName
            // 
            this.tb_TName.Location = new System.Drawing.Point(547, 116);
            this.tb_TName.Name = "tb_TName";
            this.tb_TName.Size = new System.Drawing.Size(172, 26);
            this.tb_TName.TabIndex = 5;
            // 
            // tb_TCountry
            // 
            this.tb_TCountry.Location = new System.Drawing.Point(547, 159);
            this.tb_TCountry.Name = "tb_TCountry";
            this.tb_TCountry.Size = new System.Drawing.Size(172, 26);
            this.tb_TCountry.TabIndex = 7;
            // 
            // lbl_TCountry
            // 
            this.lbl_TCountry.AutoSize = true;
            this.lbl_TCountry.Location = new System.Drawing.Point(423, 165);
            this.lbl_TCountry.Name = "lbl_TCountry";
            this.lbl_TCountry.Size = new System.Drawing.Size(116, 20);
            this.lbl_TCountry.TabIndex = 6;
            this.lbl_TCountry.Text = "Team Country :";
            // 
            // tb_TCity
            // 
            this.tb_TCity.Location = new System.Drawing.Point(547, 204);
            this.tb_TCity.Name = "tb_TCity";
            this.tb_TCity.Size = new System.Drawing.Size(172, 26);
            this.tb_TCity.TabIndex = 9;
            // 
            // lbl_TCity
            // 
            this.lbl_TCity.AutoSize = true;
            this.lbl_TCity.Location = new System.Drawing.Point(423, 210);
            this.lbl_TCity.Name = "lbl_TCity";
            this.lbl_TCity.Size = new System.Drawing.Size(87, 20);
            this.lbl_TCity.TabIndex = 8;
            this.lbl_TCity.Text = "Team City :";
            // 
            // lbl_PPosition
            // 
            this.lbl_PPosition.AutoSize = true;
            this.lbl_PPosition.Location = new System.Drawing.Point(782, 210);
            this.lbl_PPosition.Name = "lbl_PPosition";
            this.lbl_PPosition.Size = new System.Drawing.Size(120, 20);
            this.lbl_PPosition.TabIndex = 14;
            this.lbl_PPosition.Text = "Player Position :";
            // 
            // tb_PNumber
            // 
            this.tb_PNumber.Location = new System.Drawing.Point(906, 159);
            this.tb_PNumber.Name = "tb_PNumber";
            this.tb_PNumber.Size = new System.Drawing.Size(172, 26);
            this.tb_PNumber.TabIndex = 13;
            // 
            // lbl_PNumber
            // 
            this.lbl_PNumber.AutoSize = true;
            this.lbl_PNumber.Location = new System.Drawing.Point(782, 165);
            this.lbl_PNumber.Name = "lbl_PNumber";
            this.lbl_PNumber.Size = new System.Drawing.Size(120, 20);
            this.lbl_PNumber.TabIndex = 12;
            this.lbl_PNumber.Text = "Player Number :";
            // 
            // tb_PName
            // 
            this.tb_PName.Location = new System.Drawing.Point(906, 116);
            this.tb_PName.Name = "tb_PName";
            this.tb_PName.Size = new System.Drawing.Size(172, 26);
            this.tb_PName.TabIndex = 11;
            // 
            // lbl_PName
            // 
            this.lbl_PName.AutoSize = true;
            this.lbl_PName.Location = new System.Drawing.Point(782, 122);
            this.lbl_PName.Name = "lbl_PName";
            this.lbl_PName.Size = new System.Drawing.Size(106, 20);
            this.lbl_PName.TabIndex = 10;
            this.lbl_PName.Text = "Player Name :";
            // 
            // lbl_addTeam
            // 
            this.lbl_addTeam.AutoSize = true;
            this.lbl_addTeam.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_addTeam.Location = new System.Drawing.Point(422, 79);
            this.lbl_addTeam.Name = "lbl_addTeam";
            this.lbl_addTeam.Size = new System.Drawing.Size(141, 25);
            this.lbl_addTeam.TabIndex = 16;
            this.lbl_addTeam.Text = "Adding Team";
            // 
            // lbl_addPlayer
            // 
            this.lbl_addPlayer.AutoSize = true;
            this.lbl_addPlayer.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_addPlayer.Location = new System.Drawing.Point(781, 79);
            this.lbl_addPlayer.Name = "lbl_addPlayer";
            this.lbl_addPlayer.Size = new System.Drawing.Size(147, 25);
            this.lbl_addPlayer.TabIndex = 17;
            this.lbl_addPlayer.Text = "Adding Player";
            // 
            // lbl_List
            // 
            this.lbl_List.AutoSize = true;
            this.lbl_List.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_List.Location = new System.Drawing.Point(51, 68);
            this.lbl_List.Name = "lbl_List";
            this.lbl_List.Size = new System.Drawing.Size(181, 25);
            this.lbl_List.TabIndex = 18;
            this.lbl_List.Text = "Soccer Team List";
            // 
            // lbl_ChooseCountry
            // 
            this.lbl_ChooseCountry.AutoSize = true;
            this.lbl_ChooseCountry.Location = new System.Drawing.Point(52, 122);
            this.lbl_ChooseCountry.Name = "lbl_ChooseCountry";
            this.lbl_ChooseCountry.Size = new System.Drawing.Size(131, 20);
            this.lbl_ChooseCountry.TabIndex = 19;
            this.lbl_ChooseCountry.Text = "Choose Country :";
            // 
            // combo_country
            // 
            this.combo_country.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.combo_country.FormattingEnabled = true;
            this.combo_country.Items.AddRange(new object[] {
            "England",
            "Germany"});
            this.combo_country.Location = new System.Drawing.Point(191, 119);
            this.combo_country.Name = "combo_country";
            this.combo_country.Size = new System.Drawing.Size(156, 28);
            this.combo_country.TabIndex = 20;
            this.combo_country.SelectedIndexChanged += new System.EventHandler(this.combo_country_SelectedIndexChanged);
            // 
            // combo_team
            // 
            this.combo_team.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.combo_team.FormattingEnabled = true;
            this.combo_team.Location = new System.Drawing.Point(191, 153);
            this.combo_team.Name = "combo_team";
            this.combo_team.Size = new System.Drawing.Size(156, 28);
            this.combo_team.TabIndex = 22;
            this.combo_team.SelectedIndexChanged += new System.EventHandler(this.combo_team_SelectedIndexChanged);
            // 
            // lbl_ChooseTeam
            // 
            this.lbl_ChooseTeam.AutoSize = true;
            this.lbl_ChooseTeam.Location = new System.Drawing.Point(52, 156);
            this.lbl_ChooseTeam.Name = "lbl_ChooseTeam";
            this.lbl_ChooseTeam.Size = new System.Drawing.Size(116, 20);
            this.lbl_ChooseTeam.TabIndex = 21;
            this.lbl_ChooseTeam.Text = "Choose Team :";
            // 
            // cb_PPosition
            // 
            this.cb_PPosition.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cb_PPosition.FormattingEnabled = true;
            this.cb_PPosition.Items.AddRange(new object[] {
            "GK",
            "DF",
            "MF",
            "FW"});
            this.cb_PPosition.Location = new System.Drawing.Point(906, 204);
            this.cb_PPosition.Name = "cb_PPosition";
            this.cb_PPosition.Size = new System.Drawing.Size(172, 28);
            this.cb_PPosition.TabIndex = 23;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1125, 449);
            this.Controls.Add(this.cb_PPosition);
            this.Controls.Add(this.combo_team);
            this.Controls.Add(this.lbl_ChooseTeam);
            this.Controls.Add(this.combo_country);
            this.Controls.Add(this.lbl_ChooseCountry);
            this.Controls.Add(this.lbl_List);
            this.Controls.Add(this.lbl_addPlayer);
            this.Controls.Add(this.lbl_addTeam);
            this.Controls.Add(this.lbl_PPosition);
            this.Controls.Add(this.tb_PNumber);
            this.Controls.Add(this.lbl_PNumber);
            this.Controls.Add(this.tb_PName);
            this.Controls.Add(this.lbl_PName);
            this.Controls.Add(this.tb_TCity);
            this.Controls.Add(this.lbl_TCity);
            this.Controls.Add(this.tb_TCountry);
            this.Controls.Add(this.lbl_TCountry);
            this.Controls.Add(this.tb_TName);
            this.Controls.Add(this.lbl_TName);
            this.Controls.Add(this.lBox_ListTeam);
            this.Controls.Add(this.btn_addPlayer);
            this.Controls.Add(this.btn_addTeam);
            this.Controls.Add(this.btn_Remove);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btn_Remove;
        private System.Windows.Forms.Button btn_addTeam;
        private System.Windows.Forms.Button btn_addPlayer;
        private System.Windows.Forms.ListBox lBox_ListTeam;
        private System.Windows.Forms.Label lbl_TName;
        private System.Windows.Forms.TextBox tb_TName;
        private System.Windows.Forms.TextBox tb_TCountry;
        private System.Windows.Forms.Label lbl_TCountry;
        private System.Windows.Forms.TextBox tb_TCity;
        private System.Windows.Forms.Label lbl_TCity;
        private System.Windows.Forms.Label lbl_PPosition;
        private System.Windows.Forms.TextBox tb_PNumber;
        private System.Windows.Forms.Label lbl_PNumber;
        private System.Windows.Forms.TextBox tb_PName;
        private System.Windows.Forms.Label lbl_PName;
        private System.Windows.Forms.Label lbl_addTeam;
        private System.Windows.Forms.Label lbl_addPlayer;
        private System.Windows.Forms.Label lbl_List;
        private System.Windows.Forms.Label lbl_ChooseCountry;
        private System.Windows.Forms.ComboBox combo_country;
        private System.Windows.Forms.ComboBox combo_team;
        private System.Windows.Forms.Label lbl_ChooseTeam;
        private System.Windows.Forms.ComboBox cb_PPosition;
    }
}

