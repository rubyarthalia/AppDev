﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace _1st_exercise
{
    public partial class Form1 : Form
    {
        char[] hurufTertebak = { '_', '_', '_', '_', '_' };
        List<char> simpanTebakan = new List<char>();
        public Form1()
        {
            InitializeComponent();
        }
        private void btn_play_Click(object sender, EventArgs e)
        {
            string satu = tb_word1.Text.ToUpper();
            string dua = tb_word2.Text.ToUpper();
            string tiga = tb_word3.Text.ToUpper();
            string empat = tb_word4.Text.ToUpper();
            string lima = tb_word5.Text.ToUpper();
            if (tb_word1.Text == "" || tb_word2.Text == "" || tb_word3.Text == "" || tb_word4.Text == "" || tb_word5.Text == "" || satu.Length != 5 || dua.Length != 5 || tiga.Length != 5 || empat.Length != 5 || lima.Length != 5)
            {
                MessageBox.Show("There's an Error \n The word must be 5 letetrs \n You cannot put the same word twice");
            }
            if (satu == dua || satu == tiga || satu == empat || satu == lima || dua == tiga || dua == empat || dua == lima || tiga == empat || tiga == lima || empat == lima)
            {
                MessageBox.Show("There's an Error \n The word must be 5 letetrs \n You cannot put the same word twice");
            }
            else
            {
                MessageBox.Show("Let's Play !");
                panel_main.Visible = false;
                panel_play.Visible = true;
                string[] kata = {satu, dua, tiga, empat, lima};
                string tebakan = kata[new Random().Next(0, kata.Length)];
                lbl_hint.Text = tebakan.ToUpper();
                foreach (char huruf in tebakan)
                {
                    simpanTebakan.Add(huruf);
                }
            }
        }
        
        private void panel_play_Paint(object sender, PaintEventArgs e)
        {
            lbl_huruf1.Text = hurufTertebak[0].ToString().ToUpper();
            lbl_huruf2.Text = hurufTertebak[1].ToString().ToUpper();
            lbl_huruf3.Text = hurufTertebak[2].ToString().ToUpper();
            lbl_huruf4.Text = hurufTertebak[3].ToString().ToUpper();
            lbl_huruf5.Text = hurufTertebak[4].ToString().ToUpper();
        }
        private void mulaiTebak (char tebakanBenar)
        {
            if (simpanTebakan.Contains(tebakanBenar))
            {
                for (int i = 0;i<simpanTebakan.Count;i++)
                {
                    if (simpanTebakan[i] == tebakanBenar)
                    {
                        hurufTertebak[i] = tebakanBenar;
                    }
                }
                panel_play.Refresh();
            }

            bool cekMenang = false;
            int count = 0;
            for (int i = 0; i < 5; i++)
            {
                if (hurufTertebak[i] != '_')
                {
                    count += 1;
                }
            }
            if (count == 5)
            {
                cekMenang = true;
            }
            if (cekMenang == true)
            {
                MessageBox.Show("You WON");
            }
        }

        private void btn_q_Click(object sender, EventArgs e)
        {
            char hurufTertebak = 'Q';
            mulaiTebak(hurufTertebak);
        }

        private void btn_w_Click(object sender, EventArgs e)
        {
            char hurufTertebak = 'W';
            mulaiTebak(hurufTertebak);
        }

        private void btn_E_Click(object sender, EventArgs e)
        {
            char hurufTertebak = 'E';
            mulaiTebak(hurufTertebak);
        }

        private void btn_r_Click(object sender, EventArgs e)
        {
            char hurufTertebak = 'R';
            mulaiTebak(hurufTertebak);
        }

        private void btn_t_Click(object sender, EventArgs e)
        {
            char hurufTertebak = 'T';
            mulaiTebak(hurufTertebak);
        }

        private void btn_y_Click(object sender, EventArgs e)
        {
            char hurufTertebak = 'Y';
            mulaiTebak(hurufTertebak);
        }

        private void btn_u_Click(object sender, EventArgs e)
        {
            char hurufTertebak = 'U';
            mulaiTebak(hurufTertebak);
        }

        private void btn_i_Click(object sender, EventArgs e)
        {
            char hurufTertebak = 'I';
            mulaiTebak(hurufTertebak);
        }

        private void btn_o_Click(object sender, EventArgs e)
        {
            char hurufTertebak = 'O';
            mulaiTebak(hurufTertebak);
        }

        private void btn_P_Click(object sender, EventArgs e)
        {
            char hurufTertebak = 'P';
            mulaiTebak(hurufTertebak);
        }

        private void btn_a_Click(object sender, EventArgs e)
        {
            char hurufTertebak = 'A';
            mulaiTebak(hurufTertebak);
        }

        private void btn_s_Click(object sender, EventArgs e)
        {
            char hurufTertebak = 'S';
            mulaiTebak(hurufTertebak);
        }

        private void btn_d_Click(object sender, EventArgs e)
        {
            char hurufTertebak = 'D';
            mulaiTebak(hurufTertebak);
        }

        private void btn_f_Click(object sender, EventArgs e)
        {
            char hurufTertebak = 'F';
            mulaiTebak(hurufTertebak);
        }

        private void btn_g_Click(object sender, EventArgs e)
        {
            char hurufTertebak = 'G';
            mulaiTebak(hurufTertebak);
        }

        private void btn_h_Click(object sender, EventArgs e)
        {
            char hurufTertebak = 'H';
            mulaiTebak(hurufTertebak);
        }

        private void btn_j_Click(object sender, EventArgs e)
        {
            char hurufTertebak = 'J';
            mulaiTebak(hurufTertebak);
        }

        private void btn_k_Click(object sender, EventArgs e)
        {
            char hurufTertebak = 'K';
            mulaiTebak(hurufTertebak);
        }

        private void btn_l_Click(object sender, EventArgs e)
        {
            char hurufTertebak = 'L';
            mulaiTebak(hurufTertebak);
        }

        private void btn_z_Click(object sender, EventArgs e)
        {
            char hurufTertebak = 'Z';
            mulaiTebak(hurufTertebak);
        }

        private void btn_x_Click(object sender, EventArgs e)
        {
            char hurufTertebak = 'X';
            mulaiTebak(hurufTertebak);
        }

        private void btn_c_Click(object sender, EventArgs e)
        {
            char hurufTertebak = 'C';
            mulaiTebak(hurufTertebak);
        }

        private void btn_v_Click(object sender, EventArgs e)
        {
            char hurufTertebak = 'V';
            mulaiTebak(hurufTertebak);
        }

        private void btn_b_Click(object sender, EventArgs e)
        {
            char hurufTertebak = 'B';
            mulaiTebak(hurufTertebak);
        }

        private void btn_n_Click(object sender, EventArgs e)
        {
            char hurufTertebak = 'N';
            mulaiTebak(hurufTertebak);
        }

        private void btn_m_Click(object sender, EventArgs e)
        {
            char hurufTertebak = 'M';
            mulaiTebak(hurufTertebak);
        }

    }
}
