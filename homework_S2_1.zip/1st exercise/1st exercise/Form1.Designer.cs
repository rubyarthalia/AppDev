﻿namespace _1st_exercise
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lbl_word1 = new System.Windows.Forms.Label();
            this.lbl_word2 = new System.Windows.Forms.Label();
            this.lbl_word3 = new System.Windows.Forms.Label();
            this.lbl_word4 = new System.Windows.Forms.Label();
            this.lbl_word5 = new System.Windows.Forms.Label();
            this.tb_word4 = new System.Windows.Forms.TextBox();
            this.tb_word1 = new System.Windows.Forms.TextBox();
            this.tb_word2 = new System.Windows.Forms.TextBox();
            this.tb_word3 = new System.Windows.Forms.TextBox();
            this.tb_word5 = new System.Windows.Forms.TextBox();
            this.btn_play = new System.Windows.Forms.Button();
            this.panel_main = new System.Windows.Forms.Panel();
            this.panel_play = new System.Windows.Forms.Panel();
            this.lbl_hint = new System.Windows.Forms.Label();
            this.lbl_huruf5 = new System.Windows.Forms.Label();
            this.lbl_huruf2 = new System.Windows.Forms.Label();
            this.lbl_huruf3 = new System.Windows.Forms.Label();
            this.lbl_huruf4 = new System.Windows.Forms.Label();
            this.lbl_huruf1 = new System.Windows.Forms.Label();
            this.btn_P = new System.Windows.Forms.Button();
            this.btn_l = new System.Windows.Forms.Button();
            this.btn_o = new System.Windows.Forms.Button();
            this.btn_k = new System.Windows.Forms.Button();
            this.btn_i = new System.Windows.Forms.Button();
            this.btn_j = new System.Windows.Forms.Button();
            this.btn_m = new System.Windows.Forms.Button();
            this.btn_u = new System.Windows.Forms.Button();
            this.btn_h = new System.Windows.Forms.Button();
            this.btn_n = new System.Windows.Forms.Button();
            this.btn_y = new System.Windows.Forms.Button();
            this.btn_g = new System.Windows.Forms.Button();
            this.btn_b = new System.Windows.Forms.Button();
            this.btn_t = new System.Windows.Forms.Button();
            this.btn_f = new System.Windows.Forms.Button();
            this.btn_v = new System.Windows.Forms.Button();
            this.btn_r = new System.Windows.Forms.Button();
            this.btn_d = new System.Windows.Forms.Button();
            this.btn_c = new System.Windows.Forms.Button();
            this.btn_E = new System.Windows.Forms.Button();
            this.btn_s = new System.Windows.Forms.Button();
            this.btn_x = new System.Windows.Forms.Button();
            this.btn_w = new System.Windows.Forms.Button();
            this.btn_a = new System.Windows.Forms.Button();
            this.btn_z = new System.Windows.Forms.Button();
            this.btn_q = new System.Windows.Forms.Button();
            this.panel_main.SuspendLayout();
            this.panel_play.SuspendLayout();
            this.SuspendLayout();
            // 
            // lbl_word1
            // 
            this.lbl_word1.AutoSize = true;
            this.lbl_word1.Location = new System.Drawing.Point(16, 41);
            this.lbl_word1.Name = "lbl_word1";
            this.lbl_word1.Size = new System.Drawing.Size(68, 20);
            this.lbl_word1.TabIndex = 0;
            this.lbl_word1.Text = "Word 1 :";
            // 
            // lbl_word2
            // 
            this.lbl_word2.AutoSize = true;
            this.lbl_word2.Location = new System.Drawing.Point(16, 72);
            this.lbl_word2.Name = "lbl_word2";
            this.lbl_word2.Size = new System.Drawing.Size(68, 20);
            this.lbl_word2.TabIndex = 1;
            this.lbl_word2.Text = "Word 2 :";
            // 
            // lbl_word3
            // 
            this.lbl_word3.AutoSize = true;
            this.lbl_word3.Location = new System.Drawing.Point(16, 103);
            this.lbl_word3.Name = "lbl_word3";
            this.lbl_word3.Size = new System.Drawing.Size(68, 20);
            this.lbl_word3.TabIndex = 2;
            this.lbl_word3.Text = "Word 3 :";
            // 
            // lbl_word4
            // 
            this.lbl_word4.AutoSize = true;
            this.lbl_word4.Location = new System.Drawing.Point(16, 132);
            this.lbl_word4.Name = "lbl_word4";
            this.lbl_word4.Size = new System.Drawing.Size(68, 20);
            this.lbl_word4.TabIndex = 3;
            this.lbl_word4.Text = "Word 4 :";
            // 
            // lbl_word5
            // 
            this.lbl_word5.AutoSize = true;
            this.lbl_word5.Location = new System.Drawing.Point(16, 161);
            this.lbl_word5.Name = "lbl_word5";
            this.lbl_word5.Size = new System.Drawing.Size(68, 20);
            this.lbl_word5.TabIndex = 4;
            this.lbl_word5.Text = "Word 5 :";
            // 
            // tb_word4
            // 
            this.tb_word4.Location = new System.Drawing.Point(91, 35);
            this.tb_word4.Name = "tb_word4";
            this.tb_word4.Size = new System.Drawing.Size(149, 26);
            this.tb_word4.TabIndex = 9;
            // 
            // tb_word1
            // 
            this.tb_word1.Location = new System.Drawing.Point(91, 67);
            this.tb_word1.Name = "tb_word1";
            this.tb_word1.Size = new System.Drawing.Size(149, 26);
            this.tb_word1.TabIndex = 10;
            // 
            // tb_word2
            // 
            this.tb_word2.Location = new System.Drawing.Point(91, 99);
            this.tb_word2.Name = "tb_word2";
            this.tb_word2.Size = new System.Drawing.Size(149, 26);
            this.tb_word2.TabIndex = 11;
            // 
            // tb_word3
            // 
            this.tb_word3.Location = new System.Drawing.Point(91, 131);
            this.tb_word3.Name = "tb_word3";
            this.tb_word3.Size = new System.Drawing.Size(149, 26);
            this.tb_word3.TabIndex = 12;
            // 
            // tb_word5
            // 
            this.tb_word5.Location = new System.Drawing.Point(91, 161);
            this.tb_word5.Name = "tb_word5";
            this.tb_word5.Size = new System.Drawing.Size(149, 26);
            this.tb_word5.TabIndex = 13;
            // 
            // btn_play
            // 
            this.btn_play.Location = new System.Drawing.Point(125, 214);
            this.btn_play.Name = "btn_play";
            this.btn_play.Size = new System.Drawing.Size(75, 37);
            this.btn_play.TabIndex = 14;
            this.btn_play.Text = "PLAY !!!";
            this.btn_play.UseVisualStyleBackColor = true;
            this.btn_play.Click += new System.EventHandler(this.btn_play_Click);
            // 
            // panel_main
            // 
            this.panel_main.Controls.Add(this.btn_play);
            this.panel_main.Controls.Add(this.tb_word5);
            this.panel_main.Controls.Add(this.tb_word3);
            this.panel_main.Controls.Add(this.tb_word2);
            this.panel_main.Controls.Add(this.tb_word1);
            this.panel_main.Controls.Add(this.tb_word4);
            this.panel_main.Controls.Add(this.lbl_word5);
            this.panel_main.Controls.Add(this.lbl_word4);
            this.panel_main.Controls.Add(this.lbl_word3);
            this.panel_main.Controls.Add(this.lbl_word2);
            this.panel_main.Controls.Add(this.lbl_word1);
            this.panel_main.Location = new System.Drawing.Point(41, 56);
            this.panel_main.Name = "panel_main";
            this.panel_main.Size = new System.Drawing.Size(270, 262);
            this.panel_main.TabIndex = 15;
            // 
            // panel_play
            // 
            this.panel_play.Controls.Add(this.lbl_hint);
            this.panel_play.Controls.Add(this.lbl_huruf5);
            this.panel_play.Controls.Add(this.lbl_huruf2);
            this.panel_play.Controls.Add(this.lbl_huruf3);
            this.panel_play.Controls.Add(this.lbl_huruf4);
            this.panel_play.Controls.Add(this.lbl_huruf1);
            this.panel_play.Controls.Add(this.btn_P);
            this.panel_play.Controls.Add(this.btn_l);
            this.panel_play.Controls.Add(this.btn_o);
            this.panel_play.Controls.Add(this.btn_k);
            this.panel_play.Controls.Add(this.btn_i);
            this.panel_play.Controls.Add(this.btn_j);
            this.panel_play.Controls.Add(this.btn_m);
            this.panel_play.Controls.Add(this.btn_u);
            this.panel_play.Controls.Add(this.btn_h);
            this.panel_play.Controls.Add(this.btn_n);
            this.panel_play.Controls.Add(this.btn_y);
            this.panel_play.Controls.Add(this.btn_g);
            this.panel_play.Controls.Add(this.btn_b);
            this.panel_play.Controls.Add(this.btn_t);
            this.panel_play.Controls.Add(this.btn_f);
            this.panel_play.Controls.Add(this.btn_v);
            this.panel_play.Controls.Add(this.btn_r);
            this.panel_play.Controls.Add(this.btn_d);
            this.panel_play.Controls.Add(this.btn_c);
            this.panel_play.Controls.Add(this.btn_E);
            this.panel_play.Controls.Add(this.btn_s);
            this.panel_play.Controls.Add(this.btn_x);
            this.panel_play.Controls.Add(this.btn_w);
            this.panel_play.Controls.Add(this.btn_a);
            this.panel_play.Controls.Add(this.btn_z);
            this.panel_play.Controls.Add(this.btn_q);
            this.panel_play.Location = new System.Drawing.Point(41, 22);
            this.panel_play.Name = "panel_play";
            this.panel_play.Size = new System.Drawing.Size(553, 358);
            this.panel_play.TabIndex = 16;
            this.panel_play.Visible = false;
            this.panel_play.Paint += new System.Windows.Forms.PaintEventHandler(this.panel_play_Paint);
            // 
            // lbl_hint
            // 
            this.lbl_hint.AutoSize = true;
            this.lbl_hint.Location = new System.Drawing.Point(477, 20);
            this.lbl_hint.Name = "lbl_hint";
            this.lbl_hint.Size = new System.Drawing.Size(0, 20);
            this.lbl_hint.TabIndex = 32;
            // 
            // lbl_huruf5
            // 
            this.lbl_huruf5.AutoSize = true;
            this.lbl_huruf5.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_huruf5.Location = new System.Drawing.Point(343, 101);
            this.lbl_huruf5.Name = "lbl_huruf5";
            this.lbl_huruf5.Size = new System.Drawing.Size(43, 46);
            this.lbl_huruf5.TabIndex = 31;
            this.lbl_huruf5.Text = "_";
            // 
            // lbl_huruf2
            // 
            this.lbl_huruf2.AutoSize = true;
            this.lbl_huruf2.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_huruf2.Location = new System.Drawing.Point(193, 101);
            this.lbl_huruf2.Name = "lbl_huruf2";
            this.lbl_huruf2.Size = new System.Drawing.Size(43, 46);
            this.lbl_huruf2.TabIndex = 30;
            this.lbl_huruf2.Text = "_";
            // 
            // lbl_huruf3
            // 
            this.lbl_huruf3.AutoSize = true;
            this.lbl_huruf3.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_huruf3.Location = new System.Drawing.Point(242, 101);
            this.lbl_huruf3.Name = "lbl_huruf3";
            this.lbl_huruf3.Size = new System.Drawing.Size(43, 46);
            this.lbl_huruf3.TabIndex = 29;
            this.lbl_huruf3.Text = "_";
            // 
            // lbl_huruf4
            // 
            this.lbl_huruf4.AutoSize = true;
            this.lbl_huruf4.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_huruf4.Location = new System.Drawing.Point(294, 101);
            this.lbl_huruf4.Name = "lbl_huruf4";
            this.lbl_huruf4.Size = new System.Drawing.Size(43, 46);
            this.lbl_huruf4.TabIndex = 28;
            this.lbl_huruf4.Text = "_";
            // 
            // lbl_huruf1
            // 
            this.lbl_huruf1.AutoSize = true;
            this.lbl_huruf1.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_huruf1.Location = new System.Drawing.Point(144, 101);
            this.lbl_huruf1.Name = "lbl_huruf1";
            this.lbl_huruf1.Size = new System.Drawing.Size(43, 46);
            this.lbl_huruf1.TabIndex = 27;
            this.lbl_huruf1.Text = "_";
            // 
            // btn_P
            // 
            this.btn_P.Font = new System.Drawing.Font("Rockwell Condensed", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_P.Location = new System.Drawing.Point(435, 179);
            this.btn_P.Margin = new System.Windows.Forms.Padding(0);
            this.btn_P.Name = "btn_P";
            this.btn_P.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.btn_P.Size = new System.Drawing.Size(43, 43);
            this.btn_P.TabIndex = 26;
            this.btn_P.Text = "P";
            this.btn_P.UseVisualStyleBackColor = true;
            this.btn_P.Click += new System.EventHandler(this.btn_P_Click);
            // 
            // btn_l
            // 
            this.btn_l.Font = new System.Drawing.Font("Rockwell Condensed", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_l.Location = new System.Drawing.Point(410, 222);
            this.btn_l.Margin = new System.Windows.Forms.Padding(0);
            this.btn_l.Name = "btn_l";
            this.btn_l.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.btn_l.Size = new System.Drawing.Size(43, 43);
            this.btn_l.TabIndex = 25;
            this.btn_l.Text = "L";
            this.btn_l.UseVisualStyleBackColor = true;
            this.btn_l.Click += new System.EventHandler(this.btn_l_Click);
            // 
            // btn_o
            // 
            this.btn_o.Font = new System.Drawing.Font("Rockwell Condensed", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_o.Location = new System.Drawing.Point(392, 179);
            this.btn_o.Margin = new System.Windows.Forms.Padding(0);
            this.btn_o.Name = "btn_o";
            this.btn_o.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.btn_o.Size = new System.Drawing.Size(43, 43);
            this.btn_o.TabIndex = 24;
            this.btn_o.Text = "O";
            this.btn_o.UseVisualStyleBackColor = true;
            this.btn_o.Click += new System.EventHandler(this.btn_o_Click);
            // 
            // btn_k
            // 
            this.btn_k.Font = new System.Drawing.Font("Rockwell Condensed", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_k.Location = new System.Drawing.Point(367, 221);
            this.btn_k.Margin = new System.Windows.Forms.Padding(0);
            this.btn_k.Name = "btn_k";
            this.btn_k.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.btn_k.Size = new System.Drawing.Size(43, 43);
            this.btn_k.TabIndex = 23;
            this.btn_k.Text = "K";
            this.btn_k.UseVisualStyleBackColor = true;
            this.btn_k.Click += new System.EventHandler(this.btn_k_Click);
            // 
            // btn_i
            // 
            this.btn_i.Font = new System.Drawing.Font("Rockwell Condensed", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_i.Location = new System.Drawing.Point(349, 178);
            this.btn_i.Margin = new System.Windows.Forms.Padding(0);
            this.btn_i.Name = "btn_i";
            this.btn_i.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.btn_i.Size = new System.Drawing.Size(43, 43);
            this.btn_i.TabIndex = 21;
            this.btn_i.Text = "I";
            this.btn_i.UseVisualStyleBackColor = true;
            this.btn_i.Click += new System.EventHandler(this.btn_i_Click);
            // 
            // btn_j
            // 
            this.btn_j.Font = new System.Drawing.Font("Rockwell Condensed", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_j.Location = new System.Drawing.Point(324, 221);
            this.btn_j.Margin = new System.Windows.Forms.Padding(0);
            this.btn_j.Name = "btn_j";
            this.btn_j.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.btn_j.Size = new System.Drawing.Size(43, 43);
            this.btn_j.TabIndex = 20;
            this.btn_j.Text = "J";
            this.btn_j.UseVisualStyleBackColor = true;
            this.btn_j.Click += new System.EventHandler(this.btn_j_Click);
            // 
            // btn_m
            // 
            this.btn_m.Font = new System.Drawing.Font("Rockwell Condensed", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_m.Location = new System.Drawing.Point(364, 265);
            this.btn_m.Margin = new System.Windows.Forms.Padding(0);
            this.btn_m.Name = "btn_m";
            this.btn_m.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.btn_m.Size = new System.Drawing.Size(43, 43);
            this.btn_m.TabIndex = 19;
            this.btn_m.Text = "M";
            this.btn_m.UseVisualStyleBackColor = true;
            this.btn_m.Click += new System.EventHandler(this.btn_m_Click);
            // 
            // btn_u
            // 
            this.btn_u.Font = new System.Drawing.Font("Rockwell Condensed", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_u.Location = new System.Drawing.Point(306, 178);
            this.btn_u.Margin = new System.Windows.Forms.Padding(0);
            this.btn_u.Name = "btn_u";
            this.btn_u.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.btn_u.Size = new System.Drawing.Size(43, 43);
            this.btn_u.TabIndex = 18;
            this.btn_u.Text = "U";
            this.btn_u.UseVisualStyleBackColor = true;
            this.btn_u.Click += new System.EventHandler(this.btn_u_Click);
            // 
            // btn_h
            // 
            this.btn_h.Font = new System.Drawing.Font("Rockwell Condensed", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_h.Location = new System.Drawing.Point(281, 221);
            this.btn_h.Margin = new System.Windows.Forms.Padding(0);
            this.btn_h.Name = "btn_h";
            this.btn_h.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.btn_h.Size = new System.Drawing.Size(43, 43);
            this.btn_h.TabIndex = 17;
            this.btn_h.Text = "H";
            this.btn_h.UseVisualStyleBackColor = true;
            this.btn_h.Click += new System.EventHandler(this.btn_h_Click);
            // 
            // btn_n
            // 
            this.btn_n.Font = new System.Drawing.Font("Rockwell Condensed", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_n.Location = new System.Drawing.Point(321, 265);
            this.btn_n.Margin = new System.Windows.Forms.Padding(0);
            this.btn_n.Name = "btn_n";
            this.btn_n.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.btn_n.Size = new System.Drawing.Size(43, 43);
            this.btn_n.TabIndex = 16;
            this.btn_n.Text = "N";
            this.btn_n.UseVisualStyleBackColor = true;
            this.btn_n.Click += new System.EventHandler(this.btn_n_Click);
            // 
            // btn_y
            // 
            this.btn_y.Font = new System.Drawing.Font("Rockwell Condensed", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_y.Location = new System.Drawing.Point(263, 178);
            this.btn_y.Margin = new System.Windows.Forms.Padding(0);
            this.btn_y.Name = "btn_y";
            this.btn_y.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.btn_y.Size = new System.Drawing.Size(43, 43);
            this.btn_y.TabIndex = 15;
            this.btn_y.Text = "Y";
            this.btn_y.UseVisualStyleBackColor = true;
            this.btn_y.Click += new System.EventHandler(this.btn_y_Click);
            // 
            // btn_g
            // 
            this.btn_g.Font = new System.Drawing.Font("Rockwell Condensed", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_g.Location = new System.Drawing.Point(238, 221);
            this.btn_g.Margin = new System.Windows.Forms.Padding(0);
            this.btn_g.Name = "btn_g";
            this.btn_g.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.btn_g.Size = new System.Drawing.Size(43, 43);
            this.btn_g.TabIndex = 14;
            this.btn_g.Text = "G";
            this.btn_g.UseVisualStyleBackColor = true;
            this.btn_g.Click += new System.EventHandler(this.btn_g_Click);
            // 
            // btn_b
            // 
            this.btn_b.Font = new System.Drawing.Font("Rockwell Condensed", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_b.Location = new System.Drawing.Point(278, 265);
            this.btn_b.Margin = new System.Windows.Forms.Padding(0);
            this.btn_b.Name = "btn_b";
            this.btn_b.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.btn_b.Size = new System.Drawing.Size(43, 43);
            this.btn_b.TabIndex = 13;
            this.btn_b.Text = "B";
            this.btn_b.UseVisualStyleBackColor = true;
            this.btn_b.Click += new System.EventHandler(this.btn_b_Click);
            // 
            // btn_t
            // 
            this.btn_t.Font = new System.Drawing.Font("Rockwell Condensed", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_t.Location = new System.Drawing.Point(220, 178);
            this.btn_t.Margin = new System.Windows.Forms.Padding(0);
            this.btn_t.Name = "btn_t";
            this.btn_t.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.btn_t.Size = new System.Drawing.Size(43, 43);
            this.btn_t.TabIndex = 12;
            this.btn_t.Text = "T";
            this.btn_t.UseVisualStyleBackColor = true;
            this.btn_t.Click += new System.EventHandler(this.btn_t_Click);
            // 
            // btn_f
            // 
            this.btn_f.Font = new System.Drawing.Font("Rockwell Condensed", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_f.Location = new System.Drawing.Point(195, 222);
            this.btn_f.Margin = new System.Windows.Forms.Padding(0);
            this.btn_f.Name = "btn_f";
            this.btn_f.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.btn_f.Size = new System.Drawing.Size(43, 43);
            this.btn_f.TabIndex = 11;
            this.btn_f.Text = "F";
            this.btn_f.UseVisualStyleBackColor = true;
            this.btn_f.Click += new System.EventHandler(this.btn_f_Click);
            // 
            // btn_v
            // 
            this.btn_v.Font = new System.Drawing.Font("Rockwell Condensed", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_v.Location = new System.Drawing.Point(235, 266);
            this.btn_v.Margin = new System.Windows.Forms.Padding(0);
            this.btn_v.Name = "btn_v";
            this.btn_v.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.btn_v.Size = new System.Drawing.Size(43, 43);
            this.btn_v.TabIndex = 10;
            this.btn_v.Text = "V";
            this.btn_v.UseVisualStyleBackColor = true;
            this.btn_v.Click += new System.EventHandler(this.btn_v_Click);
            // 
            // btn_r
            // 
            this.btn_r.Font = new System.Drawing.Font("Rockwell Condensed", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_r.Location = new System.Drawing.Point(177, 179);
            this.btn_r.Margin = new System.Windows.Forms.Padding(0);
            this.btn_r.Name = "btn_r";
            this.btn_r.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.btn_r.Size = new System.Drawing.Size(43, 43);
            this.btn_r.TabIndex = 9;
            this.btn_r.Text = "R";
            this.btn_r.UseVisualStyleBackColor = true;
            this.btn_r.Click += new System.EventHandler(this.btn_r_Click);
            // 
            // btn_d
            // 
            this.btn_d.Font = new System.Drawing.Font("Rockwell Condensed", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_d.Location = new System.Drawing.Point(152, 222);
            this.btn_d.Margin = new System.Windows.Forms.Padding(0);
            this.btn_d.Name = "btn_d";
            this.btn_d.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.btn_d.Size = new System.Drawing.Size(43, 43);
            this.btn_d.TabIndex = 8;
            this.btn_d.Text = "D";
            this.btn_d.UseVisualStyleBackColor = true;
            this.btn_d.Click += new System.EventHandler(this.btn_d_Click);
            // 
            // btn_c
            // 
            this.btn_c.Font = new System.Drawing.Font("Rockwell Condensed", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_c.Location = new System.Drawing.Point(192, 266);
            this.btn_c.Margin = new System.Windows.Forms.Padding(0);
            this.btn_c.Name = "btn_c";
            this.btn_c.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.btn_c.Size = new System.Drawing.Size(43, 43);
            this.btn_c.TabIndex = 7;
            this.btn_c.Text = "C";
            this.btn_c.UseVisualStyleBackColor = true;
            this.btn_c.Click += new System.EventHandler(this.btn_c_Click);
            // 
            // btn_E
            // 
            this.btn_E.Font = new System.Drawing.Font("Rockwell Condensed", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_E.Location = new System.Drawing.Point(134, 179);
            this.btn_E.Margin = new System.Windows.Forms.Padding(0);
            this.btn_E.Name = "btn_E";
            this.btn_E.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.btn_E.Size = new System.Drawing.Size(43, 43);
            this.btn_E.TabIndex = 6;
            this.btn_E.Text = "E";
            this.btn_E.UseVisualStyleBackColor = true;
            this.btn_E.Click += new System.EventHandler(this.btn_E_Click);
            // 
            // btn_s
            // 
            this.btn_s.Font = new System.Drawing.Font("Rockwell Condensed", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_s.Location = new System.Drawing.Point(109, 222);
            this.btn_s.Margin = new System.Windows.Forms.Padding(0);
            this.btn_s.Name = "btn_s";
            this.btn_s.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.btn_s.Size = new System.Drawing.Size(43, 43);
            this.btn_s.TabIndex = 5;
            this.btn_s.Text = "S";
            this.btn_s.UseVisualStyleBackColor = true;
            this.btn_s.Click += new System.EventHandler(this.btn_s_Click);
            // 
            // btn_x
            // 
            this.btn_x.Font = new System.Drawing.Font("Rockwell Condensed", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_x.Location = new System.Drawing.Point(149, 266);
            this.btn_x.Margin = new System.Windows.Forms.Padding(0);
            this.btn_x.Name = "btn_x";
            this.btn_x.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.btn_x.Size = new System.Drawing.Size(43, 43);
            this.btn_x.TabIndex = 4;
            this.btn_x.Text = "X";
            this.btn_x.UseVisualStyleBackColor = true;
            this.btn_x.Click += new System.EventHandler(this.btn_x_Click);
            // 
            // btn_w
            // 
            this.btn_w.Font = new System.Drawing.Font("Rockwell Condensed", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_w.Location = new System.Drawing.Point(91, 179);
            this.btn_w.Margin = new System.Windows.Forms.Padding(0);
            this.btn_w.Name = "btn_w";
            this.btn_w.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.btn_w.Size = new System.Drawing.Size(43, 43);
            this.btn_w.TabIndex = 3;
            this.btn_w.Text = "W";
            this.btn_w.UseVisualStyleBackColor = true;
            this.btn_w.Click += new System.EventHandler(this.btn_w_Click);
            // 
            // btn_a
            // 
            this.btn_a.Font = new System.Drawing.Font("Rockwell Condensed", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_a.Location = new System.Drawing.Point(66, 222);
            this.btn_a.Margin = new System.Windows.Forms.Padding(0);
            this.btn_a.Name = "btn_a";
            this.btn_a.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.btn_a.Size = new System.Drawing.Size(43, 43);
            this.btn_a.TabIndex = 2;
            this.btn_a.Text = "A";
            this.btn_a.UseVisualStyleBackColor = true;
            this.btn_a.Click += new System.EventHandler(this.btn_a_Click);
            // 
            // btn_z
            // 
            this.btn_z.Font = new System.Drawing.Font("Rockwell Condensed", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_z.Location = new System.Drawing.Point(106, 266);
            this.btn_z.Margin = new System.Windows.Forms.Padding(0);
            this.btn_z.Name = "btn_z";
            this.btn_z.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.btn_z.Size = new System.Drawing.Size(43, 43);
            this.btn_z.TabIndex = 1;
            this.btn_z.Text = "Z";
            this.btn_z.UseVisualStyleBackColor = true;
            this.btn_z.Click += new System.EventHandler(this.btn_z_Click);
            // 
            // btn_q
            // 
            this.btn_q.Font = new System.Drawing.Font("Rockwell Condensed", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_q.Location = new System.Drawing.Point(48, 179);
            this.btn_q.Margin = new System.Windows.Forms.Padding(0);
            this.btn_q.Name = "btn_q";
            this.btn_q.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.btn_q.Size = new System.Drawing.Size(43, 43);
            this.btn_q.TabIndex = 0;
            this.btn_q.Text = "Q";
            this.btn_q.UseVisualStyleBackColor = true;
            this.btn_q.Click += new System.EventHandler(this.btn_q_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(633, 450);
            this.Controls.Add(this.panel_play);
            this.Controls.Add(this.panel_main);
            this.Name = "Form1";
            this.Text = "Form1";
            this.panel_main.ResumeLayout(false);
            this.panel_main.PerformLayout();
            this.panel_play.ResumeLayout(false);
            this.panel_play.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Label lbl_word1;
        private System.Windows.Forms.Label lbl_word2;
        private System.Windows.Forms.Label lbl_word3;
        private System.Windows.Forms.Label lbl_word4;
        private System.Windows.Forms.Label lbl_word5;
        private System.Windows.Forms.TextBox tb_word4;
        private System.Windows.Forms.TextBox tb_word1;
        private System.Windows.Forms.TextBox tb_word2;
        private System.Windows.Forms.TextBox tb_word3;
        private System.Windows.Forms.TextBox tb_word5;
        private System.Windows.Forms.Button btn_play;
        private System.Windows.Forms.Panel panel_main;
        private System.Windows.Forms.Panel panel_play;
        private System.Windows.Forms.Button btn_q;
        private System.Windows.Forms.Button btn_P;
        private System.Windows.Forms.Button btn_l;
        private System.Windows.Forms.Button btn_o;
        private System.Windows.Forms.Button btn_k;
        private System.Windows.Forms.Button btn_i;
        private System.Windows.Forms.Button btn_j;
        private System.Windows.Forms.Button btn_m;
        private System.Windows.Forms.Button btn_u;
        private System.Windows.Forms.Button btn_h;
        private System.Windows.Forms.Button btn_n;
        private System.Windows.Forms.Button btn_y;
        private System.Windows.Forms.Button btn_g;
        private System.Windows.Forms.Button btn_b;
        private System.Windows.Forms.Button btn_t;
        private System.Windows.Forms.Button btn_f;
        private System.Windows.Forms.Button btn_v;
        private System.Windows.Forms.Button btn_r;
        private System.Windows.Forms.Button btn_d;
        private System.Windows.Forms.Button btn_c;
        private System.Windows.Forms.Button btn_E;
        private System.Windows.Forms.Button btn_s;
        private System.Windows.Forms.Button btn_x;
        private System.Windows.Forms.Button btn_w;
        private System.Windows.Forms.Button btn_a;
        private System.Windows.Forms.Button btn_z;
        private System.Windows.Forms.Label lbl_huruf1;
        private System.Windows.Forms.Label lbl_hint;
        private System.Windows.Forms.Label lbl_huruf5;
        private System.Windows.Forms.Label lbl_huruf2;
        private System.Windows.Forms.Label lbl_huruf3;
        private System.Windows.Forms.Label lbl_huruf4;
    }
}

