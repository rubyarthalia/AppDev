﻿namespace UniqME
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.tsm_top = new System.Windows.Forms.ToolStripMenuItem();
            this.tShirtToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.shirtToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.tsm_bottom = new System.Windows.Forms.ToolStripMenuItem();
            this.pantsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.longPantsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.tsm_accesories = new System.Windows.Forms.ToolStripMenuItem();
            this.shoesToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.jewelleriesToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.tsm_others = new System.Windows.Forms.ToolStripMenuItem();
            this.panel_tshirt = new System.Windows.Forms.Panel();
            this.btn_kaosBiru = new System.Windows.Forms.Button();
            this.btn_kaosPutih = new System.Windows.Forms.Button();
            this.btn_kaosHitam = new System.Windows.Forms.Button();
            this.lbl_hargaKaosBiru = new System.Windows.Forms.Label();
            this.lbl_hargaKaosPutih = new System.Windows.Forms.Label();
            this.lbl_hargaKaosHitam = new System.Windows.Forms.Label();
            this.lbl_kaosBiru = new System.Windows.Forms.Label();
            this.lbl_kaosPutih = new System.Windows.Forms.Label();
            this.lbl_kaosHitam = new System.Windows.Forms.Label();
            this.pb_kaosBiru = new System.Windows.Forms.PictureBox();
            this.pb_kaosPutih = new System.Windows.Forms.PictureBox();
            this.pb_kaosHitam = new System.Windows.Forms.PictureBox();
            this.dgv_keranjang = new System.Windows.Forms.DataGridView();
            this.lbl_subTotal = new System.Windows.Forms.Label();
            this.lbl_Total = new System.Windows.Forms.Label();
            this.tb_subTotal = new System.Windows.Forms.TextBox();
            this.tb_total = new System.Windows.Forms.TextBox();
            this.btn_delete = new System.Windows.Forms.Button();
            this.panel_shirt = new System.Windows.Forms.Panel();
            this.btn_kemejaBiru = new System.Windows.Forms.Button();
            this.btn_kemejaPutih = new System.Windows.Forms.Button();
            this.btn_kemejaHitam = new System.Windows.Forms.Button();
            this.lbl_hargaKemejaBiru = new System.Windows.Forms.Label();
            this.lbl_hargaKemejaPutih = new System.Windows.Forms.Label();
            this.lbl_hargaKemejaHitam = new System.Windows.Forms.Label();
            this.lbl_kemejaBiru = new System.Windows.Forms.Label();
            this.lbl_kemejaPutih = new System.Windows.Forms.Label();
            this.lbl_kemejaHitam = new System.Windows.Forms.Label();
            this.pb_kemejaBiru = new System.Windows.Forms.PictureBox();
            this.pb_kemejaPutih = new System.Windows.Forms.PictureBox();
            this.pb_kemejaHitam = new System.Windows.Forms.PictureBox();
            this.panel_pants = new System.Windows.Forms.Panel();
            this.btn_celpenJeans = new System.Windows.Forms.Button();
            this.btn_celpenHijau = new System.Windows.Forms.Button();
            this.btn_celpenKhaki = new System.Windows.Forms.Button();
            this.lbl_hargaCelpenJeans = new System.Windows.Forms.Label();
            this.lbl_hargaCelpenHijau = new System.Windows.Forms.Label();
            this.lbl_hargaCelpenKhaki = new System.Windows.Forms.Label();
            this.lbl_celpenJeans = new System.Windows.Forms.Label();
            this.lbl_celpenHijau = new System.Windows.Forms.Label();
            this.lbl_celpenKhaki = new System.Windows.Forms.Label();
            this.pb_pantsJeans = new System.Windows.Forms.PictureBox();
            this.pb_pantshijau = new System.Windows.Forms.PictureBox();
            this.pb_pantskhaki = new System.Windows.Forms.PictureBox();
            this.panel_long = new System.Windows.Forms.Panel();
            this.btn_celpanKhaki = new System.Windows.Forms.Button();
            this.btn_celpanHijau = new System.Windows.Forms.Button();
            this.btn_celpanHitam = new System.Windows.Forms.Button();
            this.lbl_hargaCelpanKhaki = new System.Windows.Forms.Label();
            this.lbl_hargaCelpanHijau = new System.Windows.Forms.Label();
            this.lbl_hargaCelpanHitam = new System.Windows.Forms.Label();
            this.lbll_celpanKhaki = new System.Windows.Forms.Label();
            this.lbll_celpanHIjau = new System.Windows.Forms.Label();
            this.lbll_celpanHItam = new System.Windows.Forms.Label();
            this.pb_celpanKhaki = new System.Windows.Forms.PictureBox();
            this.pb_celpanHijau = new System.Windows.Forms.PictureBox();
            this.pb_celpanHitam = new System.Windows.Forms.PictureBox();
            this.panel_jewelleries = new System.Windows.Forms.Panel();
            this.btn_bag = new System.Windows.Forms.Button();
            this.btn_belt = new System.Windows.Forms.Button();
            this.btn_cap = new System.Windows.Forms.Button();
            this.lbl_hargaBag = new System.Windows.Forms.Label();
            this.lbl_hargaBelt = new System.Windows.Forms.Label();
            this.lbl_hargaCap = new System.Windows.Forms.Label();
            this.lbl_bag = new System.Windows.Forms.Label();
            this.lbl_belt = new System.Windows.Forms.Label();
            this.lbl_cap = new System.Windows.Forms.Label();
            this.pb_bag = new System.Windows.Forms.PictureBox();
            this.pb_belt = new System.Windows.Forms.PictureBox();
            this.pb_cap = new System.Windows.Forms.PictureBox();
            this.panel_shoes = new System.Windows.Forms.Panel();
            this.btn_loafers = new System.Windows.Forms.Button();
            this.btn_platform = new System.Windows.Forms.Button();
            this.btn_slipOn = new System.Windows.Forms.Button();
            this.lbl_hargaLoafers = new System.Windows.Forms.Label();
            this.lbl_hargaPlatform = new System.Windows.Forms.Label();
            this.lbl_hargaSlipOn = new System.Windows.Forms.Label();
            this.lbl_loafers = new System.Windows.Forms.Label();
            this.lbl_platformShoes = new System.Windows.Forms.Label();
            this.lbl_slipOn = new System.Windows.Forms.Label();
            this.pb_loafers = new System.Windows.Forms.PictureBox();
            this.pb_platformSandal = new System.Windows.Forms.PictureBox();
            this.pb_slipon = new System.Windows.Forms.PictureBox();
            this.panel_others = new System.Windows.Forms.Panel();
            this.tb_hargaUpload = new System.Windows.Forms.TextBox();
            this.tb_itemUpload = new System.Windows.Forms.TextBox();
            this.btn_upload = new System.Windows.Forms.Button();
            this.btn_uploadImage = new System.Windows.Forms.Button();
            this.lbl_itemPrice = new System.Windows.Forms.Label();
            this.lbl_inputNama = new System.Windows.Forms.Label();
            this.lbl_upload = new System.Windows.Forms.Label();
            this.pb_others = new System.Windows.Forms.PictureBox();
            this.menuStrip1.SuspendLayout();
            this.panel_tshirt.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pb_kaosBiru)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb_kaosPutih)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb_kaosHitam)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgv_keranjang)).BeginInit();
            this.panel_shirt.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pb_kemejaBiru)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb_kemejaPutih)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb_kemejaHitam)).BeginInit();
            this.panel_pants.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pb_pantsJeans)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb_pantshijau)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb_pantskhaki)).BeginInit();
            this.panel_long.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pb_celpanKhaki)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb_celpanHijau)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb_celpanHitam)).BeginInit();
            this.panel_jewelleries.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pb_bag)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb_belt)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb_cap)).BeginInit();
            this.panel_shoes.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pb_loafers)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb_platformSandal)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb_slipon)).BeginInit();
            this.panel_others.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pb_others)).BeginInit();
            this.SuspendLayout();
            // 
            // menuStrip1
            // 
            this.menuStrip1.GripMargin = new System.Windows.Forms.Padding(2, 2, 0, 2);
            this.menuStrip1.ImageScalingSize = new System.Drawing.Size(24, 24);
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.tsm_top,
            this.tsm_bottom,
            this.tsm_accesories,
            this.tsm_others});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(1480, 33);
            this.menuStrip1.TabIndex = 0;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // tsm_top
            // 
            this.tsm_top.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.tShirtToolStripMenuItem,
            this.shirtToolStripMenuItem});
            this.tsm_top.Name = "tsm_top";
            this.tsm_top.Size = new System.Drawing.Size(102, 29);
            this.tsm_top.Text = "Top Wear";
            // 
            // tShirtToolStripMenuItem
            // 
            this.tShirtToolStripMenuItem.Name = "tShirtToolStripMenuItem";
            this.tShirtToolStripMenuItem.Size = new System.Drawing.Size(166, 34);
            this.tShirtToolStripMenuItem.Text = "T-Shirt";
            this.tShirtToolStripMenuItem.Click += new System.EventHandler(this.tShirtToolStripMenuItem_Click);
            // 
            // shirtToolStripMenuItem
            // 
            this.shirtToolStripMenuItem.Name = "shirtToolStripMenuItem";
            this.shirtToolStripMenuItem.Size = new System.Drawing.Size(166, 34);
            this.shirtToolStripMenuItem.Text = "Shirt";
            this.shirtToolStripMenuItem.Click += new System.EventHandler(this.shirtToolStripMenuItem_Click);
            // 
            // tsm_bottom
            // 
            this.tsm_bottom.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.pantsToolStripMenuItem,
            this.longPantsToolStripMenuItem});
            this.tsm_bottom.Name = "tsm_bottom";
            this.tsm_bottom.Size = new System.Drawing.Size(133, 29);
            this.tsm_bottom.Text = "Bottom Wear";
            // 
            // pantsToolStripMenuItem
            // 
            this.pantsToolStripMenuItem.Name = "pantsToolStripMenuItem";
            this.pantsToolStripMenuItem.Size = new System.Drawing.Size(201, 34);
            this.pantsToolStripMenuItem.Text = "Pants";
            this.pantsToolStripMenuItem.Click += new System.EventHandler(this.pantsToolStripMenuItem_Click);
            // 
            // longPantsToolStripMenuItem
            // 
            this.longPantsToolStripMenuItem.Name = "longPantsToolStripMenuItem";
            this.longPantsToolStripMenuItem.Size = new System.Drawing.Size(201, 34);
            this.longPantsToolStripMenuItem.Text = "Long Pants";
            this.longPantsToolStripMenuItem.Click += new System.EventHandler(this.longPantsToolStripMenuItem_Click);
            // 
            // tsm_accesories
            // 
            this.tsm_accesories.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.shoesToolStripMenuItem,
            this.jewelleriesToolStripMenuItem});
            this.tsm_accesories.Name = "tsm_accesories";
            this.tsm_accesories.Size = new System.Drawing.Size(119, 29);
            this.tsm_accesories.Text = "Accessories";
            // 
            // shoesToolStripMenuItem
            // 
            this.shoesToolStripMenuItem.Name = "shoesToolStripMenuItem";
            this.shoesToolStripMenuItem.Size = new System.Drawing.Size(195, 34);
            this.shoesToolStripMenuItem.Text = "Shoes";
            this.shoesToolStripMenuItem.Click += new System.EventHandler(this.shoesToolStripMenuItem_Click);
            // 
            // jewelleriesToolStripMenuItem
            // 
            this.jewelleriesToolStripMenuItem.Name = "jewelleriesToolStripMenuItem";
            this.jewelleriesToolStripMenuItem.Size = new System.Drawing.Size(195, 34);
            this.jewelleriesToolStripMenuItem.Text = "Jewelleries";
            this.jewelleriesToolStripMenuItem.Click += new System.EventHandler(this.jewelleriesToolStripMenuItem_Click);
            // 
            // tsm_others
            // 
            this.tsm_others.Name = "tsm_others";
            this.tsm_others.Size = new System.Drawing.Size(81, 29);
            this.tsm_others.Text = "Others";
            this.tsm_others.Click += new System.EventHandler(this.tsm_others_Click);
            // 
            // panel_tshirt
            // 
            this.panel_tshirt.Controls.Add(this.btn_kaosBiru);
            this.panel_tshirt.Controls.Add(this.btn_kaosPutih);
            this.panel_tshirt.Controls.Add(this.btn_kaosHitam);
            this.panel_tshirt.Controls.Add(this.lbl_hargaKaosBiru);
            this.panel_tshirt.Controls.Add(this.lbl_hargaKaosPutih);
            this.panel_tshirt.Controls.Add(this.lbl_hargaKaosHitam);
            this.panel_tshirt.Controls.Add(this.lbl_kaosBiru);
            this.panel_tshirt.Controls.Add(this.lbl_kaosPutih);
            this.panel_tshirt.Controls.Add(this.lbl_kaosHitam);
            this.panel_tshirt.Controls.Add(this.pb_kaosBiru);
            this.panel_tshirt.Controls.Add(this.pb_kaosPutih);
            this.panel_tshirt.Controls.Add(this.pb_kaosHitam);
            this.panel_tshirt.Location = new System.Drawing.Point(35, 70);
            this.panel_tshirt.Name = "panel_tshirt";
            this.panel_tshirt.Size = new System.Drawing.Size(553, 334);
            this.panel_tshirt.TabIndex = 1;
            this.panel_tshirt.Visible = false;
            // 
            // btn_kaosBiru
            // 
            this.btn_kaosBiru.Location = new System.Drawing.Point(406, 265);
            this.btn_kaosBiru.Name = "btn_kaosBiru";
            this.btn_kaosBiru.Size = new System.Drawing.Size(84, 52);
            this.btn_kaosBiru.TabIndex = 11;
            this.btn_kaosBiru.Text = "Add to Cart";
            this.btn_kaosBiru.UseVisualStyleBackColor = true;
            this.btn_kaosBiru.Click += new System.EventHandler(this.btn_kaosBiru_Click);
            // 
            // btn_kaosPutih
            // 
            this.btn_kaosPutih.Location = new System.Drawing.Point(237, 265);
            this.btn_kaosPutih.Name = "btn_kaosPutih";
            this.btn_kaosPutih.Size = new System.Drawing.Size(84, 52);
            this.btn_kaosPutih.TabIndex = 10;
            this.btn_kaosPutih.Text = "Add to Cart";
            this.btn_kaosPutih.UseVisualStyleBackColor = true;
            this.btn_kaosPutih.Click += new System.EventHandler(this.btn_kaosPutih_Click);
            // 
            // btn_kaosHitam
            // 
            this.btn_kaosHitam.Location = new System.Drawing.Point(62, 265);
            this.btn_kaosHitam.Name = "btn_kaosHitam";
            this.btn_kaosHitam.Size = new System.Drawing.Size(84, 52);
            this.btn_kaosHitam.TabIndex = 9;
            this.btn_kaosHitam.Text = "Add to Cart";
            this.btn_kaosHitam.UseVisualStyleBackColor = true;
            this.btn_kaosHitam.Click += new System.EventHandler(this.btn_kaosHitam_Click);
            // 
            // lbl_hargaKaosBiru
            // 
            this.lbl_hargaKaosBiru.AutoSize = true;
            this.lbl_hargaKaosBiru.Location = new System.Drawing.Point(398, 242);
            this.lbl_hargaKaosBiru.Name = "lbl_hargaKaosBiru";
            this.lbl_hargaKaosBiru.Size = new System.Drawing.Size(92, 20);
            this.lbl_hargaKaosBiru.TabIndex = 8;
            this.lbl_hargaKaosBiru.Text = "Rp 200.000";
            // 
            // lbl_hargaKaosPutih
            // 
            this.lbl_hargaKaosPutih.AutoSize = true;
            this.lbl_hargaKaosPutih.Location = new System.Drawing.Point(233, 242);
            this.lbl_hargaKaosPutih.Name = "lbl_hargaKaosPutih";
            this.lbl_hargaKaosPutih.Size = new System.Drawing.Size(92, 20);
            this.lbl_hargaKaosPutih.TabIndex = 7;
            this.lbl_hargaKaosPutih.Text = "Rp 200.000";
            // 
            // lbl_hargaKaosHitam
            // 
            this.lbl_hargaKaosHitam.AutoSize = true;
            this.lbl_hargaKaosHitam.Location = new System.Drawing.Point(58, 242);
            this.lbl_hargaKaosHitam.Name = "lbl_hargaKaosHitam";
            this.lbl_hargaKaosHitam.Size = new System.Drawing.Size(92, 20);
            this.lbl_hargaKaosHitam.TabIndex = 6;
            this.lbl_hargaKaosHitam.Text = "Rp 200.000";
            // 
            // lbl_kaosBiru
            // 
            this.lbl_kaosBiru.AutoSize = true;
            this.lbl_kaosBiru.Location = new System.Drawing.Point(398, 219);
            this.lbl_kaosBiru.Name = "lbl_kaosBiru";
            this.lbl_kaosBiru.Size = new System.Drawing.Size(88, 20);
            this.lbl_kaosBiru.TabIndex = 5;
            this.lbl_kaosBiru.Text = "T-Shirt Biru";
            // 
            // lbl_kaosPutih
            // 
            this.lbl_kaosPutih.AutoSize = true;
            this.lbl_kaosPutih.Location = new System.Drawing.Point(229, 219);
            this.lbl_kaosPutih.Name = "lbl_kaosPutih";
            this.lbl_kaosPutih.Size = new System.Drawing.Size(96, 20);
            this.lbl_kaosPutih.TabIndex = 4;
            this.lbl_kaosPutih.Text = "T-Shirt Putih";
            // 
            // lbl_kaosHitam
            // 
            this.lbl_kaosHitam.AutoSize = true;
            this.lbl_kaosHitam.Location = new System.Drawing.Point(57, 219);
            this.lbl_kaosHitam.Name = "lbl_kaosHitam";
            this.lbl_kaosHitam.Size = new System.Drawing.Size(102, 20);
            this.lbl_kaosHitam.TabIndex = 3;
            this.lbl_kaosHitam.Text = "T-Shirt Hitam";
            // 
            // pb_kaosBiru
            // 
            this.pb_kaosBiru.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pb_kaosBiru.BackgroundImage")));
            this.pb_kaosBiru.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.pb_kaosBiru.Location = new System.Drawing.Point(382, 30);
            this.pb_kaosBiru.Name = "pb_kaosBiru";
            this.pb_kaosBiru.Size = new System.Drawing.Size(134, 175);
            this.pb_kaosBiru.TabIndex = 2;
            this.pb_kaosBiru.TabStop = false;
            // 
            // pb_kaosPutih
            // 
            this.pb_kaosPutih.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pb_kaosPutih.BackgroundImage")));
            this.pb_kaosPutih.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.pb_kaosPutih.Location = new System.Drawing.Point(209, 30);
            this.pb_kaosPutih.Name = "pb_kaosPutih";
            this.pb_kaosPutih.Size = new System.Drawing.Size(134, 175);
            this.pb_kaosPutih.TabIndex = 1;
            this.pb_kaosPutih.TabStop = false;
            // 
            // pb_kaosHitam
            // 
            this.pb_kaosHitam.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pb_kaosHitam.BackgroundImage")));
            this.pb_kaosHitam.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.pb_kaosHitam.Location = new System.Drawing.Point(40, 30);
            this.pb_kaosHitam.Name = "pb_kaosHitam";
            this.pb_kaosHitam.Size = new System.Drawing.Size(134, 175);
            this.pb_kaosHitam.TabIndex = 0;
            this.pb_kaosHitam.TabStop = false;
            // 
            // dgv_keranjang
            // 
            this.dgv_keranjang.AllowUserToAddRows = false;
            this.dgv_keranjang.AllowUserToDeleteRows = false;
            this.dgv_keranjang.AllowUserToResizeColumns = false;
            this.dgv_keranjang.AllowUserToResizeRows = false;
            this.dgv_keranjang.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgv_keranjang.Location = new System.Drawing.Point(797, 71);
            this.dgv_keranjang.Name = "dgv_keranjang";
            this.dgv_keranjang.ReadOnly = true;
            this.dgv_keranjang.RowHeadersVisible = false;
            this.dgv_keranjang.RowHeadersWidth = 62;
            this.dgv_keranjang.RowTemplate.Height = 28;
            this.dgv_keranjang.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgv_keranjang.Size = new System.Drawing.Size(594, 333);
            this.dgv_keranjang.TabIndex = 2;
            this.dgv_keranjang.CellMouseClick += new System.Windows.Forms.DataGridViewCellMouseEventHandler(this.dgv_keranjang_CellMouseClick);
            // 
            // lbl_subTotal
            // 
            this.lbl_subTotal.AutoSize = true;
            this.lbl_subTotal.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_subTotal.Location = new System.Drawing.Point(792, 427);
            this.lbl_subTotal.Name = "lbl_subTotal";
            this.lbl_subTotal.Size = new System.Drawing.Size(142, 29);
            this.lbl_subTotal.TabIndex = 3;
            this.lbl_subTotal.Text = "Sub-Total :";
            // 
            // lbl_Total
            // 
            this.lbl_Total.AutoSize = true;
            this.lbl_Total.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Total.Location = new System.Drawing.Point(792, 463);
            this.lbl_Total.Name = "lbl_Total";
            this.lbl_Total.Size = new System.Drawing.Size(87, 29);
            this.lbl_Total.TabIndex = 4;
            this.lbl_Total.Text = "Total :";
            // 
            // tb_subTotal
            // 
            this.tb_subTotal.Enabled = false;
            this.tb_subTotal.Location = new System.Drawing.Point(939, 431);
            this.tb_subTotal.Name = "tb_subTotal";
            this.tb_subTotal.Size = new System.Drawing.Size(162, 26);
            this.tb_subTotal.TabIndex = 5;
            // 
            // tb_total
            // 
            this.tb_total.Enabled = false;
            this.tb_total.Location = new System.Drawing.Point(939, 463);
            this.tb_total.Name = "tb_total";
            this.tb_total.Size = new System.Drawing.Size(162, 26);
            this.tb_total.TabIndex = 6;
            // 
            // btn_delete
            // 
            this.btn_delete.Location = new System.Drawing.Point(1179, 417);
            this.btn_delete.Name = "btn_delete";
            this.btn_delete.Size = new System.Drawing.Size(103, 35);
            this.btn_delete.TabIndex = 7;
            this.btn_delete.Text = "DELETE";
            this.btn_delete.UseVisualStyleBackColor = true;
            this.btn_delete.Click += new System.EventHandler(this.btn_delete_Click);
            // 
            // panel_shirt
            // 
            this.panel_shirt.Controls.Add(this.btn_kemejaBiru);
            this.panel_shirt.Controls.Add(this.btn_kemejaPutih);
            this.panel_shirt.Controls.Add(this.btn_kemejaHitam);
            this.panel_shirt.Controls.Add(this.lbl_hargaKemejaBiru);
            this.panel_shirt.Controls.Add(this.lbl_hargaKemejaPutih);
            this.panel_shirt.Controls.Add(this.lbl_hargaKemejaHitam);
            this.panel_shirt.Controls.Add(this.lbl_kemejaBiru);
            this.panel_shirt.Controls.Add(this.lbl_kemejaPutih);
            this.panel_shirt.Controls.Add(this.lbl_kemejaHitam);
            this.panel_shirt.Controls.Add(this.pb_kemejaBiru);
            this.panel_shirt.Controls.Add(this.pb_kemejaPutih);
            this.panel_shirt.Controls.Add(this.pb_kemejaHitam);
            this.panel_shirt.Location = new System.Drawing.Point(35, 70);
            this.panel_shirt.Name = "panel_shirt";
            this.panel_shirt.Size = new System.Drawing.Size(603, 356);
            this.panel_shirt.TabIndex = 12;
            this.panel_shirt.Visible = false;
            // 
            // btn_kemejaBiru
            // 
            this.btn_kemejaBiru.Location = new System.Drawing.Point(406, 265);
            this.btn_kemejaBiru.Name = "btn_kemejaBiru";
            this.btn_kemejaBiru.Size = new System.Drawing.Size(84, 52);
            this.btn_kemejaBiru.TabIndex = 11;
            this.btn_kemejaBiru.Text = "Add to Cart";
            this.btn_kemejaBiru.UseVisualStyleBackColor = true;
            this.btn_kemejaBiru.Click += new System.EventHandler(this.btn_kemejaBiru_Click);
            // 
            // btn_kemejaPutih
            // 
            this.btn_kemejaPutih.Location = new System.Drawing.Point(237, 265);
            this.btn_kemejaPutih.Name = "btn_kemejaPutih";
            this.btn_kemejaPutih.Size = new System.Drawing.Size(84, 52);
            this.btn_kemejaPutih.TabIndex = 10;
            this.btn_kemejaPutih.Text = "Add to Cart";
            this.btn_kemejaPutih.UseVisualStyleBackColor = true;
            this.btn_kemejaPutih.Click += new System.EventHandler(this.btn_kemejaPutih_Click);
            // 
            // btn_kemejaHitam
            // 
            this.btn_kemejaHitam.Location = new System.Drawing.Point(62, 265);
            this.btn_kemejaHitam.Name = "btn_kemejaHitam";
            this.btn_kemejaHitam.Size = new System.Drawing.Size(84, 52);
            this.btn_kemejaHitam.TabIndex = 9;
            this.btn_kemejaHitam.Text = "Add to Cart";
            this.btn_kemejaHitam.UseVisualStyleBackColor = true;
            this.btn_kemejaHitam.Click += new System.EventHandler(this.btn_kemejaHitam_Click);
            // 
            // lbl_hargaKemejaBiru
            // 
            this.lbl_hargaKemejaBiru.AutoSize = true;
            this.lbl_hargaKemejaBiru.Location = new System.Drawing.Point(398, 242);
            this.lbl_hargaKemejaBiru.Name = "lbl_hargaKemejaBiru";
            this.lbl_hargaKemejaBiru.Size = new System.Drawing.Size(92, 20);
            this.lbl_hargaKemejaBiru.TabIndex = 8;
            this.lbl_hargaKemejaBiru.Text = "Rp 500.000";
            // 
            // lbl_hargaKemejaPutih
            // 
            this.lbl_hargaKemejaPutih.AutoSize = true;
            this.lbl_hargaKemejaPutih.Location = new System.Drawing.Point(233, 242);
            this.lbl_hargaKemejaPutih.Name = "lbl_hargaKemejaPutih";
            this.lbl_hargaKemejaPutih.Size = new System.Drawing.Size(92, 20);
            this.lbl_hargaKemejaPutih.TabIndex = 7;
            this.lbl_hargaKemejaPutih.Text = "Rp 500.000";
            // 
            // lbl_hargaKemejaHitam
            // 
            this.lbl_hargaKemejaHitam.AutoSize = true;
            this.lbl_hargaKemejaHitam.Location = new System.Drawing.Point(58, 242);
            this.lbl_hargaKemejaHitam.Name = "lbl_hargaKemejaHitam";
            this.lbl_hargaKemejaHitam.Size = new System.Drawing.Size(92, 20);
            this.lbl_hargaKemejaHitam.TabIndex = 6;
            this.lbl_hargaKemejaHitam.Text = "Rp 500.000";
            // 
            // lbl_kemejaBiru
            // 
            this.lbl_kemejaBiru.AutoSize = true;
            this.lbl_kemejaBiru.Location = new System.Drawing.Point(407, 219);
            this.lbl_kemejaBiru.Name = "lbl_kemejaBiru";
            this.lbl_kemejaBiru.Size = new System.Drawing.Size(74, 20);
            this.lbl_kemejaBiru.TabIndex = 5;
            this.lbl_kemejaBiru.Text = "Shirt Biru";
            // 
            // lbl_kemejaPutih
            // 
            this.lbl_kemejaPutih.AutoSize = true;
            this.lbl_kemejaPutih.Location = new System.Drawing.Point(236, 219);
            this.lbl_kemejaPutih.Name = "lbl_kemejaPutih";
            this.lbl_kemejaPutih.Size = new System.Drawing.Size(82, 20);
            this.lbl_kemejaPutih.TabIndex = 4;
            this.lbl_kemejaPutih.Text = "Shirt Putih";
            // 
            // lbl_kemejaHitam
            // 
            this.lbl_kemejaHitam.AutoSize = true;
            this.lbl_kemejaHitam.Location = new System.Drawing.Point(60, 219);
            this.lbl_kemejaHitam.Name = "lbl_kemejaHitam";
            this.lbl_kemejaHitam.Size = new System.Drawing.Size(88, 20);
            this.lbl_kemejaHitam.TabIndex = 3;
            this.lbl_kemejaHitam.Text = "Shirt Hitam";
            // 
            // pb_kemejaBiru
            // 
            this.pb_kemejaBiru.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pb_kemejaBiru.BackgroundImage")));
            this.pb_kemejaBiru.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.pb_kemejaBiru.Location = new System.Drawing.Point(382, 30);
            this.pb_kemejaBiru.Name = "pb_kemejaBiru";
            this.pb_kemejaBiru.Size = new System.Drawing.Size(134, 175);
            this.pb_kemejaBiru.TabIndex = 2;
            this.pb_kemejaBiru.TabStop = false;
            // 
            // pb_kemejaPutih
            // 
            this.pb_kemejaPutih.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pb_kemejaPutih.BackgroundImage")));
            this.pb_kemejaPutih.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.pb_kemejaPutih.Location = new System.Drawing.Point(209, 30);
            this.pb_kemejaPutih.Name = "pb_kemejaPutih";
            this.pb_kemejaPutih.Size = new System.Drawing.Size(134, 175);
            this.pb_kemejaPutih.TabIndex = 1;
            this.pb_kemejaPutih.TabStop = false;
            // 
            // pb_kemejaHitam
            // 
            this.pb_kemejaHitam.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pb_kemejaHitam.BackgroundImage")));
            this.pb_kemejaHitam.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.pb_kemejaHitam.Location = new System.Drawing.Point(40, 30);
            this.pb_kemejaHitam.Name = "pb_kemejaHitam";
            this.pb_kemejaHitam.Size = new System.Drawing.Size(134, 175);
            this.pb_kemejaHitam.TabIndex = 0;
            this.pb_kemejaHitam.TabStop = false;
            // 
            // panel_pants
            // 
            this.panel_pants.Controls.Add(this.btn_celpenJeans);
            this.panel_pants.Controls.Add(this.btn_celpenHijau);
            this.panel_pants.Controls.Add(this.btn_celpenKhaki);
            this.panel_pants.Controls.Add(this.lbl_hargaCelpenJeans);
            this.panel_pants.Controls.Add(this.lbl_hargaCelpenHijau);
            this.panel_pants.Controls.Add(this.lbl_hargaCelpenKhaki);
            this.panel_pants.Controls.Add(this.lbl_celpenJeans);
            this.panel_pants.Controls.Add(this.lbl_celpenHijau);
            this.panel_pants.Controls.Add(this.lbl_celpenKhaki);
            this.panel_pants.Controls.Add(this.pb_pantsJeans);
            this.panel_pants.Controls.Add(this.pb_pantshijau);
            this.panel_pants.Controls.Add(this.pb_pantskhaki);
            this.panel_pants.Location = new System.Drawing.Point(35, 100);
            this.panel_pants.Name = "panel_pants";
            this.panel_pants.Size = new System.Drawing.Size(662, 438);
            this.panel_pants.TabIndex = 13;
            this.panel_pants.Visible = false;
            // 
            // btn_celpenJeans
            // 
            this.btn_celpenJeans.Location = new System.Drawing.Point(406, 265);
            this.btn_celpenJeans.Name = "btn_celpenJeans";
            this.btn_celpenJeans.Size = new System.Drawing.Size(84, 52);
            this.btn_celpenJeans.TabIndex = 11;
            this.btn_celpenJeans.Text = "Add to Cart";
            this.btn_celpenJeans.UseVisualStyleBackColor = true;
            this.btn_celpenJeans.Click += new System.EventHandler(this.btn_celpenJeans_Click);
            // 
            // btn_celpenHijau
            // 
            this.btn_celpenHijau.Location = new System.Drawing.Point(237, 265);
            this.btn_celpenHijau.Name = "btn_celpenHijau";
            this.btn_celpenHijau.Size = new System.Drawing.Size(84, 52);
            this.btn_celpenHijau.TabIndex = 10;
            this.btn_celpenHijau.Text = "Add to Cart";
            this.btn_celpenHijau.UseVisualStyleBackColor = true;
            this.btn_celpenHijau.Click += new System.EventHandler(this.btn_celpenHijau_Click);
            // 
            // btn_celpenKhaki
            // 
            this.btn_celpenKhaki.Location = new System.Drawing.Point(62, 265);
            this.btn_celpenKhaki.Name = "btn_celpenKhaki";
            this.btn_celpenKhaki.Size = new System.Drawing.Size(84, 52);
            this.btn_celpenKhaki.TabIndex = 9;
            this.btn_celpenKhaki.Text = "Add to Cart";
            this.btn_celpenKhaki.UseVisualStyleBackColor = true;
            this.btn_celpenKhaki.Click += new System.EventHandler(this.btn_celpenKhaki_Click);
            // 
            // lbl_hargaCelpenJeans
            // 
            this.lbl_hargaCelpenJeans.AutoSize = true;
            this.lbl_hargaCelpenJeans.Location = new System.Drawing.Point(400, 242);
            this.lbl_hargaCelpenJeans.Name = "lbl_hargaCelpenJeans";
            this.lbl_hargaCelpenJeans.Size = new System.Drawing.Size(92, 20);
            this.lbl_hargaCelpenJeans.TabIndex = 8;
            this.lbl_hargaCelpenJeans.Text = "Rp 500.000";
            // 
            // lbl_hargaCelpenHijau
            // 
            this.lbl_hargaCelpenHijau.AutoSize = true;
            this.lbl_hargaCelpenHijau.Location = new System.Drawing.Point(233, 242);
            this.lbl_hargaCelpenHijau.Name = "lbl_hargaCelpenHijau";
            this.lbl_hargaCelpenHijau.Size = new System.Drawing.Size(92, 20);
            this.lbl_hargaCelpenHijau.TabIndex = 7;
            this.lbl_hargaCelpenHijau.Text = "Rp 350.000";
            // 
            // lbl_hargaCelpenKhaki
            // 
            this.lbl_hargaCelpenKhaki.AutoSize = true;
            this.lbl_hargaCelpenKhaki.Location = new System.Drawing.Point(58, 242);
            this.lbl_hargaCelpenKhaki.Name = "lbl_hargaCelpenKhaki";
            this.lbl_hargaCelpenKhaki.Size = new System.Drawing.Size(92, 20);
            this.lbl_hargaCelpenKhaki.TabIndex = 6;
            this.lbl_hargaCelpenKhaki.Text = "Rp 350.000";
            // 
            // lbl_celpenJeans
            // 
            this.lbl_celpenJeans.AutoSize = true;
            this.lbl_celpenJeans.Location = new System.Drawing.Point(396, 219);
            this.lbl_celpenJeans.Name = "lbl_celpenJeans";
            this.lbl_celpenJeans.Size = new System.Drawing.Size(103, 20);
            this.lbl_celpenJeans.TabIndex = 5;
            this.lbl_celpenJeans.Text = "Jeans Shorts";
            // 
            // lbl_celpenHijau
            // 
            this.lbl_celpenHijau.AutoSize = true;
            this.lbl_celpenHijau.Location = new System.Drawing.Point(228, 219);
            this.lbl_celpenHijau.Name = "lbl_celpenHijau";
            this.lbl_celpenHijau.Size = new System.Drawing.Size(105, 20);
            this.lbl_celpenHijau.TabIndex = 4;
            this.lbl_celpenHijau.Text = "Green Shorts";
            // 
            // lbl_celpenKhaki
            // 
            this.lbl_celpenKhaki.AutoSize = true;
            this.lbl_celpenKhaki.Location = new System.Drawing.Point(60, 219);
            this.lbl_celpenKhaki.Name = "lbl_celpenKhaki";
            this.lbl_celpenKhaki.Size = new System.Drawing.Size(99, 20);
            this.lbl_celpenKhaki.TabIndex = 3;
            this.lbl_celpenKhaki.Text = "Khaki Shorts";
            // 
            // pb_pantsJeans
            // 
            this.pb_pantsJeans.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pb_pantsJeans.BackgroundImage")));
            this.pb_pantsJeans.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.pb_pantsJeans.Location = new System.Drawing.Point(382, 30);
            this.pb_pantsJeans.Name = "pb_pantsJeans";
            this.pb_pantsJeans.Size = new System.Drawing.Size(134, 175);
            this.pb_pantsJeans.TabIndex = 2;
            this.pb_pantsJeans.TabStop = false;
            // 
            // pb_pantshijau
            // 
            this.pb_pantshijau.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pb_pantshijau.BackgroundImage")));
            this.pb_pantshijau.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.pb_pantshijau.Location = new System.Drawing.Point(209, 30);
            this.pb_pantshijau.Name = "pb_pantshijau";
            this.pb_pantshijau.Size = new System.Drawing.Size(134, 175);
            this.pb_pantshijau.TabIndex = 1;
            this.pb_pantshijau.TabStop = false;
            // 
            // pb_pantskhaki
            // 
            this.pb_pantskhaki.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pb_pantskhaki.BackgroundImage")));
            this.pb_pantskhaki.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.pb_pantskhaki.Location = new System.Drawing.Point(40, 30);
            this.pb_pantskhaki.Name = "pb_pantskhaki";
            this.pb_pantskhaki.Size = new System.Drawing.Size(134, 175);
            this.pb_pantskhaki.TabIndex = 0;
            this.pb_pantskhaki.TabStop = false;
            // 
            // panel_long
            // 
            this.panel_long.Controls.Add(this.btn_celpanKhaki);
            this.panel_long.Controls.Add(this.btn_celpanHijau);
            this.panel_long.Controls.Add(this.btn_celpanHitam);
            this.panel_long.Controls.Add(this.lbl_hargaCelpanKhaki);
            this.panel_long.Controls.Add(this.lbl_hargaCelpanHijau);
            this.panel_long.Controls.Add(this.lbl_hargaCelpanHitam);
            this.panel_long.Controls.Add(this.lbll_celpanKhaki);
            this.panel_long.Controls.Add(this.lbll_celpanHIjau);
            this.panel_long.Controls.Add(this.lbll_celpanHItam);
            this.panel_long.Controls.Add(this.pb_celpanKhaki);
            this.panel_long.Controls.Add(this.pb_celpanHijau);
            this.panel_long.Controls.Add(this.pb_celpanHitam);
            this.panel_long.Location = new System.Drawing.Point(22, 78);
            this.panel_long.Name = "panel_long";
            this.panel_long.Size = new System.Drawing.Size(689, 412);
            this.panel_long.TabIndex = 14;
            this.panel_long.Visible = false;
            // 
            // btn_celpanKhaki
            // 
            this.btn_celpanKhaki.Location = new System.Drawing.Point(406, 265);
            this.btn_celpanKhaki.Name = "btn_celpanKhaki";
            this.btn_celpanKhaki.Size = new System.Drawing.Size(84, 52);
            this.btn_celpanKhaki.TabIndex = 11;
            this.btn_celpanKhaki.Text = "Add to Cart";
            this.btn_celpanKhaki.UseVisualStyleBackColor = true;
            this.btn_celpanKhaki.Click += new System.EventHandler(this.btn_celpanKhaki_Click);
            // 
            // btn_celpanHijau
            // 
            this.btn_celpanHijau.Location = new System.Drawing.Point(237, 265);
            this.btn_celpanHijau.Name = "btn_celpanHijau";
            this.btn_celpanHijau.Size = new System.Drawing.Size(84, 52);
            this.btn_celpanHijau.TabIndex = 10;
            this.btn_celpanHijau.Text = "Add to Cart";
            this.btn_celpanHijau.UseVisualStyleBackColor = true;
            this.btn_celpanHijau.Click += new System.EventHandler(this.btn_celpanHijau_Click);
            // 
            // btn_celpanHitam
            // 
            this.btn_celpanHitam.Location = new System.Drawing.Point(62, 265);
            this.btn_celpanHitam.Name = "btn_celpanHitam";
            this.btn_celpanHitam.Size = new System.Drawing.Size(84, 52);
            this.btn_celpanHitam.TabIndex = 9;
            this.btn_celpanHitam.Text = "Add to Cart";
            this.btn_celpanHitam.UseVisualStyleBackColor = true;
            this.btn_celpanHitam.Click += new System.EventHandler(this.btn_celpanHitam_Click);
            // 
            // lbl_hargaCelpanKhaki
            // 
            this.lbl_hargaCelpanKhaki.AutoSize = true;
            this.lbl_hargaCelpanKhaki.Location = new System.Drawing.Point(400, 242);
            this.lbl_hargaCelpanKhaki.Name = "lbl_hargaCelpanKhaki";
            this.lbl_hargaCelpanKhaki.Size = new System.Drawing.Size(92, 20);
            this.lbl_hargaCelpanKhaki.TabIndex = 8;
            this.lbl_hargaCelpanKhaki.Text = "Rp 400.000";
            // 
            // lbl_hargaCelpanHijau
            // 
            this.lbl_hargaCelpanHijau.AutoSize = true;
            this.lbl_hargaCelpanHijau.Location = new System.Drawing.Point(233, 242);
            this.lbl_hargaCelpanHijau.Name = "lbl_hargaCelpanHijau";
            this.lbl_hargaCelpanHijau.Size = new System.Drawing.Size(92, 20);
            this.lbl_hargaCelpanHijau.TabIndex = 7;
            this.lbl_hargaCelpanHijau.Text = "Rp 400.000";
            // 
            // lbl_hargaCelpanHitam
            // 
            this.lbl_hargaCelpanHitam.AutoSize = true;
            this.lbl_hargaCelpanHitam.Location = new System.Drawing.Point(58, 242);
            this.lbl_hargaCelpanHitam.Name = "lbl_hargaCelpanHitam";
            this.lbl_hargaCelpanHitam.Size = new System.Drawing.Size(92, 20);
            this.lbl_hargaCelpanHitam.TabIndex = 6;
            this.lbl_hargaCelpanHitam.Text = "Rp 400.000";
            // 
            // lbll_celpanKhaki
            // 
            this.lbll_celpanKhaki.AutoSize = true;
            this.lbll_celpanKhaki.Location = new System.Drawing.Point(401, 219);
            this.lbll_celpanKhaki.Name = "lbll_celpanKhaki";
            this.lbll_celpanKhaki.Size = new System.Drawing.Size(93, 20);
            this.lbll_celpanKhaki.TabIndex = 5;
            this.lbll_celpanKhaki.Text = "Khaki Pants";
            // 
            // lbll_celpanHIjau
            // 
            this.lbll_celpanHIjau.AutoSize = true;
            this.lbll_celpanHIjau.Location = new System.Drawing.Point(228, 219);
            this.lbll_celpanHIjau.Name = "lbll_celpanHIjau";
            this.lbll_celpanHIjau.Size = new System.Drawing.Size(99, 20);
            this.lbll_celpanHIjau.TabIndex = 4;
            this.lbll_celpanHIjau.Text = "Green Pants";
            // 
            // lbll_celpanHItam
            // 
            this.lbll_celpanHItam.AutoSize = true;
            this.lbll_celpanHItam.Location = new System.Drawing.Point(57, 219);
            this.lbll_celpanHItam.Name = "lbll_celpanHItam";
            this.lbll_celpanHItam.Size = new System.Drawing.Size(93, 20);
            this.lbll_celpanHItam.TabIndex = 3;
            this.lbll_celpanHItam.Text = "Black Pants";
            // 
            // pb_celpanKhaki
            // 
            this.pb_celpanKhaki.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pb_celpanKhaki.BackgroundImage")));
            this.pb_celpanKhaki.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.pb_celpanKhaki.Location = new System.Drawing.Point(382, 30);
            this.pb_celpanKhaki.Name = "pb_celpanKhaki";
            this.pb_celpanKhaki.Size = new System.Drawing.Size(134, 175);
            this.pb_celpanKhaki.TabIndex = 2;
            this.pb_celpanKhaki.TabStop = false;
            // 
            // pb_celpanHijau
            // 
            this.pb_celpanHijau.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pb_celpanHijau.BackgroundImage")));
            this.pb_celpanHijau.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.pb_celpanHijau.Location = new System.Drawing.Point(209, 30);
            this.pb_celpanHijau.Name = "pb_celpanHijau";
            this.pb_celpanHijau.Size = new System.Drawing.Size(134, 175);
            this.pb_celpanHijau.TabIndex = 1;
            this.pb_celpanHijau.TabStop = false;
            // 
            // pb_celpanHitam
            // 
            this.pb_celpanHitam.BackColor = System.Drawing.SystemColors.ControlLight;
            this.pb_celpanHitam.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pb_celpanHitam.BackgroundImage")));
            this.pb_celpanHitam.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.pb_celpanHitam.Location = new System.Drawing.Point(40, 30);
            this.pb_celpanHitam.Name = "pb_celpanHitam";
            this.pb_celpanHitam.Size = new System.Drawing.Size(134, 175);
            this.pb_celpanHitam.TabIndex = 0;
            this.pb_celpanHitam.TabStop = false;
            // 
            // panel_jewelleries
            // 
            this.panel_jewelleries.Controls.Add(this.btn_bag);
            this.panel_jewelleries.Controls.Add(this.btn_belt);
            this.panel_jewelleries.Controls.Add(this.btn_cap);
            this.panel_jewelleries.Controls.Add(this.lbl_hargaBag);
            this.panel_jewelleries.Controls.Add(this.lbl_hargaBelt);
            this.panel_jewelleries.Controls.Add(this.lbl_hargaCap);
            this.panel_jewelleries.Controls.Add(this.lbl_bag);
            this.panel_jewelleries.Controls.Add(this.lbl_belt);
            this.panel_jewelleries.Controls.Add(this.lbl_cap);
            this.panel_jewelleries.Controls.Add(this.pb_bag);
            this.panel_jewelleries.Controls.Add(this.pb_belt);
            this.panel_jewelleries.Controls.Add(this.pb_cap);
            this.panel_jewelleries.Location = new System.Drawing.Point(38, 60);
            this.panel_jewelleries.Name = "panel_jewelleries";
            this.panel_jewelleries.Size = new System.Drawing.Size(709, 416);
            this.panel_jewelleries.TabIndex = 15;
            this.panel_jewelleries.Visible = false;
            // 
            // btn_bag
            // 
            this.btn_bag.Location = new System.Drawing.Point(406, 265);
            this.btn_bag.Name = "btn_bag";
            this.btn_bag.Size = new System.Drawing.Size(84, 52);
            this.btn_bag.TabIndex = 11;
            this.btn_bag.Text = "Add to Cart";
            this.btn_bag.UseVisualStyleBackColor = true;
            this.btn_bag.Click += new System.EventHandler(this.btn_bag_Click);
            // 
            // btn_belt
            // 
            this.btn_belt.Location = new System.Drawing.Point(237, 265);
            this.btn_belt.Name = "btn_belt";
            this.btn_belt.Size = new System.Drawing.Size(84, 52);
            this.btn_belt.TabIndex = 10;
            this.btn_belt.Text = "Add to Cart";
            this.btn_belt.UseVisualStyleBackColor = true;
            this.btn_belt.Click += new System.EventHandler(this.btn_belt_Click);
            // 
            // btn_cap
            // 
            this.btn_cap.Location = new System.Drawing.Point(62, 265);
            this.btn_cap.Name = "btn_cap";
            this.btn_cap.Size = new System.Drawing.Size(84, 52);
            this.btn_cap.TabIndex = 9;
            this.btn_cap.Text = "Add to Cart";
            this.btn_cap.UseVisualStyleBackColor = true;
            this.btn_cap.Click += new System.EventHandler(this.btn_cap_Click);
            // 
            // lbl_hargaBag
            // 
            this.lbl_hargaBag.AutoSize = true;
            this.lbl_hargaBag.Location = new System.Drawing.Point(400, 242);
            this.lbl_hargaBag.Name = "lbl_hargaBag";
            this.lbl_hargaBag.Size = new System.Drawing.Size(92, 20);
            this.lbl_hargaBag.TabIndex = 8;
            this.lbl_hargaBag.Text = "Rp 200.000";
            // 
            // lbl_hargaBelt
            // 
            this.lbl_hargaBelt.AutoSize = true;
            this.lbl_hargaBelt.Location = new System.Drawing.Point(233, 242);
            this.lbl_hargaBelt.Name = "lbl_hargaBelt";
            this.lbl_hargaBelt.Size = new System.Drawing.Size(92, 20);
            this.lbl_hargaBelt.TabIndex = 7;
            this.lbl_hargaBelt.Text = "Rp 400.000";
            // 
            // lbl_hargaCap
            // 
            this.lbl_hargaCap.AutoSize = true;
            this.lbl_hargaCap.Location = new System.Drawing.Point(58, 242);
            this.lbl_hargaCap.Name = "lbl_hargaCap";
            this.lbl_hargaCap.Size = new System.Drawing.Size(92, 20);
            this.lbl_hargaCap.TabIndex = 6;
            this.lbl_hargaCap.Text = "Rp 200.000";
            // 
            // lbl_bag
            // 
            this.lbl_bag.AutoSize = true;
            this.lbl_bag.Location = new System.Drawing.Point(395, 219);
            this.lbl_bag.Name = "lbl_bag";
            this.lbl_bag.Size = new System.Drawing.Size(109, 20);
            this.lbl_bag.TabIndex = 5;
            this.lbl_bag.Text = "Dumpling Bag";
            // 
            // lbl_belt
            // 
            this.lbl_belt.AutoSize = true;
            this.lbl_belt.Location = new System.Drawing.Point(233, 222);
            this.lbl_belt.Name = "lbl_belt";
            this.lbl_belt.Size = new System.Drawing.Size(96, 20);
            this.lbl_belt.TabIndex = 4;
            this.lbl_belt.Text = "Leather Belt";
            // 
            // lbl_cap
            // 
            this.lbl_cap.AutoSize = true;
            this.lbl_cap.Location = new System.Drawing.Point(57, 219);
            this.lbl_cap.Name = "lbl_cap";
            this.lbl_cap.Size = new System.Drawing.Size(103, 20);
            this.lbl_cap.TabIndex = 3;
            this.lbl_cap.Text = "Baseball Cap";
            // 
            // pb_bag
            // 
            this.pb_bag.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pb_bag.BackgroundImage")));
            this.pb_bag.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.pb_bag.Location = new System.Drawing.Point(382, 30);
            this.pb_bag.Name = "pb_bag";
            this.pb_bag.Size = new System.Drawing.Size(134, 175);
            this.pb_bag.TabIndex = 2;
            this.pb_bag.TabStop = false;
            // 
            // pb_belt
            // 
            this.pb_belt.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pb_belt.BackgroundImage")));
            this.pb_belt.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.pb_belt.Location = new System.Drawing.Point(209, 30);
            this.pb_belt.Name = "pb_belt";
            this.pb_belt.Size = new System.Drawing.Size(134, 175);
            this.pb_belt.TabIndex = 1;
            this.pb_belt.TabStop = false;
            // 
            // pb_cap
            // 
            this.pb_cap.BackColor = System.Drawing.SystemColors.ControlLight;
            this.pb_cap.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pb_cap.BackgroundImage")));
            this.pb_cap.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.pb_cap.Location = new System.Drawing.Point(40, 30);
            this.pb_cap.Name = "pb_cap";
            this.pb_cap.Size = new System.Drawing.Size(134, 175);
            this.pb_cap.TabIndex = 0;
            this.pb_cap.TabStop = false;
            // 
            // panel_shoes
            // 
            this.panel_shoes.Controls.Add(this.btn_loafers);
            this.panel_shoes.Controls.Add(this.btn_platform);
            this.panel_shoes.Controls.Add(this.btn_slipOn);
            this.panel_shoes.Controls.Add(this.lbl_hargaLoafers);
            this.panel_shoes.Controls.Add(this.lbl_hargaPlatform);
            this.panel_shoes.Controls.Add(this.lbl_hargaSlipOn);
            this.panel_shoes.Controls.Add(this.lbl_loafers);
            this.panel_shoes.Controls.Add(this.lbl_platformShoes);
            this.panel_shoes.Controls.Add(this.lbl_slipOn);
            this.panel_shoes.Controls.Add(this.pb_loafers);
            this.panel_shoes.Controls.Add(this.pb_platformSandal);
            this.panel_shoes.Controls.Add(this.pb_slipon);
            this.panel_shoes.Location = new System.Drawing.Point(22, 100);
            this.panel_shoes.Name = "panel_shoes";
            this.panel_shoes.Size = new System.Drawing.Size(712, 403);
            this.panel_shoes.TabIndex = 16;
            this.panel_shoes.Visible = false;
            // 
            // btn_loafers
            // 
            this.btn_loafers.Location = new System.Drawing.Point(406, 265);
            this.btn_loafers.Name = "btn_loafers";
            this.btn_loafers.Size = new System.Drawing.Size(84, 52);
            this.btn_loafers.TabIndex = 11;
            this.btn_loafers.Text = "Add to Cart";
            this.btn_loafers.UseVisualStyleBackColor = true;
            this.btn_loafers.Click += new System.EventHandler(this.btn_loafers_Click);
            // 
            // btn_platform
            // 
            this.btn_platform.Location = new System.Drawing.Point(237, 265);
            this.btn_platform.Name = "btn_platform";
            this.btn_platform.Size = new System.Drawing.Size(84, 52);
            this.btn_platform.TabIndex = 10;
            this.btn_platform.Text = "Add to Cart";
            this.btn_platform.UseVisualStyleBackColor = true;
            this.btn_platform.Click += new System.EventHandler(this.btn_platform_Click);
            // 
            // btn_slipOn
            // 
            this.btn_slipOn.Location = new System.Drawing.Point(62, 265);
            this.btn_slipOn.Name = "btn_slipOn";
            this.btn_slipOn.Size = new System.Drawing.Size(84, 52);
            this.btn_slipOn.TabIndex = 9;
            this.btn_slipOn.Text = "Add to Cart";
            this.btn_slipOn.UseVisualStyleBackColor = true;
            this.btn_slipOn.Click += new System.EventHandler(this.btn_slipOn_Click);
            // 
            // lbl_hargaLoafers
            // 
            this.lbl_hargaLoafers.AutoSize = true;
            this.lbl_hargaLoafers.Location = new System.Drawing.Point(400, 242);
            this.lbl_hargaLoafers.Name = "lbl_hargaLoafers";
            this.lbl_hargaLoafers.Size = new System.Drawing.Size(105, 20);
            this.lbl_hargaLoafers.TabIndex = 8;
            this.lbl_hargaLoafers.Text = "Rp 1.000.000";
            // 
            // lbl_hargaPlatform
            // 
            this.lbl_hargaPlatform.AutoSize = true;
            this.lbl_hargaPlatform.Location = new System.Drawing.Point(233, 242);
            this.lbl_hargaPlatform.Name = "lbl_hargaPlatform";
            this.lbl_hargaPlatform.Size = new System.Drawing.Size(92, 20);
            this.lbl_hargaPlatform.TabIndex = 7;
            this.lbl_hargaPlatform.Text = "Rp 600.000";
            // 
            // lbl_hargaSlipOn
            // 
            this.lbl_hargaSlipOn.AutoSize = true;
            this.lbl_hargaSlipOn.Location = new System.Drawing.Point(58, 242);
            this.lbl_hargaSlipOn.Name = "lbl_hargaSlipOn";
            this.lbl_hargaSlipOn.Size = new System.Drawing.Size(92, 20);
            this.lbl_hargaSlipOn.TabIndex = 6;
            this.lbl_hargaSlipOn.Text = "Rp 800.000";
            // 
            // lbl_loafers
            // 
            this.lbl_loafers.AutoSize = true;
            this.lbl_loafers.Location = new System.Drawing.Point(413, 219);
            this.lbl_loafers.Name = "lbl_loafers";
            this.lbl_loafers.Size = new System.Drawing.Size(63, 20);
            this.lbl_loafers.TabIndex = 5;
            this.lbl_loafers.Text = "Loafers";
            // 
            // lbl_platformShoes
            // 
            this.lbl_platformShoes.AutoSize = true;
            this.lbl_platformShoes.Location = new System.Drawing.Point(220, 222);
            this.lbl_platformShoes.Name = "lbl_platformShoes";
            this.lbl_platformShoes.Size = new System.Drawing.Size(122, 20);
            this.lbl_platformShoes.TabIndex = 4;
            this.lbl_platformShoes.Text = "Platform Sandal";
            // 
            // lbl_slipOn
            // 
            this.lbl_slipOn.AutoSize = true;
            this.lbl_slipOn.Location = new System.Drawing.Point(57, 219);
            this.lbl_slipOn.Name = "lbl_slipOn";
            this.lbl_slipOn.Size = new System.Drawing.Size(110, 20);
            this.lbl_slipOn.TabIndex = 3;
            this.lbl_slipOn.Text = "Slip On Shoes";
            // 
            // pb_loafers
            // 
            this.pb_loafers.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pb_loafers.BackgroundImage")));
            this.pb_loafers.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.pb_loafers.Location = new System.Drawing.Point(382, 30);
            this.pb_loafers.Name = "pb_loafers";
            this.pb_loafers.Size = new System.Drawing.Size(134, 175);
            this.pb_loafers.TabIndex = 2;
            this.pb_loafers.TabStop = false;
            // 
            // pb_platformSandal
            // 
            this.pb_platformSandal.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pb_platformSandal.BackgroundImage")));
            this.pb_platformSandal.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.pb_platformSandal.Location = new System.Drawing.Point(209, 30);
            this.pb_platformSandal.Name = "pb_platformSandal";
            this.pb_platformSandal.Size = new System.Drawing.Size(134, 175);
            this.pb_platformSandal.TabIndex = 1;
            this.pb_platformSandal.TabStop = false;
            // 
            // pb_slipon
            // 
            this.pb_slipon.BackColor = System.Drawing.SystemColors.ControlLight;
            this.pb_slipon.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pb_slipon.BackgroundImage")));
            this.pb_slipon.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.pb_slipon.Location = new System.Drawing.Point(40, 30);
            this.pb_slipon.Name = "pb_slipon";
            this.pb_slipon.Size = new System.Drawing.Size(134, 175);
            this.pb_slipon.TabIndex = 0;
            this.pb_slipon.TabStop = false;
            // 
            // panel_others
            // 
            this.panel_others.Controls.Add(this.tb_hargaUpload);
            this.panel_others.Controls.Add(this.tb_itemUpload);
            this.panel_others.Controls.Add(this.btn_upload);
            this.panel_others.Controls.Add(this.btn_uploadImage);
            this.panel_others.Controls.Add(this.lbl_itemPrice);
            this.panel_others.Controls.Add(this.lbl_inputNama);
            this.panel_others.Controls.Add(this.lbl_upload);
            this.panel_others.Controls.Add(this.pb_others);
            this.panel_others.Location = new System.Drawing.Point(25, 39);
            this.panel_others.Name = "panel_others";
            this.panel_others.Size = new System.Drawing.Size(731, 523);
            this.panel_others.TabIndex = 17;
            this.panel_others.Visible = false;
            // 
            // tb_hargaUpload
            // 
            this.tb_hargaUpload.Enabled = false;
            this.tb_hargaUpload.Location = new System.Drawing.Point(206, 164);
            this.tb_hargaUpload.Name = "tb_hargaUpload";
            this.tb_hargaUpload.Size = new System.Drawing.Size(130, 26);
            this.tb_hargaUpload.TabIndex = 13;
            this.tb_hargaUpload.TextChanged += new System.EventHandler(this.tb_hargaUpload_TextChanged);
            this.tb_hargaUpload.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.tb_hargaUpload_KeyPress);
            // 
            // tb_itemUpload
            // 
            this.tb_itemUpload.Enabled = false;
            this.tb_itemUpload.Location = new System.Drawing.Point(206, 106);
            this.tb_itemUpload.Name = "tb_itemUpload";
            this.tb_itemUpload.Size = new System.Drawing.Size(130, 26);
            this.tb_itemUpload.TabIndex = 12;
            this.tb_itemUpload.TextChanged += new System.EventHandler(this.tb_itemUpload_TextChanged);
            // 
            // btn_upload
            // 
            this.btn_upload.Enabled = false;
            this.btn_upload.Location = new System.Drawing.Point(206, 208);
            this.btn_upload.Name = "btn_upload";
            this.btn_upload.Size = new System.Drawing.Size(110, 36);
            this.btn_upload.TabIndex = 11;
            this.btn_upload.Text = "Add to Cart";
            this.btn_upload.UseVisualStyleBackColor = true;
            this.btn_upload.Click += new System.EventHandler(this.btn_upload_Click);
            // 
            // btn_uploadImage
            // 
            this.btn_uploadImage.Location = new System.Drawing.Point(197, 23);
            this.btn_uploadImage.Name = "btn_uploadImage";
            this.btn_uploadImage.Size = new System.Drawing.Size(74, 33);
            this.btn_uploadImage.TabIndex = 10;
            this.btn_uploadImage.Text = "Upload";
            this.btn_uploadImage.UseVisualStyleBackColor = true;
            this.btn_uploadImage.Click += new System.EventHandler(this.btn_uploadImage_Click);
            // 
            // lbl_itemPrice
            // 
            this.lbl_itemPrice.AutoSize = true;
            this.lbl_itemPrice.Location = new System.Drawing.Point(202, 141);
            this.lbl_itemPrice.Name = "lbl_itemPrice";
            this.lbl_itemPrice.Size = new System.Drawing.Size(84, 20);
            this.lbl_itemPrice.TabIndex = 6;
            this.lbl_itemPrice.Text = "Item Price:";
            // 
            // lbl_inputNama
            // 
            this.lbl_inputNama.AutoSize = true;
            this.lbl_inputNama.Location = new System.Drawing.Point(202, 83);
            this.lbl_inputNama.Name = "lbl_inputNama";
            this.lbl_inputNama.Size = new System.Drawing.Size(91, 20);
            this.lbl_inputNama.TabIndex = 4;
            this.lbl_inputNama.Text = "Item Name:";
            // 
            // lbl_upload
            // 
            this.lbl_upload.AutoSize = true;
            this.lbl_upload.Location = new System.Drawing.Point(53, 29);
            this.lbl_upload.Name = "lbl_upload";
            this.lbl_upload.Size = new System.Drawing.Size(109, 20);
            this.lbl_upload.TabIndex = 3;
            this.lbl_upload.Text = "Upload Image";
            // 
            // pb_others
            // 
            this.pb_others.BackColor = System.Drawing.SystemColors.ControlLight;
            this.pb_others.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.pb_others.Location = new System.Drawing.Point(40, 62);
            this.pb_others.Name = "pb_others";
            this.pb_others.Size = new System.Drawing.Size(134, 175);
            this.pb_others.TabIndex = 0;
            this.pb_others.TabStop = false;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1480, 619);
            this.Controls.Add(this.panel_others);
            this.Controls.Add(this.panel_shoes);
            this.Controls.Add(this.panel_jewelleries);
            this.Controls.Add(this.panel_pants);
            this.Controls.Add(this.panel_long);
            this.Controls.Add(this.panel_shirt);
            this.Controls.Add(this.btn_delete);
            this.Controls.Add(this.tb_total);
            this.Controls.Add(this.tb_subTotal);
            this.Controls.Add(this.lbl_Total);
            this.Controls.Add(this.lbl_subTotal);
            this.Controls.Add(this.dgv_keranjang);
            this.Controls.Add(this.panel_tshirt);
            this.Controls.Add(this.menuStrip1);
            this.MainMenuStrip = this.menuStrip1;
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.panel_tshirt.ResumeLayout(false);
            this.panel_tshirt.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pb_kaosBiru)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb_kaosPutih)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb_kaosHitam)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgv_keranjang)).EndInit();
            this.panel_shirt.ResumeLayout(false);
            this.panel_shirt.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pb_kemejaBiru)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb_kemejaPutih)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb_kemejaHitam)).EndInit();
            this.panel_pants.ResumeLayout(false);
            this.panel_pants.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pb_pantsJeans)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb_pantshijau)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb_pantskhaki)).EndInit();
            this.panel_long.ResumeLayout(false);
            this.panel_long.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pb_celpanKhaki)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb_celpanHijau)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb_celpanHitam)).EndInit();
            this.panel_jewelleries.ResumeLayout(false);
            this.panel_jewelleries.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pb_bag)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb_belt)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb_cap)).EndInit();
            this.panel_shoes.ResumeLayout(false);
            this.panel_shoes.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pb_loafers)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb_platformSandal)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb_slipon)).EndInit();
            this.panel_others.ResumeLayout(false);
            this.panel_others.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pb_others)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem tsm_top;
        private System.Windows.Forms.ToolStripMenuItem tShirtToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem shirtToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem tsm_bottom;
        private System.Windows.Forms.ToolStripMenuItem pantsToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem longPantsToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem tsm_accesories;
        private System.Windows.Forms.ToolStripMenuItem shoesToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem jewelleriesToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem tsm_others;
        private System.Windows.Forms.Panel panel_tshirt;
        private System.Windows.Forms.PictureBox pb_kaosBiru;
        private System.Windows.Forms.PictureBox pb_kaosPutih;
        private System.Windows.Forms.PictureBox pb_kaosHitam;
        private System.Windows.Forms.DataGridView dgv_keranjang;
        private System.Windows.Forms.Label lbl_subTotal;
        private System.Windows.Forms.Label lbl_Total;
        private System.Windows.Forms.TextBox tb_subTotal;
        private System.Windows.Forms.TextBox tb_total;
        private System.Windows.Forms.Button btn_kaosBiru;
        private System.Windows.Forms.Button btn_kaosPutih;
        private System.Windows.Forms.Button btn_kaosHitam;
        private System.Windows.Forms.Label lbl_hargaKaosBiru;
        private System.Windows.Forms.Label lbl_hargaKaosPutih;
        private System.Windows.Forms.Label lbl_hargaKaosHitam;
        private System.Windows.Forms.Label lbl_kaosBiru;
        private System.Windows.Forms.Label lbl_kaosPutih;
        private System.Windows.Forms.Label lbl_kaosHitam;
        private System.Windows.Forms.Button btn_delete;
        private System.Windows.Forms.Panel panel_shirt;
        private System.Windows.Forms.Button btn_kemejaBiru;
        private System.Windows.Forms.Button btn_kemejaPutih;
        private System.Windows.Forms.Button btn_kemejaHitam;
        private System.Windows.Forms.Label lbl_hargaKemejaBiru;
        private System.Windows.Forms.Label lbl_hargaKemejaPutih;
        private System.Windows.Forms.Label lbl_hargaKemejaHitam;
        private System.Windows.Forms.Label lbl_kemejaBiru;
        private System.Windows.Forms.Label lbl_kemejaPutih;
        private System.Windows.Forms.Label lbl_kemejaHitam;
        private System.Windows.Forms.PictureBox pb_kemejaBiru;
        private System.Windows.Forms.PictureBox pb_kemejaPutih;
        private System.Windows.Forms.PictureBox pb_kemejaHitam;
        private System.Windows.Forms.Panel panel_pants;
        private System.Windows.Forms.Button btn_celpenJeans;
        private System.Windows.Forms.Button btn_celpenHijau;
        private System.Windows.Forms.Button btn_celpenKhaki;
        private System.Windows.Forms.Label lbl_hargaCelpenJeans;
        private System.Windows.Forms.Label lbl_hargaCelpenHijau;
        private System.Windows.Forms.Label lbl_hargaCelpenKhaki;
        private System.Windows.Forms.Label lbl_celpenJeans;
        private System.Windows.Forms.Label lbl_celpenHijau;
        private System.Windows.Forms.Label lbl_celpenKhaki;
        private System.Windows.Forms.PictureBox pb_pantsJeans;
        private System.Windows.Forms.PictureBox pb_pantshijau;
        private System.Windows.Forms.PictureBox pb_pantskhaki;
        private System.Windows.Forms.Panel panel_long;
        private System.Windows.Forms.Button btn_celpanKhaki;
        private System.Windows.Forms.Button btn_celpanHijau;
        private System.Windows.Forms.Button btn_celpanHitam;
        private System.Windows.Forms.Label lbl_hargaCelpanKhaki;
        private System.Windows.Forms.Label lbl_hargaCelpanHijau;
        private System.Windows.Forms.Label lbl_hargaCelpanHitam;
        private System.Windows.Forms.Label lbll_celpanKhaki;
        private System.Windows.Forms.Label lbll_celpanHIjau;
        private System.Windows.Forms.Label lbll_celpanHItam;
        private System.Windows.Forms.PictureBox pb_celpanKhaki;
        private System.Windows.Forms.PictureBox pb_celpanHijau;
        private System.Windows.Forms.PictureBox pb_celpanHitam;
        private System.Windows.Forms.Panel panel_jewelleries;
        private System.Windows.Forms.Button btn_bag;
        private System.Windows.Forms.Button btn_belt;
        private System.Windows.Forms.Button btn_cap;
        private System.Windows.Forms.Label lbl_hargaBag;
        private System.Windows.Forms.Label lbl_hargaBelt;
        private System.Windows.Forms.Label lbl_hargaCap;
        private System.Windows.Forms.Label lbl_bag;
        private System.Windows.Forms.Label lbl_belt;
        private System.Windows.Forms.Label lbl_cap;
        private System.Windows.Forms.PictureBox pb_bag;
        private System.Windows.Forms.PictureBox pb_belt;
        private System.Windows.Forms.PictureBox pb_cap;
        private System.Windows.Forms.Panel panel_shoes;
        private System.Windows.Forms.Button btn_loafers;
        private System.Windows.Forms.Button btn_platform;
        private System.Windows.Forms.Button btn_slipOn;
        private System.Windows.Forms.Label lbl_hargaLoafers;
        private System.Windows.Forms.Label lbl_hargaPlatform;
        private System.Windows.Forms.Label lbl_hargaSlipOn;
        private System.Windows.Forms.Label lbl_loafers;
        private System.Windows.Forms.Label lbl_platformShoes;
        private System.Windows.Forms.Label lbl_slipOn;
        private System.Windows.Forms.PictureBox pb_loafers;
        private System.Windows.Forms.PictureBox pb_platformSandal;
        private System.Windows.Forms.PictureBox pb_slipon;
        private System.Windows.Forms.Panel panel_others;
        private System.Windows.Forms.Button btn_upload;
        private System.Windows.Forms.Button btn_uploadImage;
        private System.Windows.Forms.Label lbl_itemPrice;
        private System.Windows.Forms.Label lbl_inputNama;
        private System.Windows.Forms.Label lbl_upload;
        private System.Windows.Forms.PictureBox pb_others;
        private System.Windows.Forms.TextBox tb_hargaUpload;
        private System.Windows.Forms.TextBox tb_itemUpload;
    }
}

