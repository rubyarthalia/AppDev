﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Reflection;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace TH14_S_2
{
    public partial class Form1 : Form
    {
        MySqlConnection connection;
        MySqlCommand command;
        MySqlDataAdapter adapter;

        string query;
        string date;
        string month;
        string year;

        DataTable dtTeamName;
        DataTable dtTHome = new DataTable();
        DataTable dtTAway = new DataTable();
        DataTable dtType = new DataTable();
        DataTable dtTampil = new DataTable();
        DataTable dtMatch = new DataTable();
        DataTable dtDMatch = new DataTable();
        DataTable dtTeam;
        DataTable dtTglMax;
        DataTable dtTglPilihan;

        int GoalHome = 0;
        int GoalAway = 0;

        public Form1()
        {
            InitializeComponent();
        }


        private void Form1_Load(object sender, EventArgs e)
        {
            connection = new MySqlConnection("server = localhost; uid = root; pwd = ; database = premier_league");

            try
            {
                connection.Open();

                query = "select team_name, team_id from team;";
                command = new MySqlCommand(query, connection);
                adapter = new MySqlDataAdapter(command);
                adapter.Fill(dtTHome);
                cb_THome.DataSource = dtTHome;
                cb_THome.ValueMember = "team_id";
                cb_THome.DisplayMember = "team_name";
                cb_THome.SelectedIndex = -1;

                query = "select team_name, team_id from team;";
                command = new MySqlCommand(query, connection);
                adapter = new MySqlDataAdapter(command);
                adapter.Fill(dtTAway);
                cb_TAway.DataSource = dtTAway;
                cb_TAway.ValueMember = "team_id";
                cb_TAway.DisplayMember = "team_name";
                cb_TAway.SelectedIndex = -1;

                dtTampil.Columns.Add("Minute");
                dtTampil.Columns.Add("Team ID");
                dtTampil.Columns.Add("Player ID");
                dtTampil.Columns.Add("Type");
                dgv_match.DataSource = dtTampil;

                dtDMatch.Columns.Add("Minute");
                dtDMatch.Columns.Add("Team");
                dtDMatch.Columns.Add("Player");
                dtDMatch.Columns.Add("Type");

            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error: {ex.Message}");
            }
            finally
            {
                connection.Close();
            }
        }

        public void cek()
        {
            dtTeam = new DataTable();

            if (cb_THome.SelectedValue == null || cb_TAway.SelectedValue == null)
            {
                return;
            }
            query = $"select team_id, team_name from team where team_id = '{cb_TAway.SelectedValue}' or team_id = '{cb_THome.SelectedValue}';";
            command = new MySqlCommand(query, connection);
            adapter = new MySqlDataAdapter(command);
            adapter.Fill(dtTeam);

            if (dtTeam.Rows.Count < 2)
            {
                MessageBox.Show("Team tidak boleh sama");
            }
            cb_team.DataSource = dtTeam;
            cb_team.ValueMember = "team_id";
            cb_team.DisplayMember = "team_name";
            cb_team.SelectedIndex = -1;
        }

        private void cb_THome_SelectedIndexChanged(object sender, EventArgs e)
        {
            cek();
        }

        private void cb_TAway_SelectedIndexChanged(object sender, EventArgs e)
        {
            cek();
        }

        private void dtp_match_ValueChanged(object sender, EventArgs e)
        {
            dtTglMax = new DataTable();
            dtTglPilihan = new DataTable();
            try
            {
                query = "select concat(date_format(m.match_date, '%Y'), date_format(m.match_date, '%m'), date_format(m.match_date, '%d')) as matchDate from `match` m order by 1 desc LIMIT 1;";
                command = new MySqlCommand(query, connection);
                adapter = new MySqlDataAdapter(command);
                adapter.Fill(dtTglMax);

                date = dtp_match.Value.Day.ToString();
                if (Convert.ToInt32(date) < 10)
                {
                    date = $"0{date}";
                }

                month = dtp_match.Value.Month.ToString();
                if (Convert.ToInt32(month) < 10)
                {
                    month = $"0{month}";
                }
                year = dtp_match.Value.Year.ToString();

                int pilihanDate = Convert.ToInt32($"{year}{month}{date}");
                int maxDate = Convert.ToInt32(dtTglMax.Rows[0][0]);
                if (pilihanDate >= maxDate)
                {
                    query = $"select match_id from `match` where match_id like '{year}%' order by 1 desc LIMIT 1";
                    command = new MySqlCommand(query, connection);
                    adapter = new MySqlDataAdapter(command);
                    adapter.Fill(dtTglPilihan);

                    if (dtTglPilihan.Rows.Count == 0)
                    {
                        tb_matchID.Text = $"{year}001";
                    }
                    else if (dtTglPilihan.Rows.Count == 1)
                    {
                        int cnt = 1;
                        int cntMatch = Convert.ToInt32(dtTglPilihan.Rows[0][0]) + cnt;
                        tb_matchID.Text = cntMatch.ToString();
                    }
                }
                else
                {
                    MessageBox.Show("Tanggal Invalid");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"matchdate value changed error: {ex.Message}");
            }
        }

        private void cb_team_SelectedIndexChanged(object sender, EventArgs e)
        {
            dtTeamName = new DataTable();
            query = $"select player.player_name, player.team_id from player, team where player.team_id = team.team_id and player.team_id = '{cb_team.SelectedValue}';";
            command = new MySqlCommand(query, connection);
            adapter = new MySqlDataAdapter(command);
            adapter.Fill(dtTeamName);

            cb_player.DataSource = dtTeamName;
            cb_player.ValueMember = "team_id";
            cb_player.DisplayMember = "player_name";
            cb_player.SelectedIndex = -1;
        }

        private void btn_add_Click(object sender, EventArgs e)
        {
            if (tb_matchID.Text == "" || tb_minute.Text == "" || cb_team.Text == "" || cb_player.Text == "" || cb_type.Text == "")
            {
                MessageBox.Show("Ada field yang kosong");
            }
            else
            {
                dtTampil.Rows.Add(tb_minute.Text, cb_team.Text, cb_player.Text, cb_type.Text);
                if (cb_type.Text == "GW")
                {
                    if (cb_TAway.Text == cb_team.Text)
                    {
                        GoalHome++;
                    }
                    else
                    {
                        GoalAway++;
                    }
                }
                else if (cb_type.Text == "GP" || cb_type.Text == "GO")
                {
                    if (cb_TAway.Text == cb_team.Text)
                    {
                        GoalAway++;
                    }
                    else
                    {
                        GoalHome++;
                    }
                }
                dtDMatch.Rows.Add(tb_minute.Text, cb_team.SelectedValue, cb_player.SelectedValue, cb_type.SelectedValue);
            }
        }

        private void btn_delete_Click(object sender, EventArgs e)
        {
            DataGridViewRow selectedRow = dgv_match.CurrentRow;
            int remove = 0;
            if (dgv_match.Rows.Count > 0)
            {
                for (int i = 0; i < dtTampil.Rows.Count; i++)
                {
                    if (dtTampil.Rows[i][0].ToString().Contains(selectedRow.Cells[0].Value.ToString()))
                    {
                        remove = i;
                    }
                }

                if (selectedRow.Cells[3].Value.ToString() == "GP" || selectedRow.Cells[3].Value.ToString() == "GO")
                {
                    if (cb_TAway.Text == cb_team.Text)
                    {
                        GoalAway--;
                    }
                    else
                    {
                        GoalHome--;
                    }
                }
                else if (selectedRow.Cells[3].Value.ToString() == "GW")
                {
                    if (cb_TAway.Text == cb_team.Text)
                    {
                        GoalHome--;
                    }
                    else
                    {
                        GoalAway--;
                    }
                }
                dtTampil.Rows.RemoveAt(remove);
                dtDMatch.Rows.RemoveAt(remove);
            }
            else
            {
                MessageBox.Show("Belum diselect bang");
            }

            dgv_match.Refresh();
            dgv_match.DataSource = dtTampil;
        }

        private void btn_insert_Click(object sender, EventArgs e)
        {
            if (tb_matchID.Text == "")
            {
                MessageBox.Show("Pilih tanggal pertandingan dulu");
            }
            else
            {
                connection.Open();
                foreach (DataRow dr in dtDMatch.Rows) 
                {
                    MessageBox.Show(dr[0].ToString());
                    query = $"insert into dmatch values ('{tb_matchID.Text}', '{dr[0].ToString()}', '{dr[1].ToString()}', '{dr[2].ToString()}', '{dr[3]}', 0)";
                    command = new MySqlCommand(query, connection);
                    command.ExecuteNonQuery();
                }

                query = $"insert into `match` values ('{tb_matchID.Text}', '{year}-{month}-{date}', '{cb_THome.SelectedValue}', '{cb_TAway.SelectedValue}', '{GoalHome}', '{GoalAway}', 'M002', 0);";
                command = new MySqlCommand(query, connection);
                command.ExecuteNonQuery();
                connection.Close();

                tb_matchID.Text = "";
                tb_minute.Text = "";
                cb_type.Text = "";
                cb_team.Text = "";
                cb_player.Text = "";
                GoalHome = 0;
                GoalAway = 0;
                dtTampil.Rows.Clear();
                dtDMatch.Rows.Clear();
            }
        }
    }
}
