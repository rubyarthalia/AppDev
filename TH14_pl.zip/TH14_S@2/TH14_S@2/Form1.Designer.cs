﻿namespace TH14_S_2
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btn_delete = new System.Windows.Forms.Button();
            this.btn_add = new System.Windows.Forms.Button();
            this.cb_type = new System.Windows.Forms.ComboBox();
            this.cb_player = new System.Windows.Forms.ComboBox();
            this.cb_team = new System.Windows.Forms.ComboBox();
            this.tb_minute = new System.Windows.Forms.TextBox();
            this.lbl_type = new System.Windows.Forms.Label();
            this.lbl_player = new System.Windows.Forms.Label();
            this.lbl_team = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.lbl_minute = new System.Windows.Forms.Label();
            this.dgv_match = new System.Windows.Forms.DataGridView();
            this.dtp_match = new System.Windows.Forms.DateTimePicker();
            this.lbl_TAway = new System.Windows.Forms.Label();
            this.lbl_matchDate = new System.Windows.Forms.Label();
            this.cb_THome = new System.Windows.Forms.ComboBox();
            this.tb_matchID = new System.Windows.Forms.TextBox();
            this.lbl_THome = new System.Windows.Forms.Label();
            this.lbl_matchID = new System.Windows.Forms.Label();
            this.btn_insert = new System.Windows.Forms.Button();
            this.cb_TAway = new System.Windows.Forms.ComboBox();
            ((System.ComponentModel.ISupportInitialize)(this.dgv_match)).BeginInit();
            this.SuspendLayout();
            // 
            // btn_delete
            // 
            this.btn_delete.Location = new System.Drawing.Point(910, 385);
            this.btn_delete.Margin = new System.Windows.Forms.Padding(2);
            this.btn_delete.Name = "btn_delete";
            this.btn_delete.Size = new System.Drawing.Size(78, 34);
            this.btn_delete.TabIndex = 60;
            this.btn_delete.Text = "Delete";
            this.btn_delete.UseVisualStyleBackColor = true;
            this.btn_delete.Click += new System.EventHandler(this.btn_delete_Click);
            // 
            // btn_add
            // 
            this.btn_add.Location = new System.Drawing.Point(832, 385);
            this.btn_add.Margin = new System.Windows.Forms.Padding(2);
            this.btn_add.Name = "btn_add";
            this.btn_add.Size = new System.Drawing.Size(74, 34);
            this.btn_add.TabIndex = 59;
            this.btn_add.Text = "Add";
            this.btn_add.UseVisualStyleBackColor = true;
            this.btn_add.Click += new System.EventHandler(this.btn_add_Click);
            // 
            // cb_type
            // 
            this.cb_type.FormattingEnabled = true;
            this.cb_type.Items.AddRange(new object[] {
            "CY",
            "CR",
            "GP",
            "GW",
            "GO",
            "PM"});
            this.cb_type.Location = new System.Drawing.Point(832, 341);
            this.cb_type.Margin = new System.Windows.Forms.Padding(2);
            this.cb_type.Name = "cb_type";
            this.cb_type.Size = new System.Drawing.Size(144, 28);
            this.cb_type.TabIndex = 58;
            // 
            // cb_player
            // 
            this.cb_player.FormattingEnabled = true;
            this.cb_player.Location = new System.Drawing.Point(832, 296);
            this.cb_player.Margin = new System.Windows.Forms.Padding(2);
            this.cb_player.Name = "cb_player";
            this.cb_player.Size = new System.Drawing.Size(144, 28);
            this.cb_player.TabIndex = 57;
            // 
            // cb_team
            // 
            this.cb_team.FormattingEnabled = true;
            this.cb_team.Location = new System.Drawing.Point(832, 251);
            this.cb_team.Margin = new System.Windows.Forms.Padding(2);
            this.cb_team.Name = "cb_team";
            this.cb_team.Size = new System.Drawing.Size(144, 28);
            this.cb_team.TabIndex = 56;
            this.cb_team.SelectedIndexChanged += new System.EventHandler(this.cb_team_SelectedIndexChanged);
            // 
            // tb_minute
            // 
            this.tb_minute.Location = new System.Drawing.Point(832, 207);
            this.tb_minute.Margin = new System.Windows.Forms.Padding(2);
            this.tb_minute.Name = "tb_minute";
            this.tb_minute.Size = new System.Drawing.Size(144, 26);
            this.tb_minute.TabIndex = 55;
            // 
            // lbl_type
            // 
            this.lbl_type.AutoSize = true;
            this.lbl_type.Location = new System.Drawing.Point(770, 344);
            this.lbl_type.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lbl_type.Name = "lbl_type";
            this.lbl_type.Size = new System.Drawing.Size(47, 20);
            this.lbl_type.TabIndex = 54;
            this.lbl_type.Text = "Type:";
            // 
            // lbl_player
            // 
            this.lbl_player.AutoSize = true;
            this.lbl_player.Location = new System.Drawing.Point(770, 299);
            this.lbl_player.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lbl_player.Name = "lbl_player";
            this.lbl_player.Size = new System.Drawing.Size(56, 20);
            this.lbl_player.TabIndex = 53;
            this.lbl_player.Text = "Player:";
            // 
            // lbl_team
            // 
            this.lbl_team.AutoSize = true;
            this.lbl_team.Location = new System.Drawing.Point(770, 254);
            this.lbl_team.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lbl_team.Name = "lbl_team";
            this.lbl_team.Size = new System.Drawing.Size(53, 20);
            this.lbl_team.TabIndex = 52;
            this.lbl_team.Text = "Team:";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(767, 258);
            this.label6.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(13, 20);
            this.label6.TabIndex = 51;
            this.label6.Text = " ";
            // 
            // lbl_minute
            // 
            this.lbl_minute.AutoSize = true;
            this.lbl_minute.Location = new System.Drawing.Point(770, 210);
            this.lbl_minute.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lbl_minute.Name = "lbl_minute";
            this.lbl_minute.Size = new System.Drawing.Size(61, 20);
            this.lbl_minute.TabIndex = 50;
            this.lbl_minute.Text = "Minute:";
            // 
            // dgv_match
            // 
            this.dgv_match.AllowUserToAddRows = false;
            this.dgv_match.AllowUserToDeleteRows = false;
            this.dgv_match.AllowUserToResizeColumns = false;
            this.dgv_match.AllowUserToResizeRows = false;
            this.dgv_match.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgv_match.Location = new System.Drawing.Point(34, 124);
            this.dgv_match.Margin = new System.Windows.Forms.Padding(2);
            this.dgv_match.Name = "dgv_match";
            this.dgv_match.RowHeadersWidth = 82;
            this.dgv_match.RowTemplate.Height = 33;
            this.dgv_match.Size = new System.Drawing.Size(714, 393);
            this.dgv_match.TabIndex = 49;
            // 
            // dtp_match
            // 
            this.dtp_match.Location = new System.Drawing.Point(513, 33);
            this.dtp_match.Margin = new System.Windows.Forms.Padding(2);
            this.dtp_match.Name = "dtp_match";
            this.dtp_match.Size = new System.Drawing.Size(315, 26);
            this.dtp_match.TabIndex = 47;
            this.dtp_match.ValueChanged += new System.EventHandler(this.dtp_match_ValueChanged);
            // 
            // lbl_TAway
            // 
            this.lbl_TAway.AutoSize = true;
            this.lbl_TAway.Location = new System.Drawing.Point(382, 69);
            this.lbl_TAway.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lbl_TAway.Name = "lbl_TAway";
            this.lbl_TAway.Size = new System.Drawing.Size(95, 20);
            this.lbl_TAway.TabIndex = 46;
            this.lbl_TAway.Text = "Team Away:";
            // 
            // lbl_matchDate
            // 
            this.lbl_matchDate.AutoSize = true;
            this.lbl_matchDate.Location = new System.Drawing.Point(382, 37);
            this.lbl_matchDate.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lbl_matchDate.Name = "lbl_matchDate";
            this.lbl_matchDate.Size = new System.Drawing.Size(96, 20);
            this.lbl_matchDate.TabIndex = 45;
            this.lbl_matchDate.Text = "Match Date:";
            // 
            // cb_THome
            // 
            this.cb_THome.FormattingEnabled = true;
            this.cb_THome.Location = new System.Drawing.Point(170, 69);
            this.cb_THome.Margin = new System.Windows.Forms.Padding(2);
            this.cb_THome.Name = "cb_THome";
            this.cb_THome.Size = new System.Drawing.Size(146, 28);
            this.cb_THome.TabIndex = 44;
            this.cb_THome.SelectedIndexChanged += new System.EventHandler(this.cb_THome_SelectedIndexChanged);
            // 
            // tb_matchID
            // 
            this.tb_matchID.Enabled = false;
            this.tb_matchID.Location = new System.Drawing.Point(170, 35);
            this.tb_matchID.Margin = new System.Windows.Forms.Padding(2);
            this.tb_matchID.Name = "tb_matchID";
            this.tb_matchID.Size = new System.Drawing.Size(146, 26);
            this.tb_matchID.TabIndex = 43;
            // 
            // lbl_THome
            // 
            this.lbl_THome.AutoSize = true;
            this.lbl_THome.Location = new System.Drawing.Point(35, 69);
            this.lbl_THome.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lbl_THome.Name = "lbl_THome";
            this.lbl_THome.Size = new System.Drawing.Size(100, 20);
            this.lbl_THome.TabIndex = 42;
            this.lbl_THome.Text = "Team Home:";
            // 
            // lbl_matchID
            // 
            this.lbl_matchID.AutoSize = true;
            this.lbl_matchID.Location = new System.Drawing.Point(35, 37);
            this.lbl_matchID.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lbl_matchID.Name = "lbl_matchID";
            this.lbl_matchID.Size = new System.Drawing.Size(78, 20);
            this.lbl_matchID.TabIndex = 41;
            this.lbl_matchID.Text = "Match ID:";
            // 
            // btn_insert
            // 
            this.btn_insert.Location = new System.Drawing.Point(660, 535);
            this.btn_insert.Margin = new System.Windows.Forms.Padding(2);
            this.btn_insert.Name = "btn_insert";
            this.btn_insert.Size = new System.Drawing.Size(88, 34);
            this.btn_insert.TabIndex = 61;
            this.btn_insert.Text = "INSERT";
            this.btn_insert.UseVisualStyleBackColor = true;
            this.btn_insert.Click += new System.EventHandler(this.btn_insert_Click);
            // 
            // cb_TAway
            // 
            this.cb_TAway.FormattingEnabled = true;
            this.cb_TAway.Location = new System.Drawing.Point(513, 69);
            this.cb_TAway.Margin = new System.Windows.Forms.Padding(2);
            this.cb_TAway.Name = "cb_TAway";
            this.cb_TAway.Size = new System.Drawing.Size(146, 28);
            this.cb_TAway.TabIndex = 62;
            this.cb_TAway.SelectedIndexChanged += new System.EventHandler(this.cb_TAway_SelectedIndexChanged);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1043, 675);
            this.Controls.Add(this.cb_TAway);
            this.Controls.Add(this.btn_insert);
            this.Controls.Add(this.btn_delete);
            this.Controls.Add(this.btn_add);
            this.Controls.Add(this.cb_type);
            this.Controls.Add(this.cb_player);
            this.Controls.Add(this.cb_team);
            this.Controls.Add(this.tb_minute);
            this.Controls.Add(this.lbl_type);
            this.Controls.Add(this.lbl_player);
            this.Controls.Add(this.lbl_team);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.lbl_minute);
            this.Controls.Add(this.dgv_match);
            this.Controls.Add(this.dtp_match);
            this.Controls.Add(this.lbl_TAway);
            this.Controls.Add(this.lbl_matchDate);
            this.Controls.Add(this.cb_THome);
            this.Controls.Add(this.tb_matchID);
            this.Controls.Add(this.lbl_THome);
            this.Controls.Add(this.lbl_matchID);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dgv_match)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btn_delete;
        private System.Windows.Forms.Button btn_add;
        private System.Windows.Forms.ComboBox cb_type;
        private System.Windows.Forms.ComboBox cb_player;
        private System.Windows.Forms.ComboBox cb_team;
        private System.Windows.Forms.TextBox tb_minute;
        private System.Windows.Forms.Label lbl_type;
        private System.Windows.Forms.Label lbl_player;
        private System.Windows.Forms.Label lbl_team;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label lbl_minute;
        private System.Windows.Forms.DataGridView dgv_match;
        private System.Windows.Forms.DateTimePicker dtp_match;
        private System.Windows.Forms.Label lbl_TAway;
        private System.Windows.Forms.Label lbl_matchDate;
        private System.Windows.Forms.ComboBox cb_THome;
        private System.Windows.Forms.TextBox tb_matchID;
        private System.Windows.Forms.Label lbl_THome;
        private System.Windows.Forms.Label lbl_matchID;
        private System.Windows.Forms.Button btn_insert;
        private System.Windows.Forms.ComboBox cb_TAway;
    }
}

